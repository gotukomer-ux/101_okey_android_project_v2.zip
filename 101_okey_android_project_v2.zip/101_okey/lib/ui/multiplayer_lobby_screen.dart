import 'dart:async';

import 'package:flutter/material.dart';

import '../multiplayer/bluetooth_transport.dart';
import '../multiplayer/lan_transport.dart';
import '../multiplayer/multiplayer_transport.dart';
import '../multiplayer/room_coordinator.dart';
import '../game/game_state.dart';
import 'game_table_screen.dart';
import '../multiplayer/room_state.dart';

enum _ConnectionMode { wifi, bluetooth }

class MultiplayerLobbyScreen extends StatefulWidget {
  const MultiplayerLobbyScreen({super.key});

  @override
  State<MultiplayerLobbyScreen> createState() => _MultiplayerLobbyScreenState();
}

class _MultiplayerLobbyScreenState extends State<MultiplayerLobbyScreen> {
  final _nameController = TextEditingController(text: 'Oyuncu');
  final _ipController = TextEditingController();
  _ConnectionMode _mode = _ConnectionMode.wifi;
  RoomCoordinator? _coordinator;
  StreamSubscription<RoomSnapshot>? _snapshotSubscription;
  StreamSubscription<String>? _statusSubscription;
  StreamSubscription<GameView>? _gameSubscription;
  RoomSnapshot? _snapshot;
  String _status = 'Bağlantı yöntemi seçip masa kurabilir veya masaya katılabilirsiniz.';
  String? _connectionAddress;
  List<PairedBluetoothDevice> _pairedDevices = const [];
  String? _selectedDeviceAddress;
  bool _busy = false;
  bool _roomCreated = false;
  bool _gamePageShown = false;

  @override
  void dispose() {
    _snapshotSubscription?.cancel();
    _statusSubscription?.cancel();
    _gameSubscription?.cancel();
    _coordinator?.dispose();
    _nameController.dispose();
    _ipController.dispose();
    super.dispose();
  }

  String get _playerName {
    final value = _nameController.text.trim();
    return value.isEmpty ? 'Oyuncu' : value;
  }

  MultiplayerTransport _newTransport() =>
      _mode == _ConnectionMode.wifi ? LanTransport() : BluetoothTransport();

  Future<void> _prepareCoordinator() async {
    await _snapshotSubscription?.cancel();
    await _statusSubscription?.cancel();
    await _gameSubscription?.cancel();
    await _coordinator?.dispose();
    final coordinator = RoomCoordinator(
      transport: _newTransport(),
      playerName: _playerName,
    );
    _coordinator = coordinator;
    _snapshot = null;
    _connectionAddress = null;
    _roomCreated = false;
    _gamePageShown = false;
    _snapshotSubscription = coordinator.snapshots.listen((snapshot) {
      if (mounted) setState(() => _snapshot = snapshot);
    });
    _statusSubscription = coordinator.statuses.listen((status) {
      if (mounted) setState(() => _status = status);
    });
    _gameSubscription = coordinator.gameViews.listen(_showGameTable);
  }

  void _showGameTable(GameView view, {bool force = false}) {
    if (!mounted) return;
    if (!_gamePageShown || force) {
      _gamePageShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || _coordinator == null) return;
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => GameTableScreen(session: _coordinator!, initialView: view),
        ));
      });
    }
  }

  Future<void> _hostRoom() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await _prepareCoordinator();
      final address = await _coordinator!.host();
      if (!mounted) return;
      setState(() {
        _connectionAddress = address;
        _roomCreated = true;
        _status = _mode == _ConnectionMode.wifi
            ? 'Masa hazır. Diğer telefonlar aynı Wi-Fi ağına bağlanıp bu IP ile katılabilir.'
            : 'Bluetooth masası hazır. Diğer telefonlar önce bu cihazla eşleşip ardından katılabilir.';
      });
    } catch (error) {
      _showError(error);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _joinRoom() async {
    if (_busy) return;
    final target = _mode == _ConnectionMode.wifi
        ? _ipController.text.trim()
        : (_selectedDeviceAddress ?? '');
    if (target.isEmpty) {
      _showError(_mode == _ConnectionMode.wifi
          ? 'Masa sahibinin IP adresini girin.'
          : 'Önce eşleşmiş Bluetooth cihazlarından masa sahibini seçin.');
      return;
    }
    setState(() => _busy = true);
    try {
      await _prepareCoordinator();
      await _coordinator!.join(target);
      if (mounted) {
        setState(() {
          _roomCreated = true;
          _status = 'Bağlantı kuruldu; masadan yanıt bekleniyor.';
        });
      }
    } catch (error) {
      _showError(error);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _loadPairedDevices() async {
    try {
      final devices = await BluetoothTransport().pairedBluetoothDevices();
      if (!mounted) return;
      setState(() {
        _pairedDevices = devices;
        _selectedDeviceAddress = devices.isEmpty ? null : devices.first.address;
      });
      if (devices.isEmpty) {
        _showInfo('Eşleşmiş cihaz bulunamadı. Telefon ayarlarından masa sahibiyle Bluetooth eşleştirmesi yapın.');
      }
    } catch (error) {
      _showError(error);
    }
  }

  Future<void> _openBluetoothSettings() async {
    try {
      await BluetoothTransport().openBluetoothSettings();
    } catch (error) {
      _showError(error);
    }
  }

  Future<void> _leaveRoom() async {
    await _coordinator?.leave();
    await _coordinator?.dispose();
    if (!mounted) return;
    setState(() {
      _coordinator = null;
      _snapshot = null;
      _roomCreated = false;
      _connectionAddress = null;
      _gamePageShown = false;
      _status = 'Masadan ayrıldınız.';
    });
  }

  void _showError(Object error) {
    if (!mounted) return;
    setState(() => _status = 'Hata: $error');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Bağlantı kurulamadı: $error')),
    );
  }

  void _showInfo(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final players = _snapshot?.players ?? const <RoomPlayer>[];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dört Kişilik Masa'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(builder: (context, constraints) {
          final compact = constraints.maxWidth < 760;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1040),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Oyuncu ve bağlantı',
                                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _nameController,
                              maxLength: 18,
                              enabled: !_roomCreated && _snapshot == null,
                              decoration: const InputDecoration(
                                labelText: 'Oyuncu adınız',
                                border: OutlineInputBorder(),
                                counterText: '',
                              ),
                            ),
                            const SizedBox(height: 10),
                            SegmentedButton<_ConnectionMode>(
                              segments: const [
                                ButtonSegment(
                                  value: _ConnectionMode.wifi,
                                  icon: Icon(Icons.wifi),
                                  label: Text('Aynı Wi-Fi'),
                                ),
                                ButtonSegment(
                                  value: _ConnectionMode.bluetooth,
                                  icon: Icon(Icons.bluetooth),
                                  label: Text('Bluetooth'),
                                ),
                              ],
                              selected: {_mode},
                              onSelectionChanged: _roomCreated || _snapshot != null
                                  ? null
                                  : (selection) => setState(() => _mode = selection.first),
                            ),
                            const SizedBox(height: 12),
                            if (_mode == _ConnectionMode.wifi) ...[
                              if (_snapshot == null && !_roomCreated) ...[
                                TextField(
                                  controller: _ipController,
                                  keyboardType: TextInputType.text,
                                  decoration: const InputDecoration(
                                    labelText: 'Masa sahibinin IPv4 adresi',
                                    hintText: '192.168.1.25',
                                    border: OutlineInputBorder(),
                                  ),
                                ),
                              ],
                              Wrap(
                                spacing: 10,
                                runSpacing: 10,
                                children: [
                                  FilledButton.icon(
                                    onPressed: _busy || _roomCreated || _snapshot != null ? null : _hostRoom,
                                    icon: const Icon(Icons.add_to_home_screen),
                                    label: const Text('Wi-Fi masası kur'),
                                  ),
                                  OutlinedButton.icon(
                                    onPressed: _busy || _roomCreated || _snapshot != null ? null : _joinRoom,
                                    icon: const Icon(Icons.login),
                                    label: const Text('IP ile masaya katıl'),
                                  ),
                                ],
                              ),
                            ] else ...[
                              if (_snapshot == null && !_roomCreated) ...[
                                Wrap(
                                  spacing: 10,
                                  runSpacing: 10,
                                  children: [
                                    FilledButton.icon(
                                      onPressed: _busy ? null : _hostRoom,
                                      icon: const Icon(Icons.bluetooth),
                                      label: const Text('Bluetooth masası kur'),
                                    ),
                                    OutlinedButton.icon(
                                      onPressed: _busy ? null : _loadPairedDevices,
                                      icon: const Icon(Icons.refresh),
                                      label: const Text('Eşleşmiş cihazları getir'),
                                    ),
                                    OutlinedButton.icon(
                                      onPressed: _openBluetoothSettings,
                                      icon: const Icon(Icons.settings_bluetooth),
                                      label: const Text('Bluetooth ayarları'),
                                    ),
                                  ],
                                ),
                                if (_pairedDevices.isNotEmpty) ...[
                                  const SizedBox(height: 12),
                                  DropdownButtonFormField<String>(
                                    value: _selectedDeviceAddress,
                                    decoration: const InputDecoration(
                                      labelText: 'Masa sahibi cihazı',
                                      border: OutlineInputBorder(),
                                    ),
                                    items: _pairedDevices
                                        .map((device) => DropdownMenuItem(
                                              value: device.address,
                                              child: Text('${device.name} (${device.address})'),
                                            ))
                                        .toList(),
                                    onChanged: (value) => setState(() => _selectedDeviceAddress = value),
                                  ),
                                  const SizedBox(height: 10),
                                  OutlinedButton.icon(
                                    onPressed: _busy ? null : _joinRoom,
                                    icon: const Icon(Icons.login),
                                    label: const Text('Seçili Bluetooth masasına katıl'),
                                  ),
                                ],
                              ],
                              const SizedBox(height: 8),
                              const Text(
                                'Bluetooth için telefonları önce Android Bluetooth ayarlarından eşleştirin. Masa sahibi uygulamada masayı açık tutmalıdır.',
                                style: TextStyle(color: Colors.white70),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    if (_roomCreated && _snapshot == null) ...[
                      const SizedBox(height: 14),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              const Expanded(child: Text('Bağlantı kuruluyor veya masa sahibinin yanıtı bekleniyor.')),
                              OutlinedButton.icon(
                                onPressed: _leaveRoom,
                                icon: const Icon(Icons.logout),
                                label: const Text('Ayrıl'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    if (_snapshot != null) ...[
                      const SizedBox(height: 14),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Expanded(
                                    child: Text('Oyun masası',
                                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                  ),
                                  Chip(label: Text('${players.length}/4 oyuncu')),
                                ],
                              ),
                              if (_connectionAddress != null) ...[
                                const SizedBox(height: 8),
                                SelectableText(
                                  _mode == _ConnectionMode.wifi
                                      ? 'IP: ${_connectionAddress!.split(':').first}  •  Port: ${_connectionAddress!.split(':').last}'
                                      : 'Bluetooth cihazı: $_connectionAddress',
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                              ],
                              const SizedBox(height: 12),
                              GridView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: compact ? 2 : 4,
                                  mainAxisSpacing: 8,
                                  crossAxisSpacing: 8,
                                  childAspectRatio: compact ? 2.8 : 2.2,
                                ),
                                itemCount: 4,
                                itemBuilder: (context, index) {
                                  final matchingPlayers = players.where((p) => p.seat == index).toList();
                                  final player = matchingPlayers.isEmpty ? null : matchingPlayers.first;
                                  return Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: player == null
                                          ? Colors.white.withOpacity(0.04)
                                          : const Color(0xFF174C39),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                          color: player == null ? Colors.white24 : const Color(0xFFC9A45C)),
                                    ),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 16,
                                          child: Text('${index + 1}'),
                                        ),
                                        const SizedBox(width: 9),
                                        Expanded(
                                          child: Text(
                                            player == null ? 'Boş koltuk' : player.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        if (player?.isHost == true)
                                          const Icon(Icons.star, color: Color(0xFFC9A45C), size: 17),
                                      ],
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 12),
                              if (_snapshot!.isFull)
                                const Text('Dört oyuncu da masada.',
                                    style: TextStyle(color: Colors.lightGreenAccent)),
                              if (_snapshot!.isFull && _coordinator?.isHost == true && !_coordinator!.gameStarted) ...[
                                const SizedBox(height: 10),
                                FilledButton.icon(
                                  onPressed: _busy ? null : () async {
                                    setState(() => _busy = true);
                                    try {
                                      await _coordinator!.startRoom();
                                    } catch (error) {
                                      _showError(error);
                                    } finally {
                                      if (mounted) setState(() => _busy = false);
                                    }
                                  },
                                  icon: const Icon(Icons.play_arrow_rounded),
                                  label: const Text('Oyunu başlat'),
                                ),
                              ] else if (_snapshot!.isFull && _coordinator?.isHost == false) ...[
                                const SizedBox(height: 8),
                                const Text('Masa sahibinin oyunu başlatması bekleniyor.'),
                              ],
                              if (_snapshot!.isFull && _coordinator?.gameStarted == true && _coordinator?.currentGameView != null) ...[
                                const SizedBox(height: 8),
                                OutlinedButton.icon(
                                  onPressed: () => _showGameTable(_coordinator!.currentGameView!, force: true),
                                  icon: const Icon(Icons.sports_esports),
                                  label: const Text('Oyuna geri dön'),
                                ),
                              ],
                              const SizedBox(height: 8),
                              OutlinedButton.icon(
                                onPressed: _leaveRoom,
                                icon: const Icon(Icons.logout),
                                label: const Text('Masadan ayrıl'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Card(
                      color: const Color(0xFF173A2E),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.info_outline, color: Color(0xFFC9A45C)),
                            const SizedBox(width: 10),
                            Expanded(child: Text(_status)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Oyun başladığında host taşları dağıtır, oyunculara yalnızca kendi ellerini gönderir ve bütün hamleleri merkezi olarak doğrular.',
                      style: TextStyle(color: Colors.white60, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
