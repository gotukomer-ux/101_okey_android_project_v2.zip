import 'dart:async';

import 'package:flutter/material.dart';

import '../domain/meld.dart';
import '../domain/tile.dart';
import '../game/game_state.dart';
import '../game/opening_rules.dart';
import '../session/game_session.dart';

class GameTableScreen extends StatefulWidget {
  const GameTableScreen({
    super.key,
    required this.session,
    required this.initialView,
  });

  final GameSession session;
  final GameView initialView;

  @override
  State<GameTableScreen> createState() => _GameTableScreenState();
}

class _GameTableScreenState extends State<GameTableScreen> {
  late GameView _view;
  StreamSubscription<GameView>? _subscription;
  StreamSubscription<String>? _statusSubscription;
  final Set<String> _selected = {};
  final List<List<String>> _draftMelds = [];
  final List<List<String>> _draftPairs = [];
  final Map<String, TileFace> _representedFaces = {};
  String? _selectedMeldId;
  bool _busy = false;
  bool _sortByNumber = false;
  List<String> _manualOrder = [];

  @override
  void initState() {
    super.initState();
    _view = widget.initialView;
    _manualOrder = _view.myHand.map((tile) => tile.id).toList();
    _subscription = widget.session.gameViews.listen((view) {
      if (!mounted) return;
      setState(() {
        _view = view;
        final currentIds = view.myHand.map((tile) => tile.id).toSet();
        _manualOrder.removeWhere((id) => !currentIds.contains(id));
        for (final tile in view.myHand) {
          if (!_manualOrder.contains(tile.id)) _manualOrder.add(tile.id);
        }
        // Selection is cleared only after an authoritative state update. A
        // rejected network move therefore leaves the user's selection intact.
        _selected.clear();
        _selectedMeldId = null;
        _representedFaces.removeWhere((id, _) => !currentIds.contains(id));
        final mine = view.players.firstWhere((player) => player.seat == view.mySeat);
        if (mine.hasOpened) {
          _draftMelds.clear();
          _draftPairs.clear();
        }
      });
    });
    _statusSubscription = widget.session.statuses.listen((message) {
      final lower = message.toLowerCase();
      if (lower.contains('hata') || lower.contains('redded') ||
          lower.contains('geçersiz') || lower.contains('sıra sizde değil') ||
          lower.contains('bulunamadı') || lower.contains('başarısız') ||
          lower.contains('bad state')) {
        _showMessage(message);
      }
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _statusSubscription?.cancel();
    super.dispose();
  }

  PlayerGameSummary get _myPlayer => _view.players.firstWhere((player) => player.seat == _view.mySeat);
  bool get _myTurn => !_view.roundFinished && _view.currentSeat == _view.mySeat;
  bool get _canProcess => _myTurn && !_view.mustDraw && !_busy &&
      _myPlayer.openingType == OpeningType.normal && _view.myHand.length > 1;
  bool get _canStartOpening => _myTurn && !_view.mustDraw && !_busy && !_myPlayer.hasOpened;
  bool get _canDraw => _myTurn && _view.mustDraw && !_busy;
  bool get _canDiscard => _myTurn && !_view.mustDraw && !_busy && _selected.length == 1;

  List<Tile> get _displayHand {
    final hand = [..._view.myHand];
    if (_sortByNumber) {
      hand.sort((a, b) {
        if (a.isNumbered != b.isNumbered) return a.isNumbered ? -1 : 1;
        if (!a.isNumbered) return a.id.compareTo(b.id);
        final colorCompare = a.color!.index.compareTo(b.color!.index);
        return colorCompare != 0 ? colorCompare : a.number!.compareTo(b.number!);
      });
    } else {
      final order = {for (var i = 0; i < _manualOrder.length; i++) _manualOrder[i]: i};
      hand.sort((a, b) => (order[a.id] ?? 1 << 20).compareTo(order[b.id] ?? 1 << 20));
    }
    return hand;
  }

  void _reorderHand(int oldIndex, int newIndex) {
    final hand = _displayHand;
    if (newIndex > oldIndex) newIndex -= 1;
    if (oldIndex < 0 || oldIndex >= hand.length || newIndex < 0 || newIndex >= hand.length) return;
    setState(() {
      final moved = hand.removeAt(oldIndex);
      hand.insert(newIndex, moved);
      _manualOrder = hand.map((tile) => tile.id).toList();
      _sortByNumber = false;
    });
  }

  Future<void> _act(Map<String, dynamic> action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.session.submitGameAction(action);
      // The session publishes an authoritative view after acceptance. Do not
      // clear a remote player's selection merely because the socket write worked.
      if (!mounted) return;
    } catch (error) {
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  Future<void> _startNextRound() async {
    if (_busy || !widget.session.canStartNextRound) return;
    setState(() => _busy = true);
    try {
      await widget.session.startNextRound();
      if (mounted) {
        setState(() {
          _selected.clear();
          _draftMelds.clear();
          _draftPairs.clear();
          _representedFaces.clear();
          _selectedMeldId = null;
          _manualOrder = _view.myHand.map((tile) => tile.id).toList();
        });
      }
    } catch (error) {
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _stageMeld() {
    if (!_canStartOpening || _selected.length < 3) return;
    if (_draftPairs.isNotEmpty) {
      _showMessage('Çift açılışı hazırlarken normal per hazırlayamazsınız.');
      return;
    }
    final alreadyStaged = _draftMelds.expand((meld) => meld).toSet();
    if (_selected.any(alreadyStaged.contains)) {
      _showMessage('Bir taş iki farklı per içinde kullanılamaz.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final tiles = _selected
        .map((id) => byId[id]!)
        .map((tile) => MeldTile(tile, representedFace: _representedFaces[tile.id]))
        .toList();
    final validation = MeldValidator.validate(tiles, _view.realOkey);
    if (!validation.isValid) {
      _showMessage(validation.error ?? 'Seçilen taşlar geçerli per değil.');
      return;
    }
    setState(() {
      _draftMelds.add(_selected.toList());
      _selected.clear();
    });
  }

  void _stagePair() {
    if (!_canStartOpening || _selected.length != 2) return;
    if (_draftMelds.isNotEmpty) {
      _showMessage('Normal açılış hazırlarken çift açılışı hazırlayamazsınız.');
      return;
    }
    final alreadyStaged = _draftPairs.expand((pair) => pair).toSet();
    if (_selected.any(alreadyStaged.contains)) {
      _showMessage('Bir taş iki farklı çift içinde kullanılamaz.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final selectedTiles = _selected.map((id) => byId[id]!).toList();
    final first = selectedTiles[0];
    final second = selectedTiles[1];
    if (!first.isNumbered || !second.isNumbered ||
        first.color != second.color || first.number != second.number) {
      _showMessage('Çift aynı renk ve aynı sayıdaki iki taştan oluşmalı.');
      return;
    }
    setState(() {
      _draftPairs.add(_selected.toList());
      _selected.clear();
    });
  }


  int _draftOpeningPoints() {
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    return _draftMelds.fold<int>(0, (total, ids) {
      final meld = ids.map((id) => MeldTile(
        byId[id]!,
        representedFace: _representedFaces[id],
      )).toList();
      return total + OpeningRules.meldPoints(meld, _view.realOkey);
    });
  }

  Future<void> _openNormal() async {
    if (_draftMelds.isEmpty || _myPlayer.hasOpened) return;
    if (_draftPairs.isNotEmpty) {
      _showMessage('Çift açılışı hazırlarken normal açılış yapamazsınız.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final proposedMelds = _draftMelds
        .map((ids) => ids
            .map((id) => MeldTile(byId[id]!, representedFace: _representedFaces[id]))
            .toList())
        .toList();
    final points = proposedMelds.fold<int>(
        0, (sum, meld) => sum + OpeningRules.meldPoints(meld, _view.realOkey));
    if (!OpeningRules.canOpenNormally(proposedMelds, _view.realOkey)) {
      _showMessage('Açılış geçersiz veya toplamı $points. En az 101 puanlık geçerli perler gerekli.');
      return;
    }
    await _act({
      'action': 'open_normal',
      'melds': _draftMelds
          .map((ids) => ids
              .map((id) => {
                    'tileId': id,
                    if (_representedFaces[id] != null)
                      'representedFace': _representedFaces[id]!.toJson(),
                  })
              .toList())
          .toList(),
    });
  }

  Future<void> _openPairs() async {
    if (_draftPairs.length < 5 || _draftMelds.isNotEmpty || _myPlayer.hasOpened) {
      _showMessage('Çift açmak için başka normal per hazırlamadan en az beş çift gerekli.');
      return;
    }
    await _act({'action': 'open_pairs', 'pairs': _draftPairs});
  }

  Future<void> _addToSelectedMeld() async {
    if (!_canProcess || _selected.length != 1 || _selectedMeldId == null) return;
    await _act({
      'action': 'add_to_meld',
      'meldId': _selectedMeldId,
      'tileId': _selected.first,
      if (_representedFaces[_selected.first] != null)
        'representedFace': _representedFaces[_selected.first]!.toJson(),
    });
  }


  Future<void> _chooseOkeyValue() async {
    if (_selected.length != 1) {
      _showMessage('Önce elinizden tek bir gerçek okey taşı seçin.');
      return;
    }
    final tileId = _selected.first;
    final matches = _view.myHand.where((tile) => tile.id == tileId).toList();
    if (matches.isEmpty) return;
    final tile = matches.first;
    final isRealOkey = tile.isNumbered &&
        tile.color == _view.realOkey.color && tile.number == _view.realOkey.number;
    if (!isRealOkey) {
      _showMessage('Yalnızca gerçek okeyin temsil edeceği yüz seçilebilir.');
      return;
    }
    var color = _representedFaces[tileId]?.color ?? TileColor.red;
    var number = _representedFaces[tileId]?.number ?? 1;
    final selectedFace = await showDialog<TileFace>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Okey hangi taşın yerine geçsin?'),
          content: Row(
            children: [
              Expanded(
                child: DropdownButton<TileColor>(
                  isExpanded: true,
                  value: color,
                  items: TileColor.values
                      .map((value) => DropdownMenuItem(value: value, child: Text(value.name)))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => color = value);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: number,
                  items: List.generate(13, (index) => index + 1)
                      .map((value) => DropdownMenuItem(value: value, child: Text('$value')))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => number = value);
                  },
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, TileFace(color, number)), child: const Text('Uygula')),
          ],
        ),
      ),
    );
    if (selectedFace != null && mounted) {
      setState(() => _representedFaces[tileId] = selectedFace);
    }
  }

  Color _faceColor(TileColor color) {
    switch (color) {
      case TileColor.red:
        return const Color(0xFFC62828);
      case TileColor.blue:
        return const Color(0xFF1565C0);
      case TileColor.black:
        return const Color(0xFF212121);
      case TileColor.yellow:
        return const Color(0xFFF9A825);
    }
  }

  Widget _tile(
    Tile tile, {
    bool selected = false,
    VoidCallback? onTap,
    double width = 42,
    TileFace? shownFace,
  }) {
    final face = shownFace ?? (tile.isNumbered ? TileFace(tile.color!, tile.number!) : null);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: width,
        height: 62,
        margin: EdgeInsets.only(left: 2, right: 2, top: selected ? 0 : 7, bottom: selected ? 6 : 0),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF8E8),
          borderRadius: BorderRadius.circular(7),
          border: Border.all(
            color: selected ? const Color(0xFFFFD54F) : Colors.black26,
            width: selected ? 3 : 1,
          ),
          boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 3, offset: Offset(0, 2))],
        ),
        child: Center(
          child: face != null
              ? Text(
                  '${face.number}',
                  style: TextStyle(
                    fontSize: 27,
                    fontWeight: FontWeight.w900,
                    color: _faceColor(face.color),
                  ),
                )
              : const Icon(Icons.star, color: Color(0xFF6D4C41), size: 25),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentPlayer = _view.players.firstWhere((p) => p.seat == _view.currentSeat);
    final topDiscard = _view.discardPile.isEmpty ? null : _view.discardPile.last;
    return Scaffold(
      appBar: AppBar(
        title: Text('101 Okey  •  El ${_view.roundNumber}'),
        automaticallyImplyLeading: false,
        actions: [
          TextButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.meeting_room_outlined),
            label: const Text('Lobi'),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _playerBadge(_view.players[( _view.mySeat + 2) % 4]),
                  _playerBadge(_view.players[(_view.mySeat + 1) % 4]),
                  _playerBadge(_view.players[(_view.mySeat + 3) % 4]),
                  Row(children: [
                    const Text('Gösterge: '),
                    _tile(_view.indicator, width: 34),
                    const SizedBox(width: 8),
                    Text('Okey: ${_view.realOkey.color.name} ${_view.realOkey.number}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ]),
                ],
              ),
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFF17563E),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: const Color(0xFFC9A45C), width: 3),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: _view.melds.map((meld) {
                            final selected = _selectedMeldId == meld.id;
                            return DragTarget<String>(
                              onWillAccept: (tileId) => tileId != null && _canProcess &&
                                  meld.type != GameMeldType.pair,
                              onAccept: (tileId) => _act({
                                'action': 'add_to_meld',
                                'meldId': meld.id,
                                'tileId': tileId,
                                if (_representedFaces[tileId] != null)
                                  'representedFace': _representedFaces[tileId]!.toJson(),
                              }),
                              builder: (context, candidates, rejected) => GestureDetector(
                                onTap: () => setState(() => _selectedMeldId = meld.id),
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 120),
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: candidates.isNotEmpty
                                        ? Colors.amber.withOpacity(.30)
                                        : selected ? Colors.amber.withOpacity(.22) : Colors.black12,
                                    border: Border.all(color: candidates.isNotEmpty || selected ? Colors.amber : Colors.white24),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Row(mainAxisSize: MainAxisSize.min, children: meld.tiles.map((item) => _tile(item.tile, width: 30)).toList()),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('Kapalı deste'),
                        Container(
                          width: 48,
                          height: 62,
                          decoration: BoxDecoration(color: const Color(0xFF244D86), borderRadius: BorderRadius.circular(7), border: Border.all(color: Colors.white70)),
                          child: const Center(child: Icon(Icons.layers, color: Colors.white)),
                        ),
                        Text('${_view.drawPileCount} taş'),
                        const SizedBox(height: 8),
                        const Text('Son atılan'),
                        if (topDiscard != null) _tile(topDiscard, width: 38) else const SizedBox(width: 38, height: 62),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            if (_view.requiredOpeningTileId != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                child: Row(
                  children: const [
                    Icon(Icons.info_outline, color: Colors.amberAccent, size: 16),
                    SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Yandan aldığınız taşı bu tur 101 veya çift açılışında kullanmalısınız.',
                        style: TextStyle(color: Colors.amberAccent, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Expanded(child: Text(_view.roundFinished ? 'El bitti • Kazanan: ${_view.players[_view.winnerSeat ?? 0].name} (${_view.winType?.name ?? '-'})' : _myTurn ? 'Sıra sizde' : 'Sıra: ${currentPlayer.name}', style: const TextStyle(fontWeight: FontWeight.bold))),
                  Text('Deste: ${_view.drawPileCount}'),
                  IconButton(tooltip: 'Taşları sırala', onPressed: () => setState(() => _sortByNumber = !_sortByNumber), icon: const Icon(Icons.sort)),
                ],
              ),
            ),
            SizedBox(
              height: 78,
              child: ReorderableListView(
                scrollDirection: Axis.horizontal,
                buildDefaultDragHandles: false,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                onReorder: _reorderHand,
                children: List<Widget>.generate(_displayHand.length, (index) {
                  final tile = _displayHand[index];
                  return Row(
                    key: ValueKey(tile.id),
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      LongPressDraggable<String>(
                        data: tile.id,
                        feedback: Material(
                          color: Colors.transparent,
                          child: _tile(tile, selected: true),
                        ),
                        childWhenDragging: Opacity(
                          opacity: .35,
                          child: _tile(tile, selected: _selected.contains(tile.id)),
                        ),
                        child: _tile(
                          tile,
                          selected: _selected.contains(tile.id),
                          onTap: _view.roundFinished ? null : () => setState(() {
                            if (!_selected.add(tile.id)) _selected.remove(tile.id);
                          }),
                        ),
                      ),
                      ReorderableDragStartListener(
                        index: index,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 1),
                          child: Icon(Icons.drag_indicator, size: 13, color: Colors.white38),
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 2, 8, 8),
                child: Row(
                  children: [
                    FilledButton(onPressed: _canDraw ? () => _act({'action': 'draw_stock'}) : null, child: const Text('Taş çek')),
                    const SizedBox(width: 6),
                    FilledButton(onPressed: _canDraw && _view.discardPile.isNotEmpty ? () => _act({'action': 'take_discard'}) : null, child: const Text('Yandan al')),
                    const SizedBox(width: 6),
                    FilledButton(onPressed: _canDiscard ? () => _act({'action': 'discard', 'tileId': _selected.first}) : null, child: const Text('Taş at')),
                    const SizedBox(width: 6),
                    OutlinedButton(onPressed: _canStartOpening ? _stageMeld : null, child: const Text('Per ekle')),
                    const SizedBox(width: 6),
                    OutlinedButton(onPressed: _myTurn && !_view.mustDraw && !_busy && _selected.length == 1 ? _chooseOkeyValue : null, child: const Text('Okey değeri')),
                    const SizedBox(width: 6),
                    OutlinedButton(onPressed: _canStartOpening ? _stagePair : null, child: const Text('Çift ekle')),
                    const SizedBox(width: 6),
                    FilledButton.tonal(onPressed: _canStartOpening && _draftMelds.isNotEmpty ? _openNormal : null, child: Text('101 aç (${_draftMelds.length})')),
                    const SizedBox(width: 6),
                    FilledButton.tonal(onPressed: _canStartOpening && _draftPairs.length >= 5 ? _openPairs : null, child: Text('Çift aç (${_draftPairs.length})')),
                    const SizedBox(width: 6),
                    OutlinedButton(onPressed: _canProcess && _selected.length == 1 && _selectedMeldId != null ? _addToSelectedMeld : null, child: const Text('Seçili pere işle')),
                  ],
                ),
              ),
            ),
            if (_draftMelds.isNotEmpty || _draftPairs.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  _draftPairs.isNotEmpty
                      ? 'Hazırlanan çift: ${_draftPairs.length}/5'
                      : 'Hazırlanan per: ${_draftMelds.length} • Açılış puanı: ${_draftOpeningPoints()}/101',
                  style: const TextStyle(color: Colors.amberAccent, fontSize: 12),
                ),
              ),
            if (_view.roundFinished)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Wrap(
                      spacing: 14,
                      children: _view.players.map((player) => Text(
                        '${player.name}: ${_view.scoreDeltas[player.seat] ?? 0}  •  Toplam ${player.totalScore}',
                      )).toList(),
                    ),
                    const SizedBox(height: 6),
                    if (widget.session.canStartNextRound)
                      FilledButton.icon(
                        onPressed: _busy ? null : _startNextRound,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Yeni el başlat'),
                      )
                    else
                      const Text('Yeni eli masa sahibinin başlatması bekleniyor.',
                          style: TextStyle(color: Colors.white60, fontSize: 12)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _playerBadge(PlayerGameSummary player) {
    final isCurrent = player.seat == _view.currentSeat && !_view.roundFinished;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: isCurrent ? Colors.amber.withOpacity(.18) : Colors.white10,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: isCurrent ? Colors.amber : Colors.white24),
      ),
      child: Text('${player.name}  •  ${player.handCount} taş  •  ${player.totalScore} puan${player.hasOpened ? ' • Açtı' : ''}', style: const TextStyle(fontSize: 11)),
    );
  }
}
