import 'transport_event.dart';

abstract interface class MultiplayerTransport {
  Stream<TransportEvent> get events;

  /// Starts a room and returns a human-readable connection address/name.
  Future<String> host();

  /// Joins a room. [target] is an IPv4 address for Wi-Fi or a paired MAC for Bluetooth.
  Future<void> join(String target);

  /// Host may target a peer; clients send to their host when peerId is null.
  Future<void> send(Map<String, dynamic> message, {String? peerId});

  /// Removes a rejected or disconnected remote peer from the host transport.
  Future<void> disconnectPeer(String peerId);

  Future<void> close();

  Future<List<PairedBluetoothDevice>> pairedBluetoothDevices();

  Future<void> openBluetoothSettings();
}

abstract interface class DisposableMultiplayerTransport {
  Future<void> disposeTransport();
}
