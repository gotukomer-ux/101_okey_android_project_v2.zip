import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'bot/bot_strategy.dart';
import 'session/solo_game_controller.dart';
import 'ui/game_table_screen.dart';
import 'ui/multiplayer_lobby_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const OkeyApp());
}

class OkeyApp extends StatelessWidget {
  const OkeyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '101 Okey',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF10251E),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2E8B62),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF10251E)),
      ),
      home: const GameHomeScreen(),
    );
  }
}

class GameHomeScreen extends StatelessWidget {
  const GameHomeScreen({super.key});

  Future<void> _startSolo(BuildContext context) async {
    final difficulty = await showDialog<BotDifficulty>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Bilgisayara karşı oyna'),
        content: const Text('Üç botun zorluk seviyesini seç.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, BotDifficulty.easy),
            child: const Text('Kolay'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, BotDifficulty.medium),
            child: const Text('Orta'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, BotDifficulty.hard),
            child: const Text('Zor'),
          ),
        ],
      ),
    );
    if (difficulty == null || !context.mounted) return;
    final session = SoloGameController.newGame(difficulty: difficulty);
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => GameTableScreen(
        session: session,
        initialView: session.currentGameView,
      ),
    ));
    await session.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: Container(
              margin: const EdgeInsets.all(18),
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              decoration: BoxDecoration(
                color: const Color(0xFF174C39),
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: const Color(0xFFC9A45C), width: 4),
                boxShadow: const [
                  BoxShadow(color: Colors.black54, blurRadius: 24, spreadRadius: 3),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('101 OKEY',
                      style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 5)),
                  const SizedBox(height: 8),
                  const Text('Klasik Türk 101 Okey', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 26),
                  SizedBox(
                    width: 300,
                    child: FilledButton.icon(
                      onPressed: () => _startSolo(context),
                      icon: const Icon(Icons.smart_toy_outlined),
                      label: const Text('Bilgisayara Karşı Oyna'),
                      style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: 300,
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => const MultiplayerLobbyScreen())),
                      icon: const Icon(Icons.groups_rounded),
                      label: const Text('Dört Kişilik Masa'),
                      style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text('Tek kişilik bot oyunu veya aynı Wi-Fi / Bluetooth ile 4 kişi',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white60, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
