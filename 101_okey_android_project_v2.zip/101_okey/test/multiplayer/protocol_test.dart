import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/multiplayer/lan_transport.dart';
import 'package:classic_101_okey/multiplayer/room_coordinator.dart';

void main() {
  test('host rejects an older multiplayer protocol before allocating a seat', () async {
    final host = RoomCoordinator(
      transport: LanTransport(port: 0),
      playerName: 'Host',
    );
    Socket? client;
    try {
      final address = await host.host();
      final port = int.parse(address.split(':').last);
      final socket = await Socket.connect('127.0.0.1', port);
      client = socket;
      final responseFuture = socket
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .first
          .timeout(const Duration(seconds: 5));
      socket.write('${jsonEncode({
        'type': 'join',
        'playerId': 'old-client',
        'name': 'Old client',
        'protocol': 1,
      })}\n');
      await socket.flush();

      final response = jsonDecode(await responseFuture) as Map<String, dynamic>;
      expect(response['type'], 'join_rejected');
      expect(response['reason'], contains('Uyumsuz'));
      expect(host.currentSnapshot!.players, hasLength(1));
    } finally {
      await client?.close();
      await host.dispose();
    }
  }, timeout: const Timeout(Duration(seconds: 10)));
}
