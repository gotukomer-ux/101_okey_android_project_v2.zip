package com.example.classic_101_okey

import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val PERMISSION_CHANNEL = "classic_101_okey/platform_permissions"
        private const val REQUEST_LOCAL_NETWORK_PERMISSION = 7413
    }

    private var pendingPermissionResult: MethodChannel.Result? = null
    private var permissionPending = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PERMISSION_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "ensureLocalNetworkPermission") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                withLocalNetworkPermission(result) { result.success(true) }
            }
    }

    private fun withLocalNetworkPermission(result: MethodChannel.Result, action: () -> Unit) {
        // ACCESS_LOCAL_NETWORK is enforced for apps targeting API 37+ on Android 17+.
        if (Build.VERSION.SDK_INT < 37 || applicationInfo.targetSdkVersion < 37 ||
            checkSelfPermission("android.permission.ACCESS_LOCAL_NETWORK") == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            action()
            return
        }
        if (permissionPending) {
            result.error("PERMISSION_BUSY", "Yerel ağ izin isteği zaten açık.", null)
            return
        }
        permissionPending = true
        pendingPermissionResult = result
        requestPermissions(arrayOf("android.permission.ACCESS_LOCAL_NETWORK"), REQUEST_LOCAL_NETWORK_PERMISSION)
    }

    @Deprecated("Deprecated in Android API; retained for Flutter activity permission callback")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_LOCAL_NETWORK_PERMISSION) return
        permissionPending = false
        val result = pendingPermissionResult
        pendingPermissionResult = null
        if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            result?.success(true)
        } else {
            result?.error("PERMISSION_DENIED", "Aynı Wi-Fi ağı üzerinden bağlantı için Yerel ağ izni gerekli.", null)
        }
    }
}
