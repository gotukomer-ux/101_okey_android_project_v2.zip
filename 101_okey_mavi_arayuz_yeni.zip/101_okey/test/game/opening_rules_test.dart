import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/domain/meld.dart';
import 'package:classic_101_okey/domain/tile.dart';
import 'package:classic_101_okey/game/opening_rules.dart';

Tile tile(String id, TileColor color, int number) =>
    Tile.numbered(id: id, color: color, number: number);

void main() {
  const realOkey = TileFace(TileColor.yellow, 5);

  test('normal opening rejects a physical tile reused across different melds', () {
    final shared = tile('shared', TileColor.red, 5);
    final melds = [
      [
        MeldTile(tile('r4', TileColor.red, 4)),
        MeldTile(shared),
        MeldTile(tile('r6', TileColor.red, 6)),
      ],
      [
        MeldTile(shared),
        MeldTile(tile('b5', TileColor.blue, 5)),
        MeldTile(tile('k5', TileColor.black, 5)),
      ],
    ];
    expect(OpeningRules.canOpenNormally(melds, realOkey), isFalse);
  });

  test('pair opening rejects fewer than five actual pairs', () {
    final tiles = <Tile>[
      tile('a1', TileColor.red, 1), tile('a2', TileColor.red, 1),
      tile('b1', TileColor.blue, 2), tile('b2', TileColor.blue, 2),
      tile('c1', TileColor.black, 3), tile('c2', TileColor.black, 3),
      tile('d1', TileColor.yellow, 4), tile('d2', TileColor.yellow, 4),
    ];
    expect(OpeningRules.canOpenPairs(tiles), isFalse);
  });

  test('pair opening accepts five pairs but rejects a reused physical tile', () {
    final tiles = <Tile>[];
    for (var number = 1; number <= 5; number++) {
      tiles
        ..add(tile('pair-$number-a', TileColor.red, number))
        ..add(tile('pair-$number-b', TileColor.red, number));
    }
    expect(OpeningRules.canOpenPairs(tiles), isTrue);
    expect(OpeningRules.canOpenPairs([...tiles, tiles.first, tile('extra', TileColor.blue, 13)]), isFalse);
  });
}
