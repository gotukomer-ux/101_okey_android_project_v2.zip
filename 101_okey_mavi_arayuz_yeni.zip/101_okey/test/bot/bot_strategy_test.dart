import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/domain/meld.dart';
import 'package:classic_101_okey/bot/bot_strategy.dart';
import 'package:classic_101_okey/domain/tile.dart';
import 'package:classic_101_okey/game/game_engine.dart';
import 'package:classic_101_okey/game/game_state.dart';
import 'package:classic_101_okey/session/solo_game_controller.dart';

Tile t(String id, TileColor color, int number) =>
    Tile.numbered(id: id, color: color, number: number);

final indicator = t('indicator', TileColor.yellow, 4);
const realOkey = TileFace(TileColor.yellow, 5);

List<Tile> openableHand() => [
      t('r1', TileColor.red, 1),
      t('r2', TileColor.red, 2),
      t('r3', TileColor.red, 3),
      t('b5', TileColor.blue, 5),
      t('b6', TileColor.blue, 6),
      t('b7', TileColor.blue, 7),
      t('k8', TileColor.black, 8),
      t('k9', TileColor.black, 9),
      t('k10', TileColor.black, 10),
      t('y10', TileColor.yellow, 10),
      t('y11', TileColor.yellow, 11),
      t('y12', TileColor.yellow, 12),
      t('y13', TileColor.yellow, 13),
      t('r7', TileColor.red, 7),
      t('b7g', TileColor.blue, 7),
      t('k7g', TileColor.black, 7),
      t('r4', TileColor.red, 4),
      t('spare', TileColor.blue, 1),
    ];

void main() {
  group('BotStrategy', () {
    test('draws from the stock when the turn begins', () {
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [openableHand(), [t('p1', TileColor.red, 1)], [t('p2', TileColor.blue, 2)], [t('p3', TileColor.black, 3)]],
        currentSeat: 1,
        mustDraw: true,
        drawPile: [t('draw', TileColor.black, 11)],
      );
      final action = const BotStrategy().nextAction(game.viewFor(1));
      expect(action['action'], 'draw_stock');
    });

    test('finds a one-turn 101 opening and leaves a discard tile', () {
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [openableHand(), [t('p1', TileColor.red, 1)], [t('p2', TileColor.blue, 2)], [t('p3', TileColor.black, 3)]],
        currentSeat: 0,
      );
      final action = const BotStrategy(difficulty: BotDifficulty.hard).nextAction(game.viewFor(0));
      expect(action['action'], 'open_normal');
      game.applyAction(0, action);
      expect(game.viewFor(0).players.firstWhere((p) => p.seat == 0).hasOpened, isTrue);
      expect(game.handFor(0), isNotEmpty);
    });

    test('chooses five pairs when no 101 opening exists', () {
      final pairs = <Tile>[];
      for (var number = 1; number <= 5; number++) {
        pairs
          ..add(t('pair-$number-a', TileColor.red, number))
          ..add(t('pair-$number-b', TileColor.red, number));
      }
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [[...pairs, t('last', TileColor.blue, 9)], [t('p1', TileColor.red, 1)], [t('p2', TileColor.blue, 2)], [t('p3', TileColor.black, 3)]],
      );
      final action = const BotStrategy().nextAction(game.viewFor(0));
      expect(action['action'], 'open_pairs');
      expect((action['pairs'] as List), hasLength(5));
    });

    test('processes a valid tile into an existing run after opening', () {
      final hand = openableHand();
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [hand, [t('p1', TileColor.red, 1)], [t('p2', TileColor.blue, 2)], [t('p3', TileColor.black, 3)]],
      );
      final byId = {for (final tile in hand) tile.id: tile};
      game.openNormally(0, [
        ['r1', 'r2', 'r3'].map((id) => MeldTile(byId[id]!)).toList(),
        ['b5', 'b6', 'b7'].map((id) => MeldTile(byId[id]!)).toList(),
        ['k8', 'k9', 'k10'].map((id) => MeldTile(byId[id]!)).toList(),
        ['y10', 'y11', 'y12', 'y13'].map((id) => MeldTile(byId[id]!)).toList(),
        ['r7', 'b7g', 'k7g'].map((id) => MeldTile(byId[id]!)).toList(),
      ]);
      final action = const BotStrategy().nextAction(game.viewFor(0));
      expect(action['action'], 'add_to_meld');
      expect(action['tileId'], 'r4');
    });


    test('discards an isolated tile before a tile connected to a run', () {
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [
          [
            t('run-3', TileColor.red, 3),
            t('run-4', TileColor.red, 4),
            t('run-5', TileColor.red, 5),
            t('isolated-2', TileColor.blue, 2),
          ],
          [t('p1', TileColor.red, 1)],
          [t('p2', TileColor.blue, 2)],
          [t('p3', TileColor.black, 3)],
        ],
        currentSeat: 0,
        mustDraw: false,
      );
      final action = const BotStrategy(difficulty: BotDifficulty.hard).nextAction(game.viewFor(0));
      expect(action['action'], 'discard');
      expect(action['tileId'], 'isolated-2');
    });

    test('timeout discard preserves staged tiles while choosing another isolated tile', () {
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [
          [
            t('run-3', TileColor.red, 3),
            t('run-4', TileColor.red, 4),
            t('run-5', TileColor.red, 5),
            t('staged-isolated-2', TileColor.blue, 2),
            t('free-isolated-1', TileColor.yellow, 1),
          ],
          [t('p1', TileColor.red, 1)],
          [t('p2', TileColor.blue, 2)],
          [t('p3', TileColor.black, 3)],
        ],
        currentSeat: 0,
        mustDraw: false,
      );
      final discard = const BotStrategy().chooseLeastUsefulDiscard(
        game.viewFor(0), protectedTileIds: {'staged-isolated-2'});
      expect(discard.id, 'free-isolated-1');
    });

    test('takes the previous discard only when it can be used in a 101 opening', () {
      final previousDiscard = t('taken-red-4', TileColor.red, 4);
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [openableHand(), [t('p1', TileColor.red, 1)], [t('p2', TileColor.blue, 2)], [t('p3', TileColor.black, 3)]],
        discardPile: [previousDiscard],
        currentSeat: 0,
        mustDraw: true,
      );
      const bot = BotStrategy(difficulty: BotDifficulty.medium);
      final drawAction = bot.nextAction(game.viewFor(0));
      expect(drawAction['action'], 'take_discard');
      game.applyAction(0, drawAction);
      final openingAction = bot.nextAction(game.viewFor(0));
      expect(openingAction['action'], 'open_normal');
      final usedIds = (openingAction['melds'] as List)
          .expand((meld) => meld as List)
          .map((entry) => (entry as Map)['tileId'])
          .toSet();
      expect(usedIds, contains(previousDiscard.id));
      game.applyAction(0, openingAction);
      expect(game.viewFor(0).players.firstWhere((player) => player.seat == 0).hasOpened, isTrue);
    });

    test('does not take a discard that cannot be used in a first opening', () {
      final unrelated = t('unrelated-red-13', TileColor.red, 13);
      final game = GameEngine.forTesting(
        indicator: indicator,
        realOkey: realOkey,
        hands: [[t('a', TileColor.red, 1), t('b', TileColor.blue, 4), t('c', TileColor.black, 8)], [t('p1', TileColor.red, 1)], [t('p2', TileColor.blue, 2)], [t('p3', TileColor.black, 3)]],
        discardPile: [unrelated],
        currentSeat: 0,
        mustDraw: true,
        drawPile: [t('stock', TileColor.yellow, 9)],
      );
      final action = const BotStrategy().nextAction(game.viewFor(0));
      expect(action['action'], 'draw_stock');
    });

    test('offline session automatically plays all three bots after human discards', () async {
      final session = SoloGameController.newGame(
        difficulty: BotDifficulty.easy,
        random: Random(19),
        botDelay: Duration.zero,
      );
      try {
        expect(session.currentGameView.mySeat, 0);
        expect(session.currentGameView.myHand, hasLength(22));
        await session.submitGameAction({
          'action': 'discard',
          'tileId': session.currentGameView.myHand.first.id,
        });
        expect(session.currentGameView.currentSeat, 0);
        expect(session.currentGameView.mustDraw, isTrue);
        expect(session.currentGameView.players, hasLength(4));
        expect(session.currentGameView.players.skip(1).every((p) => p.name.startsWith('Bot')), isTrue);
      } finally {
        await session.dispose();
      }
    });
  });
}
