import 'dart:async';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/multiplayer/lan_transport.dart';
import 'package:classic_101_okey/multiplayer/room_coordinator.dart';

void main() {
  test('four LAN seats start one host-authoritative round and synchronize turns', () async {
    final host = RoomCoordinator(
      transport: LanTransport(port: 0),
      playerName: 'Host',
    );
    final clients = <RoomCoordinator>[];
    StreamSubscription<dynamic>? roomSubscription;

    try {
      final address = await host.host();
      final port = int.parse(address.split(':').last);
      clients.addAll(List.generate(
        3,
        (index) => RoomCoordinator(
          transport: LanTransport(port: port),
          playerName: 'Client ${index + 1}',
        ),
      ));
      final fullRoom = Completer<void>();
      roomSubscription = host.snapshots.listen((snapshot) {
        if (snapshot.isFull && !fullRoom.isCompleted) fullRoom.complete();
      });
      await Future.wait(clients.map((client) => client.join('127.0.0.1')));
      await fullRoom.future.timeout(const Duration(seconds: 5));
      expect(host.currentSnapshot!.players, hasLength(4));

      final clientViews = clients
          .map((client) => client.gameViews.first.timeout(const Duration(seconds: 5)))
          .toList();
      await host.startRoom(random: Random(42));
      final views = await Future.wait(clientViews);
      expect(views.map((view) => view.mySeat).toSet(), {1, 2, 3});
      final seatOneClient = clients[views.indexWhere((view) => view.mySeat == 1)];
      final seatTwoClient = clients[views.indexWhere((view) => view.mySeat == 2)];
      expect(views.every((view) => view.players.length == 4), isTrue);
      expect(views.every((view) => view.myHand.length == 21), isTrue);
      expect(views.every((view) => view.requiredOpeningTileId == null), isTrue);
      expect(
        views.every((view) => (view.toJson()['players'] as List)
            .every((player) => !(player as Map).containsKey('hand'))),
        isTrue,
      );

      final hostHand = host.currentGameView!.myHand;
      final seatOneTurn = seatOneClient.gameViews.firstWhere(
        (view) => view.currentSeat == 1 && view.mustDraw,
      ).timeout(const Duration(seconds: 5));
      await host.submitGameAction({'action': 'discard', 'tileId': hostHand.first.id});
      await seatOneTurn;

      final seatOneAfterDraw = seatOneClient.gameViews.firstWhere(
        (view) => view.currentSeat == 1 && !view.mustDraw && view.myHand.length == 22,
      ).timeout(const Duration(seconds: 5));
      await seatOneClient.submitGameAction({'action': 'draw_stock'});
      final drawnView = await seatOneAfterDraw;
      expect(drawnView.myHand, hasLength(22));

      final rejected = seatTwoClient.statuses.firstWhere(
        (status) => status.contains('Sıra sizde değil'),
      ).timeout(const Duration(seconds: 5));
      await expectLater(
        seatTwoClient.submitGameAction({'action': 'draw_stock'}),
        throwsA(isA<StateError>()),
      );
      expect(await rejected, contains('Sıra sizde değil'));

      final seatTwoTurn = seatTwoClient.gameViews.firstWhere(
        (view) => view.currentSeat == 2 && view.mustDraw,
      ).timeout(const Duration(seconds: 5));
      await seatOneClient.submitGameAction({
        'action': 'discard',
        'tileId': drawnView.myHand.first.id,
      });
      final seatTwoTurnView = await seatTwoTurn;
      expect(seatTwoTurnView.mySeat, 2);
      expect(seatTwoTurnView.myHand, hasLength(21));

      final seatTwoAfterDraw = seatTwoClient.gameViews.firstWhere(
        (view) => view.currentSeat == 2 && !view.mustDraw && view.myHand.length == 22,
      ).timeout(const Duration(seconds: 5));
      await seatTwoClient.submitGameAction({'action': 'draw_stock'});
      expect((await seatTwoAfterDraw).myHand, hasLength(22));
    } finally {
      await roomSubscription?.cancel();
      for (final client in clients) {
        await client.dispose();
      }
      await host.dispose();
    }
  }, timeout: const Timeout(Duration(seconds: 25)));
}
