import 'package:flutter_test/flutter_test.dart';
import 'package:classic_101_okey/domain/meld.dart';
import 'package:classic_101_okey/domain/tile.dart';
import 'package:classic_101_okey/game/opening_rules.dart';

void main() {
  const okey = TileFace(TileColor.yellow, 5);

  Tile tile(String id, TileColor color, int number) =>
      Tile.numbered(id: id, color: color, number: number);

  test('accepts same-colour consecutive run', () {
    final meld = [
      MeldTile(tile('a', TileColor.blue, 4)),
      MeldTile(tile('b', TileColor.blue, 5)),
      MeldTile(tile('c', TileColor.blue, 6)),
    ];
    expect(MeldValidator.validate(meld, okey).isValid, isTrue);
  });

  test('rejects 12-13-1 wraparound run', () {
    final meld = [
      MeldTile(tile('a', TileColor.red, 12)),
      MeldTile(tile('b', TileColor.red, 13)),
      MeldTile(tile('c', TileColor.red, 1)),
    ];
    expect(MeldValidator.validate(meld, okey).isValid, isFalse);
  });

  test('accepts three different-colour same-number group', () {
    final meld = [
      MeldTile(tile('a', TileColor.red, 9)),
      MeldTile(tile('b', TileColor.blue, 9)),
      MeldTile(tile('c', TileColor.yellow, 9)),
    ];
    expect(MeldValidator.validate(meld, okey).isValid, isTrue);
  });

  test('rejects duplicate colour in group', () {
    final meld = [
      MeldTile(tile('a', TileColor.red, 9)),
      MeldTile(tile('b', TileColor.red, 9)),
      MeldTile(tile('c', TileColor.yellow, 9)),
    ];
    expect(MeldValidator.validate(meld, okey).isValid, isFalse);
  });



  test('accepts a real okey as a represented missing tile', () {
    final meld = [
      MeldTile(tile('a', TileColor.red, 4)),
      MeldTile(tile('okey', TileColor.yellow, 5),
          representedFace: const TileFace(TileColor.red, 5)),
      MeldTile(tile('c', TileColor.red, 6)),
    ];
    expect(MeldValidator.validate(meld, okey).isValid, isTrue);
  });

  test('false joker represents the real okey face and cannot be reassigned', () {
    final valid = [
      MeldTile(tile('a', TileColor.yellow, 4)),
      const MeldTile(Tile.falseJoker(id: 'false'), representedFace: null),
      MeldTile(tile('c', TileColor.yellow, 6)),
    ];
    expect(MeldValidator.validate(valid, okey).isValid, isTrue);
    final invalid = [
      MeldTile(tile('a', TileColor.red, 4)),
      const MeldTile(Tile.falseJoker(id: 'false-2'),
          representedFace: TileFace(TileColor.red, 5)),
      MeldTile(tile('c', TileColor.red, 6)),
    ];
    expect(MeldValidator.validate(invalid, okey).isValid, isFalse);
  });

  test('opening points use the face represented by a real okey substitute', () {
    final realOkeyTile = tile('okey', TileColor.yellow, 5);
    final meld = [
      MeldTile(tile('a', TileColor.red, 6)),
      MeldTile(realOkeyTile, representedFace: const TileFace(TileColor.red, 7)),
      MeldTile(tile('c', TileColor.red, 8)),
    ];
    expect(OpeningRules.meldPoints(meld, okey), 21);
  });

  test('rejects reusing the same physical tile id', () {
    final same = tile('same', TileColor.black, 7);
    final meld = [MeldTile(same), MeldTile(same), MeldTile(tile('c', TileColor.black, 9))];
    expect(MeldValidator.validate(meld, okey).isValid, isFalse);
  });
}
