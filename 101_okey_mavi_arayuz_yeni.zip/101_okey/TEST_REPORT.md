# 101 Okey — development test report

Date: 2026-11-14  
Source version: 0.7.0+7  
Status: **SOURCE CHECKS PASS; FLUTTER BUILD / RUNTIME NOT VERIFIED**

## Summary

This source milestone keeps offline and local multiplayer on the same game engine. It retains same-Wi-Fi LAN multiplayer and optional bot-filled seats for two or three human players. The game table is now landscape-oriented and uses a clean blue palette. Opened melds appear in the centre, the player's tiles are arranged along the bottom, the draw / discard column sits beside the central table, opening controls remain in the far-right panel, and hand total and 101 opening progress are shown separately.

A 30-second local turn timer has been added. If the player has not drawn when time expires, the app draws from stock and then automatically discards the least useful tile using the existing bot heuristic. The heuristic protects jokers and useful meld connections, prefers isolated low-value tiles, and avoids tiles staged in local opening groups. Existing 101 opening, pair opening, meld processing, Wi-Fi and bot logic remain in the source.

This is not a release approval. No APK was built, and no physical-device test was possible in the current environment.

## Checks actually executed

| Check | Result | Notes |
|---|---|---|
| Python source-structure checker | PASS — 51 checks | Checks file presence and key source contracts; does not execute Dart |
| Dart lexical scan and delimiter balance | PASS | Pygments lexer over all Dart files; delimiter balance checked in all four modified Dart library files; not a Dart compiler |
| `pubspec.yaml` parse | PASS | Parsed with PyYAML |
| Android manifest XML parse | PASS | Parsed with ElementTree |
| GitHub Actions workflow YAML parse | PASS | Parsed with PyYAML |
| Shell script syntax | PASS | `bash -n` over build scripts |
| Flutter unit / integration tests | NOT RUN | `flutter` command not found |
| Dart formatter / analyzer | NOT RUN | Dart / Flutter SDK unavailable |
| Android APK build | NOT RUN | Flutter and Android SDK unavailable |
| Four-phone Wi-Fi test | NOT RUN | No physical Android devices available |

## Important unverified areas

- The modified Dart source has not been compiled by the Dart compiler. Source checks and lexical scanning are not substitutes for `flutter analyze` or `flutter test`.
- The 30-second timeout needs an Android device test in offline play and on both host and guest Wi-Fi clients.
- Wi-Fi multiplayer and host-controlled bot seats need a real Android test, including two-human-plus-two-bot and three-human-plus-one-bot tables.
- Wi-Fi TCP requires a four-device test on a router that allows clients to communicate.
- Player reconnection after a game starts is not complete; a disconnected seat remains reserved for the current hand.
- Pair-table processing, stock exhaustion and exact precedence for special finishes still require the chosen table-rule specification.

## Release gate

Do not label this source archive as a working app or distribute it as a verified APK until `flutter analyze`, all Dart tests, the APK build and physical-device tests pass.
