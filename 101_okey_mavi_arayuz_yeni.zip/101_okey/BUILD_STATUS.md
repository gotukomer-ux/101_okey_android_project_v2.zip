# Android build status

- Source structure checks: PASS (51 checks).
- Dart lexical scan: PASS (all 26 Dart files); delimiter balance: PASS (four modified library files; not a substitute for Dart analysis).
- YAML / Android manifest parse: PASS.
- Shell syntax: PASS.
- Flutter analyze: NOT RUN (Flutter SDK absent in authoring environment).
- Flutter tests: NOT RUN (Flutter SDK absent in authoring environment).
- APK build: NOT RUN (Flutter and Android SDK absent).
- Device install / gameplay: NOT RUN.

A GitHub Actions workflow and local build script are included. The workflow deliberately runs analysis and tests before producing an APK; failed checks prevent the artifact from being uploaded. Do not install or distribute an APK until that workflow succeeds and physical-device testing is completed.

- Source version: 0.7.0+7.
- UI: blue landscape table inspired by the supplied 101 Okey screenshots; tiles are arranged at the bottom, opened melds occupy the centre, the draw pile sits beside the central table, and action controls remain in the far-right panel.
- Turn clock: 30 seconds per local human turn. On expiry, if no tile has been drawn, the app draws from stock and automatically discards the least useful tile using the bot heuristic; jokers, useful connections and locally staged opening tiles are protected.
- Bluetooth: removed from the app source, manifest and native bridge.
- Local multiplayer: same Wi-Fi only; bot fill supports 2 or 3 real players.
