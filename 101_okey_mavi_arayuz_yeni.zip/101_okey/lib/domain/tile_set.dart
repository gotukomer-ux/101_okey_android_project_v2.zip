import 'dart:math';

import 'tile.dart';

class TileDeal {
  const TileDeal({
    required this.indicator,
    required this.realOkey,
    required this.hands,
    required this.drawPile,
  });

  final Tile indicator;
  final TileFace realOkey;
  final List<List<Tile>> hands;
  final List<Tile> drawPile;
}

class TileSet {
  /// Returns the next face in the indicator's colour; 13 wraps to 1.
  static TileFace realOkeyFor(Tile indicator) {
    if (!indicator.isNumbered) {
      throw ArgumentError.value(indicator, 'indicator', 'Gösterge numaralı taş olmalı.');
    }
    return TileFace(
      indicator.color!,
      indicator.number == 13 ? 1 : indicator.number! + 1,
    );
  }

  static List<Tile> create() {
    final tiles = <Tile>[];
    for (final color in TileColor.values) {
      for (var number = 1; number <= 13; number++) {
        for (var copy = 0; copy < 2; copy++) {
          tiles.add(Tile.numbered(
            id: '${color.name}-$number-${copy + 1}',
            color: color,
            number: number,
          ));
        }
      }
    }
    tiles
      ..add(const Tile.falseJoker(id: 'false-joker-1'))
      ..add(const Tile.falseJoker(id: 'false-joker-2'));
    return tiles;
  }

  static TileDeal deal({Random? random, int startingPlayer = 0}) {
    if (startingPlayer < 0 || startingPlayer > 3) {
      throw ArgumentError.value(startingPlayer, 'startingPlayer');
    }
    final rng = random ?? Random.secure();
    final tiles = create()..shuffle(rng);

    // The indicator is one of the 106 physical tiles, not an extra 107th tile.
    final indicatorIndex = tiles.indexWhere((tile) => tile.isNumbered);
    final indicator = tiles.removeAt(indicatorIndex);
    final realOkey = realOkeyFor(indicator);

    final hands = List.generate(4, (_) => <Tile>[]);
    for (var player = 0; player < 4; player++) {
      final count = player == startingPlayer ? 22 : 21;
      for (var i = 0; i < count; i++) {
        hands[player].add(tiles.removeLast());
      }
    }

    return TileDeal(
      indicator: indicator,
      realOkey: realOkey,
      hands: hands,
      drawPile: tiles,
    );
  }
}
