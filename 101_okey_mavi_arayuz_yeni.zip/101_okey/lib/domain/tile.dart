enum TileColor { red, blue, black, yellow }

enum TileKind { numbered, falseJoker }

extension IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

class Tile {
  const Tile.numbered({required this.id, required this.color, required this.number})
      : kind = TileKind.numbered;

  const Tile.falseJoker({required this.id})
      : kind = TileKind.falseJoker,
        color = null,
        number = null;

  final String id;
  final TileKind kind;
  final TileColor? color;
  final int? number;

  bool get isNumbered => kind == TileKind.numbered;

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'color': color?.name,
        'number': number,
      };

  factory Tile.fromJson(Map<String, dynamic> json) {
    final id = json['id'];
    final kind = json['kind'];
    if (id is! String || id.isEmpty || kind is! String) {
      throw const FormatException('Taş kimliği veya türü geçersiz.');
    }
    if (kind == TileKind.falseJoker.name) return Tile.falseJoker(id: id);
    if (kind != TileKind.numbered.name) {
      throw const FormatException('Bilinmeyen taş türü.');
    }
    final colorName = json['color'];
    final number = json['number'];
    final color = TileColor.values.where((value) => value.name == colorName).firstOrNull;
    if (color == null || number is! int || number < 1 || number > 13) {
      throw const FormatException('Numaralı taşın rengi veya sayısı geçersiz.');
    }
    return Tile.numbered(id: id, color: color, number: number);
  }

  @override
  String toString() => isNumbered ? '${color!.name}-$number#$id' : 'false-joker#$id';
}

class TileFace {
  const TileFace(this.color, this.number);
  final TileColor color;
  final int number;

  Map<String, dynamic> toJson() => {'color': color.name, 'number': number};

  factory TileFace.fromJson(Map<String, dynamic> json) {
    final colorName = json['color'];
    final number = json['number'];
    final color = TileColor.values.where((value) => value.name == colorName).firstOrNull;
    if (color == null || number is! int || number < 1 || number > 13) {
      throw const FormatException('Taş yüzü geçersiz.');
    }
    return TileFace(color, number);
  }

  @override
  bool operator ==(Object other) =>
      other is TileFace && other.color == color && other.number == number;

  @override
  int get hashCode => Object.hash(color, number);

  @override
  String toString() => '${color.name}-$number';
}
