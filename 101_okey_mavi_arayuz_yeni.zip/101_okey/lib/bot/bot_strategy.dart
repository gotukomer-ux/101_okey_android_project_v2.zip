import '../domain/meld.dart';
import '../domain/tile.dart';
import '../game/game_state.dart';
import '../game/opening_rules.dart';

enum BotDifficulty { easy, medium, hard }

class BotStrategy {
  const BotStrategy({this.difficulty = BotDifficulty.medium});

  final BotDifficulty difficulty;

  /// Returns one legal next action. The caller applies it to the authoritative
  /// GameEngine and asks again using a fresh view until the bot discards.
  Map<String, dynamic> nextAction(GameView view) {
    if (view.roundFinished) throw StateError('El tamamlandı; bot hamle yapamaz.');
    if (view.currentSeat != view.mySeat) {
      throw StateError('Botun sırası değil.');
    }
    if (view.mustDraw) {
      if (_shouldTakeDiscard(view)) return const {'action': 'take_discard'};
      return const {'action': 'draw_stock'};
    }

    final player = view.players.firstWhere((item) => item.seat == view.mySeat);
    if (!player.hasOpened) {
      final requiredId = view.requiredOpeningTileId;
      final normal = _findNormalOpening(view, requiredTileId: requiredId);
      if (normal != null) {
        return {
          'action': 'open_normal',
          'melds': normal.map((meld) => meld.map(_meldTileJson).toList()).toList(),
        };
      }
      final pairs = _findPairs(view.myHand);
      if (pairs.length >= 5 &&
          (requiredId == null || pairs.any((pair) => pair.contains(requiredId)))) {
        return {'action': 'open_pairs', 'pairs': pairs};
      }
      if (requiredId != null) {
        throw StateError('Bot, yandan aldığı taşı kullanarak geçerli açılış oluşturamadı.');
      }
    } else if (player.openingType == OpeningType.normal && view.myHand.length > 1) {
      final addition = _findMeldAddition(view);
      if (addition != null) return addition;
    }

    if (view.myHand.isEmpty) throw StateError('Botun elinde atılacak taş yok.');
    return {'action': 'discard', 'tileId': _chooseDiscard(view).id};
  }

  Map<String, dynamic> _meldTileJson(MeldTile item) => {
        'tileId': item.tile.id,
        if (item.representedFace != null)
          'representedFace': item.representedFace!.toJson(),
      };

  bool _shouldTakeDiscard(GameView view) {
    if (view.discardPile.isEmpty) return false;
    final top = view.discardPile.last;
    final candidateHand = [...view.myHand, top];
    final player = view.players.firstWhere((item) => item.seat == view.mySeat);
    if (!player.hasOpened) {
      final normal = _findNormalOpening(
        view,
        hand: candidateHand,
        requiredTileId: top.id,
      );
      if (normal != null) return true;
      final pairs = _findPairs(candidateHand);
      return pairs.length >= 5 && pairs.any((pair) => pair.contains(top.id));
    }
    if (player.openingType == OpeningType.normal && view.myHand.length > 1) {
      final addition = _findMeldAddition(
        view, hand: candidateHand, requiredTileId: top.id);
      return addition != null && addition['tileId'] == top.id;
    }
    return false;
  }

  List<List<MeldTile>>? _findNormalOpening(
    GameView view, {
    List<Tile>? hand,
    String? requiredTileId,
  }) {
    final candidates = _openingCandidates(hand ?? view.myHand, view.realOkey);
    if (candidates.isEmpty) return null;

    final orderedLists = <List<_MeldCandidate>>[];
    orderedLists.add([...candidates]..sort((a, b) => b.points.compareTo(a.points)));
    if (difficulty != BotDifficulty.easy) {
      orderedLists.add([...candidates]..sort((a, b) {
        final score = (b.points * 100 ~/ b.tiles.length)
            .compareTo(a.points * 100 ~/ a.tiles.length);
        return score != 0 ? score : b.points.compareTo(a.points);
      }));
      orderedLists.add([...candidates]..sort((a, b) {
        final size = b.tiles.length.compareTo(a.tiles.length);
        return size != 0 ? size : b.points.compareTo(a.points);
      }));
    }
    if (difficulty == BotDifficulty.hard) {
      final result = _searchDisjoint(
        candidates,
        maxTileCount: (hand ?? view.myHand).length - 1,
        nodeBudget: 24000,
        requiredTileId: requiredTileId,
      );
      if (result != null) return result.map((candidate) => candidate.tiles).toList();
    }

    for (final ordered in orderedLists) {
      final used = <String>{};
      final chosen = <_MeldCandidate>[];
      var points = 0;
      for (final candidate in ordered) {
        if (candidate.ids.any(used.contains) ||
            used.length + candidate.ids.length >= (hand ?? view.myHand).length) {
          continue;
        }
        used.addAll(candidate.ids);
        chosen.add(candidate);
        points += candidate.points;
        if (points >= 101 && (requiredTileId == null || used.contains(requiredTileId))) {
          return chosen.map((candidate) => candidate.tiles).toList();
        }
      }
    }
    return null;
  }

  List<_MeldCandidate> _openingCandidates(List<Tile> hand, TileFace realOkey) {
    final candidates = <_MeldCandidate>[];
    final signatures = <String>{};

    void addPattern(List<TileFace> faces) {
      // A physical face may have two copies. Generate a few deterministic
      // copy-allocation variants so one candidate does not monopolise the
      // first copy needed by another disjoint meld.
      for (var variant = 0; variant < 4; variant++) {
        final assigned = _assignPattern(faces, hand, realOkey, variant);
        if (assigned == null) continue;
        final validation = MeldValidator.validate(assigned, realOkey);
        if (!validation.isValid) continue;
        final signature = '${validation.type!.name}:${assigned.map((item) =>
            '${item.tile.id}@${item.representedFace?.color.name ?? '-'}-${item.representedFace?.number ?? 0}').join('|')}';
        if (!signatures.add(signature)) continue;
        candidates.add(_MeldCandidate(
          tiles: assigned,
          points: OpeningRules.meldPoints(assigned, realOkey),
        ));
      }
    }

    for (final color in TileColor.values) {
      for (var start = 1; start <= 11; start++) {
        for (var end = start + 2; end <= 13; end++) {
          addPattern([
            for (var number = start; number <= end; number++) TileFace(color, number),
          ]);
        }
      }
    }

    for (var number = 1; number <= 13; number++) {
      final colors = TileColor.values;
      for (var a = 0; a < colors.length; a++) {
        for (var b = a + 1; b < colors.length; b++) {
          for (var c = b + 1; c < colors.length; c++) {
            addPattern([TileFace(colors[a], number), TileFace(colors[b], number), TileFace(colors[c], number)]);
            addPattern([
              TileFace(colors[0], number),
              TileFace(colors[1], number),
              TileFace(colors[2], number),
              TileFace(colors[3], number),
            ]);
          }
        }
      }
    }
    return candidates;
  }

  List<MeldTile>? _assignPattern(
      List<TileFace> faces, List<Tile> hand, TileFace realOkey, int variant) {
    final remaining = [...hand];
    final assigned = <MeldTile>[];
    var slot = 0;
    for (final face in faces) {
      final selector = (variant >> (slot % 2)) & 1;
      slot++;
      Tile? selected;
      // Use a naturally matching numbered tile before spending a joker.
      final exact = remaining.where((tile) => tile.isNumbered &&
          tile.color == face.color && tile.number == face.number).toList();
      if (exact.isNotEmpty) selected = exact[selector % exact.length];
      if (selected != null) {
        remaining.removeWhere((tile) => tile.id == selected!.id);
        assigned.add(MeldTile(selected));
        continue;
      }

      // A false joker has only the real okey's face; it cannot represent any
      // other tile. A true okey may represent any face in this candidate.
      if (face == realOkey) {
        final falseJokers = remaining.where((tile) => tile.kind == TileKind.falseJoker).toList();
        if (falseJokers.isNotEmpty) selected = falseJokers[selector % falseJokers.length];
      }
      if (selected != null) {
        remaining.removeWhere((tile) => tile.id == selected!.id);
        assigned.add(MeldTile(selected));
        continue;
      }
      final trueJokers = remaining.where((tile) => tile.isNumbered &&
          tile.color == realOkey.color && tile.number == realOkey.number).toList();
      if (trueJokers.isNotEmpty) selected = trueJokers[selector % trueJokers.length];
      if (selected == null) return null;
      remaining.removeWhere((tile) => tile.id == selected!.id);
      assigned.add(MeldTile(selected, representedFace: face));
    }
    return assigned;
  }

  List<List<String>> _findPairs(List<Tile> hand) {
    final buckets = <String, List<Tile>>{};
    for (final tile in hand) {
      if (!tile.isNumbered) continue;
      final key = '${tile.color!.name}-${tile.number}';
      buckets.putIfAbsent(key, () => []).add(tile);
    }
    final pairs = <List<String>>[];
    for (final tiles in buckets.values) {
      if (tiles.length >= 2) pairs.add([tiles[0].id, tiles[1].id]);
    }
    final maximumPairs = (hand.length - 1) ~/ 2;
    return pairs.take(maximumPairs).toList();
  }

  Map<String, dynamic>? _findMeldAddition(
    GameView view, {List<Tile>? hand, String? requiredTileId}) {
    for (final tile in hand ?? view.myHand) {
      if (requiredTileId != null && tile.id != requiredTileId) continue;
      final isTrueOkey = tile.isNumbered &&
          tile.color == view.realOkey.color && tile.number == view.realOkey.number;
      final representations = isTrueOkey
          ? [
              for (final color in TileColor.values)
                for (var number = 1; number <= 13; number++) TileFace(color, number),
            ]
          : <TileFace?>[null];
      for (final meld in view.melds) {
        if (meld.type == GameMeldType.pair) continue;
        for (final face in representations) {
          final addition = MeldTile(tile, representedFace: face);
          final validation = MeldValidator.validate([...meld.tiles, addition], view.realOkey);
          if (!validation.isValid) continue;
          final expectedType = meld.type == GameMeldType.run ? MeldType.run : MeldType.group;
          if (validation.type != expectedType) continue;
          return {
            'action': 'add_to_meld',
            'meldId': meld.id,
            'tileId': tile.id,
            if (face != null) 'representedFace': face.toJson(),
          };
        }
      }
    }
    return null;
  }

  /// Chooses the least useful tile for a timed-out human turn as well.
  Tile chooseLeastUsefulDiscard(
    GameView view, {
    Set<String> protectedTileIds = const <String>{},
  }) {
    final candidates = view.myHand.where((tile) => !protectedTileIds.contains(tile.id)).toList();
    return _chooseDiscard(view, handOverride: candidates.isEmpty ? view.myHand : candidates);
  }

  Tile _chooseDiscard(GameView view, {List<Tile>? handOverride}) {
    final hand = handOverride ?? view.myHand;
    var chosen = hand.first;
    var bestUtility = double.infinity;
    for (final tile in hand) {
      var utility = _tileUtility(tile, hand, view.realOkey);
      if (difficulty == BotDifficulty.hard) {
        // The hard bot is especially careful not to break near-complete melds.
        utility += _futureMeldPotential(tile, hand) * 2.0;
      }
      if (utility < bestUtility) {
        bestUtility = utility;
        chosen = tile;
      }
    }
    return chosen;
  }

  double _futureMeldPotential(Tile discard, List<Tile> hand) {
    if (!discard.isNumbered) return 100;
    var potential = 0.0;
    final others = hand.where((tile) => tile.id != discard.id && tile.isNumbered).toList();
    final sameColor = others.where((tile) => tile.color == discard.color).toList();
    for (final first in sameColor) {
      for (final second in sameColor) {
        if (first.id == second.id) continue;
        final numbers = [discard.number!, first.number!, second.number!]..sort();
        if (numbers[1] - numbers[0] == 1 && numbers[2] - numbers[1] == 1) {
          potential += 2.5;
        } else if (numbers[2] - numbers[0] <= 3) {
          potential += 0.45;
        }
      }
    }
    final sameNumber = others.where((tile) => tile.number == discard.number && tile.color != discard.color).length;
    if (sameNumber >= 2) potential += 2.0;
    return potential;
  }

  double _tileUtility(Tile tile, List<Tile> hand, TileFace realOkey) {
    // Keep both joker types and the physical real okey whenever possible.
    if (tile.kind == TileKind.falseJoker) return 10000;
    if (tile.isNumbered && tile.color == realOkey.color && tile.number == realOkey.number) return 11000;

    var connections = 0.0;
    if (tile.isNumbered) {
      for (final other in hand) {
        if (other.id == tile.id || !other.isNumbered) continue;
        if (other.color == tile.color) {
          final distance = (other.number! - tile.number!).abs();
          if (distance == 1) connections += 3.0;
          if (distance == 2) connections += 1.2;
        }
        if (other.number == tile.number && other.color != tile.color) {
          connections += 2.0;
        }
      }
    }
    // A connected/usable tile is protected. Among equally unhelpful isolated
    // tiles, the bot sheds the lower printed number as requested.
    return connections * 100.0 + (tile.number ?? 0);
  }

  List<_MeldCandidate>? _searchDisjoint(
      List<_MeldCandidate> candidates, {
        required int maxTileCount,
        required int nodeBudget,
        String? requiredTileId,
      }) {
    final ordered = [...candidates]..sort((a, b) => b.points.compareTo(a.points));
    var visited = 0;
    List<_MeldCandidate>? solution;
    void search(int start, Set<String> used, List<_MeldCandidate> chosen, int points) {
      if (solution != null || visited++ >= nodeBudget) return;
      if (points >= 101 &&
          (requiredTileId == null || used.contains(requiredTileId))) {
        solution = [...chosen];
        return;
      }
      if (chosen.length >= 8) return;
      for (var index = start; index < ordered.length; index++) {
        final candidate = ordered[index];
        if (candidate.ids.any(used.contains) || used.length + candidate.ids.length > maxTileCount) continue;
        final nextUsed = {...used, ...candidate.ids};
        search(index + 1, nextUsed, [...chosen, candidate], points + candidate.points);
        if (solution != null || visited >= nodeBudget) return;
      }
    }

    search(0, <String>{}, <_MeldCandidate>[], 0);
    return solution;
  }
}

class _MeldCandidate {
  _MeldCandidate({required this.tiles, required this.points})
      : ids = tiles.map((item) => item.tile.id).toSet();

  final List<MeldTile> tiles;
  final Set<String> ids;
  final int points;
}
