import '../domain/meld.dart';
import '../domain/tile.dart';

class OpeningRules {
  static int meldPoints(List<MeldTile> meld, TileFace realOkey) {
    var total = 0;
    for (final item in meld) {
      final tile = item.tile;
      if (tile.isNumbered) {
        // A real okey used as a substitute scores as the represented tile.
        total += item.representedFace?.number ?? tile.number!;
      } else {
        // The false joker always has the face of the real okey for this hand.
        total += realOkey.number;
      }
    }
    return total;
  }

  static bool canOpenNormally(List<List<MeldTile>> melds, TileFace realOkey) {
    if (melds.isEmpty) return false;
    final ids = melds.expand((meld) => meld.map((item) => item.tile.id)).toList();
    if (ids.toSet().length != ids.length) return false;
    return melds.every((meld) => MeldValidator.validate(meld, realOkey).isValid) &&
        melds.fold<int>(0, (sum, meld) => sum + meldPoints(meld, realOkey)) >= 101;
  }

  static bool canOpenPairs(List<Tile> tiles) {
    if (tiles.length < 10 || tiles.length.isOdd) return false;
    if (tiles.map((tile) => tile.id).toSet().length != tiles.length ||
        tiles.any((tile) => !tile.isNumbered)) {
      return false;
    }
    final counts = <String, int>{};
    for (final tile in tiles) {
      final key = '${tile.color!.name}-${tile.number}';
      counts.update(key, (value) => value + 1, ifAbsent: () => 1);
    }
    // Count actual two-tile pairs; a physical tile cannot be re-used.
    final pairCount = counts.values.fold<int>(0, (sum, count) => sum + count ~/ 2);
    return pairCount >= 5;
  }
}
