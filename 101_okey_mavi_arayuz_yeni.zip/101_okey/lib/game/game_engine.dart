import 'dart:math';

import '../domain/meld.dart';
import '../domain/tile.dart';
import '../domain/tile_set.dart';
import 'game_state.dart';
import 'opening_rules.dart';

class ScoreConfig {
  const ScoreConfig({
    this.winnerBase = 101,
    this.unopenedPenalty = 202,
    this.normalMultiplier = 1,
    this.okeyMultiplier = 2,
    this.pairsMultiplier = 2,
    this.handMultiplier = 2,
  });

  final int winnerBase;
  final int unopenedPenalty;
  final int normalMultiplier;
  final int okeyMultiplier;
  final int pairsMultiplier;
  final int handMultiplier;

  int multiplierFor(WinType type) {
    switch (type) {
      case WinType.normal:
        return normalMultiplier;
      case WinType.okey:
        return okeyMultiplier;
      case WinType.pairs:
        return pairsMultiplier;
      case WinType.hand:
        return handMultiplier;
    }
  }
}

class _PlayerRound {
  _PlayerRound({required this.id, required this.name, required this.seat, required this.hand, this.totalScore = 0});

  final String id;
  final String name;
  final int seat;
  final List<Tile> hand;
  bool hasOpened = false;
  OpeningType? openingType;
  int totalScore = 0;
}

/// Host-authoritative, deterministic 101 Okey round engine.
/// The server/host owns the full state; [viewFor] exposes only one player's hand.
class GameEngine {
  GameEngine._({
    required this.gameId,
    required this.roundNumber,
    required this.indicator,
    required this.realOkey,
    required List<_PlayerRound> players,
    required List<Tile> drawPile,
    required this.scoreConfig,
    required int startingSeat,
  })  : _players = players,
        _drawPile = drawPile,
        _currentSeat = startingSeat,
        _mustDraw = false;

  /// Builds a controlled state for deterministic rule tests and replay tooling.
  /// Production game creation must use [GameEngine.start].
  factory GameEngine.forTesting({
    required Tile indicator,
    required TileFace realOkey,
    required List<List<Tile>> hands,
    List<Tile> drawPile = const [],
    List<Tile> discardPile = const [],
    int currentSeat = 0,
    bool mustDraw = false,
    ScoreConfig scoreConfig = const ScoreConfig(),
  }) {
    if (hands.length != 4 || currentSeat < 0 || currentSeat > 3) {
      throw ArgumentError('Test oyunu dört el ve geçerli bir sıra koltuğu gerektirir.');
    }
    final allTiles = <Tile>[indicator, ...hands.expand((hand) => hand), ...drawPile, ...discardPile];
    if (allTiles.map((tile) => tile.id).toSet().length != allTiles.length) {
      throw ArgumentError('Test durumunda fiziksel taş kimlikleri benzersiz olmalı.');
    }
    final players = List.generate(
      4,
      (seat) => _PlayerRound(
        id: 'test-player-$seat',
        name: 'Oyuncu ${seat + 1}',
        seat: seat,
        hand: List<Tile>.of(hands[seat]),
      ),
    );
    final engine = GameEngine._(
      gameId: 'test-game',
      roundNumber: 1,
      indicator: indicator,
      realOkey: realOkey,
      players: players,
      drawPile: List<Tile>.of(drawPile),
      scoreConfig: scoreConfig,
      startingSeat: currentSeat,
    );
    engine._mustDraw = mustDraw;
    engine._discardPile.addAll(discardPile);
    return engine;
  }

  factory GameEngine.start({
    required List<String> playerNames,
    List<String>? playerIds,
    int startingSeat = 0,
    int roundNumber = 1,
    Random? random,
    ScoreConfig scoreConfig = const ScoreConfig(),
    Map<String, int> initialScores = const {},
  }) {
    if (playerNames.length != 4 || startingSeat < 0 || startingSeat > 3) {
      throw ArgumentError('Oyun tam dört oyuncuyla ve 0–3 başlangıç koltuğuyla kurulmalı.');
    }
    final ids = playerIds ?? List.generate(4, (index) => 'seat-$index');
    if (ids.length != 4 || ids.toSet().length != 4 || ids.any((id) => id.trim().isEmpty)) {
      throw ArgumentError('Dört benzersiz oyuncu kimliği gerekli.');
    }
    final rng = random ?? Random.secure();
    final deal = TileSet.deal(random: rng, startingPlayer: startingSeat);
    final players = List.generate(
      4,
      (seat) => _PlayerRound(
        id: ids[seat],
        name: playerNames[seat].trim().isEmpty ? 'Oyuncu ${seat + 1}' : playerNames[seat].trim(),
        seat: seat,
        hand: List<Tile>.of(deal.hands[seat]),
        totalScore: initialScores[ids[seat]] ?? 0,
      ),
    );
    final suffix = List<int>.generate(8, (_) => rng.nextInt(16))
        .map((value) => value.toRadixString(16))
        .join();
    return GameEngine._(
      gameId: '${DateTime.now().microsecondsSinceEpoch}-$suffix',
      roundNumber: roundNumber,
      indicator: deal.indicator,
      realOkey: deal.realOkey,
      players: players,
      drawPile: List<Tile>.of(deal.drawPile),
      scoreConfig: scoreConfig,
      startingSeat: startingSeat,
    );
  }

  final String gameId;
  final int roundNumber;
  final Tile indicator;
  final TileFace realOkey;
  final ScoreConfig scoreConfig;
  final List<_PlayerRound> _players;
  final List<Tile> _drawPile;
  final List<Tile> _discardPile = [];
  final List<GameMeld> _melds = [];

  int _currentSeat;
  bool _mustDraw;
  bool _roundFinished = false;
  int? _winnerSeat;
  WinType? _winType;
  int _turnNumber = 0;
  int _nextMeldId = 1;
  String? _requiredOpeningTileId;
  bool _openedThisTurn = false;
  final Map<int, int> _scoreDeltas = {};

  int get currentSeat => _currentSeat;
  bool get mustDraw => _mustDraw;
  bool get isFinished => _roundFinished;
  int get drawPileCount => _drawPile.length;
  int get turnNumber => _turnNumber;
  List<Tile> handFor(int seat) => List.unmodifiable(_player(seat).hand);

  void drawFromStock(int seat) {
    _assertTurn(seat);
    if (!_mustDraw) throw StateError('Bu turda zaten taş çekildi.');
    if (_drawPile.isEmpty) throw StateError('Kapalı taş destesi boş.');
    _player(seat).hand.add(_drawPile.removeLast());
    _mustDraw = false;
  }

  void takeDiscard(int seat) {
    _assertTurn(seat);
    if (!_mustDraw) throw StateError('Bu turda zaten taş alındı.');
    if (_discardPile.isEmpty) throw StateError('Yandan alınabilecek taş yok.');
    final tile = _discardPile.removeLast();
    _player(seat).hand.add(tile);
    _mustDraw = false;
    if (!_player(seat).hasOpened) _requiredOpeningTileId = tile.id;
  }

  void openNormally(int seat, List<List<MeldTile>> proposedMelds) {
    _assertCanPlay(seat);
    final player = _player(seat);
    if (player.hasOpened) throw StateError('Oyuncu daha önce el açmış.');
    if (proposedMelds.isEmpty) throw StateError('Açılış için en az bir per gerekli.');

    final ids = <String>[];
    var points = 0;
    final validated = <GameMeld>[];
    for (final proposed in proposedMelds) {
      final result = MeldValidator.validate(proposed, realOkey);
      if (!result.isValid) throw StateError(result.error ?? 'Geçersiz per.');
      points += OpeningRules.meldPoints(proposed, realOkey);
      ids.addAll(proposed.map((item) => item.tile.id));
      validated.add(GameMeld(
        id: 'meld-${_nextMeldId++}',
        ownerSeat: seat,
        type: result.type == MeldType.run ? GameMeldType.run : GameMeldType.group,
        tiles: List.unmodifiable(proposed),
      ));
    }
    _validateHandTileIds(player, ids);
    if (ids.toSet().length != ids.length) throw StateError('Aynı taş birden fazla per içinde kullanılamaz.');
    if (points < 101) throw StateError('Normal açılış için en az 101 puan gerekli.');
    if (player.hand.length - ids.length < 1) {
      throw StateError('Açılıştan sonra son atış için elinizde en az bir taş kalmalı.');
    }
    _ensureRequiredDiscardUsed(ids);

    _removeHandTiles(player, ids);
    player.hasOpened = true;
    player.openingType = OpeningType.normal;
    _openedThisTurn = true;
    _melds.addAll(validated);
    _requiredOpeningTileId = null;
  }

  void openPairs(int seat, List<List<String>> proposedPairs) {
    _assertCanPlay(seat);
    final player = _player(seat);
    if (player.hasOpened) throw StateError('Oyuncu daha önce el açmış.');
    if (proposedPairs.length < 5) throw StateError('Çift açmak için en az beş çift gerekli.');

    final ids = <String>[];
    final validated = <GameMeld>[];
    for (final pair in proposedPairs) {
      if (pair.length != 2) throw StateError('Her çift tam iki taştan oluşmalı.');
      final first = _findHandTile(player, pair[0]);
      final second = _findHandTile(player, pair[1]);
      if (!first.isNumbered || !second.isNumbered ||
          first.color != second.color || first.number != second.number) {
        throw StateError('Çift aynı renk ve aynı sayıdaki iki fiziksel taş olmalı.');
      }
      ids.addAll(pair);
      validated.add(GameMeld(
        id: 'meld-${_nextMeldId++}',
        ownerSeat: seat,
        type: GameMeldType.pair,
        tiles: [MeldTile(first), MeldTile(second)],
      ));
    }
    if (ids.toSet().length != ids.length) throw StateError('Bir taş birden fazla çiftte kullanılamaz.');
    _validateHandTileIds(player, ids);
    if (player.hand.length - ids.length < 1) {
      throw StateError('Çift açılışından sonra son atış için en az bir taş kalmalı.');
    }
    _ensureRequiredDiscardUsed(ids);

    _removeHandTiles(player, ids);
    player.hasOpened = true;
    player.openingType = OpeningType.pairs;
    _openedThisTurn = true;
    _melds.addAll(validated);
    _requiredOpeningTileId = null;
  }

  void addToMeld(int seat, String meldId, MeldTile addition) {
    _assertCanPlay(seat);
    final player = _player(seat);
    if (!player.hasOpened) throw StateError('Taş işlemek için önce el açılmalı.');
    if (player.openingType == OpeningType.pairs) {
      throw StateError('Çift açan oyuncu için taş işleme kuralı bu sürümde kapalı.');
    }
    if (player.hand.length <= 1) {
      throw StateError('Son atış taşınızı masaya işleyemezsiniz.');
    }
    _findHandTile(player, addition.tile.id);
    final index = _melds.indexWhere((meld) => meld.id == meldId);
    if (index < 0) throw StateError('İşlenecek per bulunamadı.');
    final target = _melds[index];
    if (target.type == GameMeldType.pair) throw StateError('Bu sürümde çiftlere taş işleme desteklenmiyor.');
    final updatedTiles = [...target.tiles, addition];
    final validation = MeldValidator.validate(updatedTiles, realOkey);
    if (!validation.isValid) throw StateError(validation.error ?? 'İşleme sonrası per geçersiz.');
    final type = validation.type == MeldType.run ? GameMeldType.run : GameMeldType.group;
    if (type != target.type) throw StateError('İşleme mevcut perin türünü değiştiremez.');
    _melds[index] = GameMeld(
      id: target.id,
      ownerSeat: target.ownerSeat,
      type: target.type,
      tiles: List.unmodifiable(updatedTiles),
    );
    player.hand.removeWhere((tile) => tile.id == addition.tile.id);
  }

  void discard(int seat, String tileId) {
    _assertCanPlay(seat);
    final player = _player(seat);
    if (_requiredOpeningTileId != null) {
      throw StateError('Yandan aldığınız taşı bu tur açılışta kullanmalısınız.');
    }
    final tile = _findHandTile(player, tileId);
    player.hand.removeWhere((candidate) => candidate.id == tileId);
    _discardPile.add(tile);

    if (player.hand.isEmpty) {
      _finishRound(seat, tile);
      return;
    }

    _currentSeat = (_currentSeat + 1) % 4;
    _mustDraw = true;
    _turnNumber++;
    _openedThisTurn = false;
  }

  /// Applies a network action after the host has resolved the sender's seat.
  /// Every client is treated as untrusted; all IDs and rules are revalidated here.
  void applyAction(int seat, Map<String, dynamic> action) {
    final type = action['action'];
    switch (type) {
      case 'draw_stock':
        drawFromStock(seat);
        return;
      case 'take_discard':
        takeDiscard(seat);
        return;
      case 'discard':
        final tileId = action['tileId'];
        if (tileId is! String) throw const FormatException('Atılacak taş kimliği eksik.');
        discard(seat, tileId);
        return;
      case 'open_normal':
        final rawMelds = action['melds'];
        if (rawMelds is! List) throw const FormatException('Açılış perleri eksik.');
        openNormally(seat, rawMelds.map((raw) => _parseMeld(raw, seat)).toList());
        return;
      case 'open_pairs':
        final rawPairs = action['pairs'];
        if (rawPairs is! List) throw const FormatException('Çift listesi eksik.');
        final pairs = rawPairs.map((raw) {
          if (raw is! List || raw.any((id) => id is! String)) {
            throw const FormatException('Çift taş kimlikleri geçersiz.');
          }
          return raw.cast<String>();
        }).toList();
        openPairs(seat, pairs);
        return;
      case 'add_to_meld':
        final meldId = action['meldId'];
        final tileId = action['tileId'];
        if (meldId is! String || tileId is! String) {
          throw const FormatException('İşleme bilgisi eksik.');
        }
        final rawFace = action['representedFace'];
        if (rawFace != null && rawFace is! Map) {
          throw const FormatException('Okey temsil yüzü geçersiz.');
        }
        final face = rawFace is Map
            ? TileFace.fromJson(Map<String, dynamic>.from(rawFace))
            : null;
        addToMeld(seat, meldId, MeldTile(_findHandTile(_player(seat), tileId), representedFace: face));
        return;
      default:
        throw const FormatException('Bilinmeyen oyun hamlesi.');
    }
  }

  GameView viewFor(int seat) {
    final player = _player(seat);
    return GameView(
      gameId: gameId,
      roundNumber: roundNumber,
      mySeat: seat,
      currentSeat: _currentSeat,
      indicator: indicator,
      realOkey: realOkey,
      myHand: List.unmodifiable(player.hand),
      discardPile: List.unmodifiable(_discardPile),
      drawPileCount: _drawPile.length,
      players: _players
          .map((other) => PlayerGameSummary(
                id: other.id,
                name: other.name,
                seat: other.seat,
                handCount: other.hand.length,
                hasOpened: other.hasOpened,
                openingType: other.openingType,
                totalScore: other.totalScore,
              ))
          .toList(),
      melds: List.unmodifiable(_melds),
      mustDraw: seat == _currentSeat && _mustDraw,
      requiredOpeningTileId: seat == _currentSeat ? _requiredOpeningTileId : null,
      roundFinished: _roundFinished,
      winnerSeat: _winnerSeat,
      winType: _winType,
      scoreDeltas: Map.unmodifiable(_scoreDeltas),
    );
  }

  void _finishRound(int seat, Tile lastDiscard) {
    _roundFinished = true;
    _winnerSeat = seat;
    if (_isTrueOkey(lastDiscard)) {
      _winType = WinType.okey;
    } else if (_player(seat).openingType == OpeningType.pairs) {
      _winType = WinType.pairs;
    } else if (_turnNumber == 0 && _openedThisTurn) {
      _winType = WinType.hand;
    } else {
      _winType = WinType.normal;
    }
    final multiplier = scoreConfig.multiplierFor(_winType!);
    for (final player in _players) {
      if (player.seat == seat) {
        _scoreDeltas[player.seat] = -scoreConfig.winnerBase * multiplier;
      } else if (!player.hasOpened) {
        _scoreDeltas[player.seat] = scoreConfig.unopenedPenalty * multiplier;
      } else {
        final value = player.hand.fold<int>(0, (sum, tile) => sum + _penaltyValue(tile));
        _scoreDeltas[player.seat] = value * multiplier;
      }
      player.totalScore += _scoreDeltas[player.seat]!;
    }
  }

  int _penaltyValue(Tile tile) {
    // Remaining tiles score their face value. The false joker represents the
    // real okey face for this hand; it is not automatically worth 101 points.
    if (tile.kind == TileKind.falseJoker) return realOkey.number;
    return tile.number!;
  }

  bool _isTrueOkey(Tile tile) =>
      tile.isNumbered && tile.color == realOkey.color && tile.number == realOkey.number;


  List<MeldTile> _parseMeld(Object? raw, int seat) {
    if (raw is! List || raw.isEmpty) throw const FormatException('Per listesi geçersiz.');
    return raw.map((entry) {
      if (entry is! Map) throw const FormatException('Per taşı verisi geçersiz.');
      final data = Map<String, dynamic>.from(entry);
      final tileId = data['tileId'];
      if (tileId is! String) throw const FormatException('Per taşı kimliği eksik.');
      final rawFace = data['representedFace'];
      if (rawFace != null && rawFace is! Map) {
        throw const FormatException('Okey temsil yüzü geçersiz.');
      }
      final face = rawFace is Map
          ? TileFace.fromJson(Map<String, dynamic>.from(rawFace))
          : null;
      return MeldTile(_findHandTile(_player(seat), tileId), representedFace: face);
    }).toList();
  }

  void _ensureRequiredDiscardUsed(List<String> ids) {
    final requiredId = _requiredOpeningTileId;
    if (requiredId != null && !ids.contains(requiredId)) {
      throw StateError('Yandan aldığınız taş açılışta kullanılmalı.');
    }
  }

  void _validateHandTileIds(_PlayerRound player, List<String> ids) {
    if (ids.toSet().length != ids.length) {
      throw StateError('Aynı fiziksel taş birden fazla kullanılamaz.');
    }
    for (final id in ids) {
      _findHandTile(player, id);
    }
  }

  void _removeHandTiles(_PlayerRound player, List<String> ids) {
    final selected = ids.toSet();
    player.hand.removeWhere((tile) => selected.contains(tile.id));
  }

  Tile _findHandTile(_PlayerRound player, String id) {
    for (final tile in player.hand) {
      if (tile.id == id) return tile;
    }
    throw StateError('Bu taş oyuncunun elinde bulunmuyor.');
  }

  _PlayerRound _player(int seat) {
    if (seat < 0 || seat > 3) throw ArgumentError.value(seat, 'seat');
    return _players[seat];
  }

  void _assertTurn(int seat) {
    if (_roundFinished) throw StateError('El tamamlandı.');
    if (seat != _currentSeat) throw StateError('Sıra sizde değil.');
  }

  void _assertCanPlay(int seat) {
    _assertTurn(seat);
    if (_mustDraw) throw StateError('Önce taş çekmeli veya yandan taş almalısınız.');
  }
}
