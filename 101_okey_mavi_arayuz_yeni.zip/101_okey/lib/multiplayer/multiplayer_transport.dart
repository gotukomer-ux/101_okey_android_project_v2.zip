import 'transport_event.dart';

abstract interface class MultiplayerTransport {
  Stream<TransportEvent> get events;

  /// Starts a room and returns a human-readable connection address/name.
  Future<String> host();

  /// Joins a room using the host IPv4 address on the same local Wi-Fi network.
  Future<void> join(String target);

  /// Host may target a peer; clients send to their host when peerId is null.
  Future<void> send(Map<String, dynamic> message, {String? peerId});

  /// Removes a rejected or disconnected remote peer from the host transport.
  Future<void> disconnectPeer(String peerId);

  Future<void> close();

}

abstract interface class DisposableMultiplayerTransport {
  Future<void> disposeTransport();
}
