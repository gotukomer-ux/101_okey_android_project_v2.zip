import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

import 'multiplayer_transport.dart';
import 'transport_event.dart';

/// Local-network transport. One phone hosts the room; up to three other
/// phones connect to the host's IPv4 address on port 4041.
class LanTransport implements MultiplayerTransport, DisposableMultiplayerTransport {
  LanTransport({this.port = 4041});

  static const MethodChannel _permissionChannel =
      MethodChannel('classic_101_okey/platform_permissions');

  final int port;
  final StreamController<TransportEvent> _events =
      StreamController<TransportEvent>.broadcast();
  final Map<String, Socket> _peers = {};
  final Map<String, StreamSubscription<String>> _peerSubscriptions = {};

  ServerSocket? _server;
  Socket? _client;
  StreamSubscription<String>? _clientSubscription;
  bool _isHost = false;
  int _nextPeer = 1;
  bool _closed = false;

  @override
  Stream<TransportEvent> get events => _events.stream;

  @override
  Future<String> host() async {
    await _ensureLocalNetworkPermission();
    await close();
    _closed = false;
    _isHost = true;
    _server = await ServerSocket.bind(InternetAddress.anyIPv4, port,
        shared: true);
    _server!.listen(_accept, onError: (Object error) {
      _emit(TransportEvent(
          type: TransportEventType.error,
          message: 'Wi-Fi sunucusu hatası: $error'));
    });
    return '${await _findLocalIpv4()}:${_server!.port}';
  }

  void _accept(Socket socket) {
    if (_closed) {
      socket.destroy();
      return;
    }
    if (_peers.length >= 3) {
      socket.write('{"type":"room_full"}\n');
      socket.flush().whenComplete(socket.destroy);
      return;
    }
    socket.setOption(SocketOption.tcpNoDelay, true);
    final peerId = 'lan-peer-${_nextPeer++}';
    _peers[peerId] = socket;
    _emit(TransportEvent(type: TransportEventType.connected, peerId: peerId));
    _peerSubscriptions[peerId] = socket
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(
      (line) => _handleLine(line, peerId),
      onError: (Object error) => _emit(TransportEvent(
          type: TransportEventType.error,
          peerId: peerId,
          message: 'Oyuncu bağlantı hatası: $error')),
      onDone: () => _removePeer(peerId),
      cancelOnError: false,
    );
  }

  @override
  Future<void> join(String target) async {
    await _ensureLocalNetworkPermission();
    await close();
    _closed = false;
    _isHost = false;
    final address = target.trim();
    if (address.isEmpty || address.contains(':')) {
      throw ArgumentError('Yalnızca IPv4 adresi girin (ör. 192.168.1.25).');
    }
    final socket = await Socket.connect(address, port,
        timeout: const Duration(seconds: 10));
    socket.setOption(SocketOption.tcpNoDelay, true);
    _client = socket;
    _emit(const TransportEvent(
        type: TransportEventType.connected, peerId: 'lan-server'));
    _clientSubscription = socket
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(
      (line) => _handleLine(line, 'lan-server'),
      onError: (Object error) => _emit(TransportEvent(
          type: TransportEventType.error,
          message: 'Wi-Fi bağlantı hatası: $error')),
      onDone: () {
        _client = null;
        _emit(const TransportEvent(
            type: TransportEventType.disconnected, peerId: 'lan-server'));
      },
      cancelOnError: false,
    );
  }

  void _handleLine(String line, String peerId) {
    try {
      final decoded = jsonDecode(line);
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('Mesaj JSON nesnesi değil.');
      }
      _emit(TransportEvent(
          type: TransportEventType.message,
          peerId: peerId,
          data: decoded));
    } on FormatException catch (error) {
      _emit(TransportEvent(
          type: TransportEventType.error,
          peerId: peerId,
          message: 'Geçersiz ağ mesajı: ${error.message}'));
    }
  }

  void _removePeer(String peerId) {
    _peerSubscriptions.remove(peerId)?.cancel();
    _peers.remove(peerId)?.destroy();
    _emit(TransportEvent(
        type: TransportEventType.disconnected, peerId: peerId));
  }

  @override
  Future<void> send(Map<String, dynamic> message, {String? peerId}) async {
    final line = '${jsonEncode(message)}\n';
    if (_isHost) {
      if (peerId != null) {
        final socket = _peers[peerId];
        if (socket == null) throw StateError('Oyuncu bağlantısı bulunamadı.');
        socket.write(line);
        await socket.flush();
      } else {
        for (final socket in _peers.values.toList()) {
          socket.write(line);
          await socket.flush();
        }
      }
    } else {
      final socket = _client;
      if (socket == null) throw StateError('Sunucuya bağlı değil.');
      socket.write(line);
      await socket.flush();
    }
  }


  @override
  Future<void> disconnectPeer(String peerId) async {
    final socket = _peers.remove(peerId);
    final subscription = _peerSubscriptions.remove(peerId);
    await subscription?.cancel();
    if (socket != null) {
      socket.destroy();
      _emit(TransportEvent(type: TransportEventType.disconnected, peerId: peerId));
    }
  }

  Future<void> _ensureLocalNetworkPermission() async {
    if (Platform.isAndroid) {
      await _permissionChannel.invokeMethod<void>('ensureLocalNetworkPermission');
    }
  }

  Future<String> _findLocalIpv4() async {
    final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4, includeLoopback: false);
    final preferredAddresses = <String>[];
    final fallbackAddresses = <String>[];
    for (final interface in interfaces) {
      for (final address in interface.addresses) {
        final ip = address.address;
        if (!_isPrivateIpv4(ip)) continue;
        final name = interface.name.toLowerCase();
        final isWifi = name.contains('wlan') || name.contains('wifi') || name.contains('ap');
        (isWifi ? preferredAddresses : fallbackAddresses).add(ip);
      }
    }
    final addresses = preferredAddresses.isNotEmpty
        ? preferredAddresses
        : fallbackAddresses;
    if (addresses.isEmpty) {
      throw StateError('Yerel IPv4 adresi bulunamadı. Wi-Fi bağlantısını kontrol edin.');
    }
    addresses.sort((a, b) {
      final aw = a.startsWith('192.168.') || a.startsWith('10.') || a.startsWith('172.');
      final bw = b.startsWith('192.168.') || b.startsWith('10.') || b.startsWith('172.');
      return (bw ? 1 : 0) - (aw ? 1 : 0);
    });
    return addresses.first;
  }

  bool _isPrivateIpv4(String ip) {
    final parts = ip.split('.').map(int.tryParse).toList();
    if (parts.length != 4 || parts.any((part) => part == null)) return false;
    final a = parts[0]!;
    final b = parts[1]!;
    return a == 10 ||
        (a == 172 && b >= 16 && b <= 31) ||
        (a == 192 && b == 168) ||
        (a == 169 && b == 254);
  }

  void _emit(TransportEvent event) {
    if (!_events.isClosed) _events.add(event);
  }


  @override
  Future<void> close() async {
    _closed = true;
    await _server?.close();
    _server = null;
    for (final subscription in _peerSubscriptions.values) {
      await subscription.cancel();
    }
    _peerSubscriptions.clear();
    for (final socket in _peers.values) {
      socket.destroy();
    }
    _peers.clear();
    await _clientSubscription?.cancel();
    _clientSubscription = null;
    _client?.destroy();
    _client = null;
  }

  @override
  Future<void> disposeTransport() async {
    await close();
    await _events.close();
  }
}
