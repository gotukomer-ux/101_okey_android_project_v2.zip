import 'dart:async';
import 'dart:math';

import '../bot/bot_strategy.dart';
import '../game/game_engine.dart';
import '../game/game_state.dart';
import 'multiplayer_transport.dart';
import 'room_state.dart';
import 'transport_event.dart';
import '../session/game_session.dart';

class RoomCoordinator implements GameSession {
  static const int protocolVersion = 2;
  RoomCoordinator({required this.transport, required this.playerName})
      : localPlayerId = _newPlayerId() {
    _eventSubscription = transport.events.listen(_onTransportEvent);
  }

  final MultiplayerTransport transport;
  final String playerName;
  final String localPlayerId;
  final StreamController<RoomSnapshot> _snapshots =
      StreamController<RoomSnapshot>.broadcast();
  final StreamController<String> _statuses =
      StreamController<String>.broadcast();
  final StreamController<GameView> _gameViews =
      StreamController<GameView>.broadcast();
  final Set<String> _disconnectedPeers = {};
  final Set<int> _botSeats = {};
  final Map<int, BotStrategy> _botStrategies = {};
  late final StreamSubscription<TransportEvent> _eventSubscription;

  RoomRegistry? _registry;
  RoomSnapshot? _remoteSnapshot;
  GameEngine? _gameEngine;
  GameView? _remoteGameView;
  bool _isHost = false;
  bool _joinSent = false;
  bool _joinRejected = false;
  bool _disposed = false;
  Completer<void>? _pendingActionResult;
  String? connectionAddress;

  Stream<RoomSnapshot> get snapshots => _snapshots.stream;
  @override
  @override
  @override
  @override
  @override
  Stream<String> get statuses => _statuses.stream;
  @override
  @override
  @override
  @override
  @override
  Stream<GameView> get gameViews => _gameViews.stream;
  RoomSnapshot? get currentSnapshot => _registry?.snapshot ?? _remoteSnapshot;
  @override
  @override
  @override
  @override
  @override
  GameView? get currentGameView => _gameEngine?.viewFor(0) ?? _remoteGameView;
  bool get isHost => _isHost;
  bool get gameStarted => _gameEngine != null || _remoteGameView != null;

  @override
  bool get canStartNextRound => _isHost && _gameEngine?.isFinished == true;

  Future<String> host() async {
    _isHost = true;
    connectionAddress = await transport.host();
    _registry = RoomRegistry(hostId: localPlayerId, hostName: playerName);
    _publish(_registry!.snapshot);
    _status('Masa kuruldu. Üç oyuncu daha bağlanabilir.');
    return connectionAddress!;
  }

  Future<void> join(String target) async {
    _isHost = false;
    _status('Bağlanılıyor…');
    await transport.join(target);
  }

  /// Starts a real round on the host and sends seat-specific, privacy-safe views.
  Future<void> startRoom({Random? random, bool fillWithBots = false}) async {
    final registry = _registry;
    if (!_isHost || registry == null) {
      throw StateError('Masayı yalnızca kuran oyuncu başlatabilir.');
    }
    if (_gameEngine != null) throw StateError('Oyun zaten başlatılmış.');
    if (fillWithBots) registry.fillRemainingWithBots();
    final roomBeforeStart = registry.snapshot;
    if (!roomBeforeStart.isFull) throw StateError('Oyun için dört koltuğun da dolması gerekli.');
    _botSeats
      ..clear()
      ..addAll(roomBeforeStart.players.where((player) => player.isBot).map((player) => player.seat));
    _botStrategies
      ..clear()
      ..addEntries(_botSeats.map((seat) => MapEntry(seat, const BotStrategy(difficulty: BotDifficulty.hard))));
    registry.start();
    final room = registry.snapshot;
    final sorted = [...room.players]..sort((a, b) => a.seat.compareTo(b.seat));
    _gameEngine = GameEngine.start(
      playerNames: sorted.map((player) => player.name).toList(),
      playerIds: sorted.map((player) => player.id).toList(),
      random: random,
    );
    _publish(room);
    await transport.send({'type': 'room_state', 'room': room.toJson()});
    await _runBotTurns();
    _publishGame(_gameEngine!.viewFor(0));
    await _broadcastGameViews();
    _status('Oyun başladı. Taşlar her oyuncuya özel gönderildi.');
  }

  @override
  Future<void> startNextRound() async {
    final registry = _registry;
    final previous = _gameEngine;
    if (!_isHost || registry == null || previous == null || !previous.isFinished) {
      throw StateError('Yeni eli yalnızca masa sahibi, mevcut el bittikten sonra başlatabilir.');
    }
    final previousView = previous.viewFor(0);
    final players = [...previousView.players]..sort((a, b) => a.seat.compareTo(b.seat));
    final scores = {for (final player in players) player.id: player.totalScore};
    final nextRound = previous.roundNumber + 1;
    _gameEngine = GameEngine.start(
      playerNames: players.map((player) => player.name).toList(),
      playerIds: players.map((player) => player.id).toList(),
      roundNumber: nextRound,
      startingSeat: nextRound % 4,
      initialScores: scores,
    );
    await _runBotTurns();
    await _broadcastGameViews();
    _status('El $nextRound başladı. Önceki puanlar korundu.');
  }

  /// Clients submit commands; the host applies and validates every command.
  @override
  @override
  @override
  @override
  @override
  Future<void> submitGameAction(Map<String, dynamic> action) async {
    if (_disposed) throw StateError('Oyun bağlantısı kapalı.');
    if (_isHost) {
      final engine = _gameEngine;
      if (engine == null) throw StateError('Oyun henüz başlamadı.');
      engine.applyAction(0, action);
      await _runBotTurns();
      _publishGame(engine.viewFor(0));
      await _broadcastGameViews();
      return;
    }
    if (_remoteGameView == null) throw StateError('Oyun durumu henüz alınmadı.');
    if (_pendingActionResult != null) throw StateError('Önceki hamlenin sunucu onayı bekleniyor.');
    final pending = Completer<void>();
    _pendingActionResult = pending;
    final acknowledgement = pending.future.timeout(const Duration(seconds: 12));
    // Attach before sending: a fast host may answer before the socket flush
    // future has completed. The later await still observes the original result.
    acknowledgement.catchError((Object _) {});
    try {
      await transport.send({'type': 'game_action', 'actionData': action});
      await acknowledgement;
    } finally {
      if (identical(_pendingActionResult, pending)) _pendingActionResult = null;
    }
  }

  void _onTransportEvent(TransportEvent event) {
    if (_disposed) return;
    switch (event.type) {
      case TransportEventType.connected:
        if (!_isHost && !_joinSent) {
          _joinSent = true;
          transport.send({
            'type': 'join',
            'playerId': localPlayerId,
            'name': playerName,
            'protocol': protocolVersion,
          }).catchError((Object error) => _status('Katılma mesajı gönderilemedi: $error'));
          _status('Bağlandı; masaya giriş onaylanıyor…');
        }
        break;
      case TransportEventType.disconnected:
        if (_isHost) {
          final peerId = event.peerId;
          // During a game, keep the seat/state reserved; the game must not silently
          // reassign a disconnected player's tiles to another participant.
          if (_gameEngine == null && peerId != null && _registry?.removePeer(peerId) == true) {
            _broadcastSnapshot().catchError(
                (Object error) => _status('Oda durumu gönderilemedi: $error'));
            _status('Bir oyuncu masadan ayrıldı.');
          } else if (_gameEngine != null) {
            if (peerId != null) _disconnectedPeers.add(peerId);
            _status('Bir oyuncunun bağlantısı kesildi. El durumu korunuyor; otomatik koltuk devri yapılmadı.');
          }
        } else if (!_joinRejected) {
          _status('Masa bağlantısı kesildi.');
          final pending = _pendingActionResult;
          if (pending != null && !pending.isCompleted) {
            pending.completeError(StateError('Masa bağlantısı kesildi.'));
          }
        }
        break;
      case TransportEventType.message:
        _handleMessage(event).catchError(
            (Object error) => _status('Oda mesajı işlenemedi: $error'));
        break;
      case TransportEventType.error:
        _status(event.message ?? 'Bağlantı hatası.');
        break;
    }
  }

  Future<void> _handleMessage(TransportEvent event) async {
    final data = event.data;
    if (data == null) return;
    final type = data['type'];
    if (_isHost) {
      if (type == 'join') {
        await _handleJoin(event, data);
        return;
      }
      if (type == 'game_action') {
        await _handleGameAction(event, data);
        return;
      }
      return;
    }

    if (type == 'room_state') {
      try {
        final rawRoom = data['room'];
        if (rawRoom is! Map) throw const FormatException('Oda verisi eksik.');
        _remoteSnapshot = RoomSnapshot.fromJson(Map<String, dynamic>.from(rawRoom));
        _publish(_remoteSnapshot!);
        _status('Masaya bağlı: ${_remoteSnapshot!.occupiedSeats}/4 oyuncu.');
      } on FormatException catch (error) {
        _status('Oda bilgisi okunamadı: ${error.message}');
      }
    } else if (type == 'game_snapshot') {
      try {
        final rawGame = data['game'];
        if (rawGame is! Map) throw const FormatException('Oyun verisi eksik.');
        _remoteGameView = GameView.fromJson(Map<String, dynamic>.from(rawGame));
        _publishGame(_remoteGameView!);
      } on FormatException catch (error) {
        _status('Oyun verisi okunamadı: ${error.message}');
      }
    } else if (type == 'action_accepted') {
      final pending = _pendingActionResult;
      if (pending != null && !pending.isCompleted) pending.complete();
    } else if (type == 'join_rejected' || type == 'room_full') {
      _joinRejected = true;
      _status(data['reason'] as String? ?? 'Masa dolu veya katılma reddedildi.');
      await transport.close();
    } else if (type == 'action_rejected') {
      final reason = data['reason'] as String? ?? 'Hamle sunucu tarafından reddedildi.';
      _status(reason);
      final pending = _pendingActionResult;
      if (pending != null && !pending.isCompleted) pending.completeError(StateError(reason));
    }
  }

  Future<void> _handleJoin(TransportEvent event, Map<String, dynamic> data) async {
    final peerId = event.peerId;
    if (peerId == null || _registry == null) return;
    if (data['protocol'] != protocolVersion) {
      await transport.send(
        {'type': 'join_rejected', 'reason': 'Uyumsuz oyun sürümü.'},
        peerId: peerId,
      );
      await transport.disconnectPeer(peerId);
      return;
    }
    if (_gameEngine != null) {
      await transport.send(
        {'type': 'join_rejected', 'reason': 'Oyun başladı; yeni oyuncu alınamaz.'},
        peerId: peerId,
      );
      await transport.disconnectPeer(peerId);
      return;
    }
    final playerId = data['playerId'];
    final playerName = data['name'];
    if (playerId is! String || playerName is! String || playerId.trim().isEmpty) {
      await transport.send(
        {'type': 'join_rejected', 'reason': 'Oyuncu giriş bilgileri geçersiz.'},
        peerId: peerId,
      );
      await transport.disconnectPeer(peerId);
      return;
    }
    final outcome = _registry!.join(
      playerId: playerId,
      playerName: playerName,
      peerId: peerId,
    );
    if (!outcome.accepted) {
      await transport.send(
        {'type': 'join_rejected', 'reason': outcome.reason},
        peerId: peerId,
      );
      await transport.disconnectPeer(peerId);
      return;
    }
    final matching = outcome.snapshot!.players.where((player) => player.id == playerId).toList();
    if (matching.isEmpty) throw StateError('Kabul edilen oyuncu oda listesinde bulunamadı.');
    final player = matching.first;
    await transport.send(
      {'type': 'join_accepted', 'playerId': player.id, 'seat': player.seat},
      peerId: peerId,
    );
    await _broadcastSnapshot();
    _status('${player.name} masaya katıldı (${_registry!.snapshot.occupiedSeats}/4).');
  }

  Future<void> _handleGameAction(TransportEvent event, Map<String, dynamic> data) async {
    final peerId = event.peerId;
    final registry = _registry;
    final engine = _gameEngine;
    if (peerId == null || registry == null || engine == null) return;
    final player = registry.playerForPeer(peerId);
    final rawAction = data['actionData'];
    if (player == null || rawAction is! Map) {
      await transport.send(
        {'type': 'action_rejected', 'reason': 'Oyuncu bağlantısı veya hamle verisi geçersiz.'},
        peerId: peerId,
      );
      return;
    }
    try {
      engine.applyAction(player.seat, Map<String, dynamic>.from(rawAction));
    } catch (error) {
      await transport.send(
        {'type': 'action_rejected', 'reason': error.toString()},
        peerId: peerId,
      );
      return;
    }
    // Human action is committed. A bot issue must not make the client believe
    // its accepted action was rejected.
    try {
      await _runBotTurns();
    } catch (error) {
      _status('Oyuncu hamlesi kaydedildi; bot sırası tamamlanamadı: $error');
    }
    await _broadcastGameViews();
    try {
      await transport.send({'type': 'action_accepted'}, peerId: peerId);
    } catch (error) {
      _status('Hamle kabul edildi ancak onay iletilemedi: $error');
    }
    _status('${player.name} hamlesi kabul edildi.');
  }

  Future<void> _runBotTurns() async {
    final engine = _gameEngine;
    if (engine == null || _botSeats.isEmpty) return;
    var actions = 0;
    while (!engine.isFinished && _botSeats.contains(engine.currentSeat)) {
      actions++;
      if (actions > 48) {
        throw StateError('Bot hamle sınırına ulaşıldı; oyun güvenli şekilde durduruldu.');
      }
      final seat = engine.currentSeat;
      final strategy = _botStrategies[seat] ?? const BotStrategy(difficulty: BotDifficulty.hard);
      final action = strategy.nextAction(engine.viewFor(seat));
      engine.applyAction(seat, action);
    }
  }

  Future<void> _broadcastSnapshot() async {
    final snapshot = _registry!.snapshot;
    _publish(snapshot);
    await transport.send({'type': 'room_state', 'room': snapshot.toJson()});
  }

  Future<void> _broadcastGameViews() async {
    final engine = _gameEngine;
    final registry = _registry;
    if (engine == null || registry == null) return;
    _publishGame(engine.viewFor(0));
    for (var seat = 1; seat < 4; seat++) {
      final peerId = registry.peerForSeat(seat);
      if (peerId == null || _disconnectedPeers.contains(peerId)) continue;
      try {
        await transport.send(
          {'type': 'game_snapshot', 'game': engine.viewFor(seat).toJson()},
          peerId: peerId,
        );
      } catch (error) {
        _disconnectedPeers.add(peerId);
        _status('Oyuncu $seat bağlantısına oyun durumu gönderilemedi: $error');
      }
    }
  }

  void _publish(RoomSnapshot snapshot) {
    if (!_snapshots.isClosed) _snapshots.add(snapshot);
  }

  void _publishGame(GameView view) {
    if (!_gameViews.isClosed) _gameViews.add(view);
  }

  void _status(String status) {
    if (!_statuses.isClosed) _statuses.add(status);
  }

  static String _newPlayerId() {
    final random = Random.secure();
    final suffix = List<int>.generate(12, (_) => random.nextInt(16))
        .map((value) => value.toRadixString(16))
        .join();
    return '${DateTime.now().microsecondsSinceEpoch}-$suffix';
  }

  @override
  @override
  @override
  @override
  @override
  Future<void> leave() async {
    await transport.close();
    _status('Masadan ayrıldınız.');
  }

  @override
  @override
  @override
  @override
  @override
  Future<void> dispose() async {
    _disposed = true;
    final pending = _pendingActionResult;
    if (pending != null && !pending.isCompleted) {
      pending.completeError(StateError('Oyun bağlantısı kapatıldı.'));
    }
    await _eventSubscription.cancel();
    if (transport is DisposableMultiplayerTransport) {
      await (transport as DisposableMultiplayerTransport).disposeTransport();
    } else {
      await transport.close();
    }
    await _snapshots.close();
    await _statuses.close();
    await _gameViews.close();
  }
}
