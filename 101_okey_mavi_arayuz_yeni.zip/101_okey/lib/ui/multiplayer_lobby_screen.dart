// ignore_for_file: deprecated_member_use
import 'dart:async';

import 'package:flutter/material.dart';

import '../multiplayer/lan_transport.dart';
import '../multiplayer/multiplayer_transport.dart';
import '../multiplayer/room_coordinator.dart';
import '../game/game_state.dart';
import 'game_table_screen.dart';
import '../multiplayer/room_state.dart';

class MultiplayerLobbyScreen extends StatefulWidget {
  const MultiplayerLobbyScreen({super.key});

  @override
  State<MultiplayerLobbyScreen> createState() => _MultiplayerLobbyScreenState();
}

class _MultiplayerLobbyScreenState extends State<MultiplayerLobbyScreen> {
  final _nameController = TextEditingController(text: 'Oyuncu');
  final _ipController = TextEditingController();
  RoomCoordinator? _coordinator;
  StreamSubscription<RoomSnapshot>? _snapshotSubscription;
  StreamSubscription<String>? _statusSubscription;
  StreamSubscription<GameView>? _gameSubscription;
  RoomSnapshot? _snapshot;
  String _status = 'Aynı Wi-Fi ağı üzerinden masa kurabilir veya IP ile katılabilirsiniz.';
  String? _connectionAddress;
  bool _busy = false;
  bool _roomCreated = false;
  bool _gamePageShown = false;

  @override
  void dispose() {
    _snapshotSubscription?.cancel();
    _statusSubscription?.cancel();
    _gameSubscription?.cancel();
    _coordinator?.dispose();
    _nameController.dispose();
    _ipController.dispose();
    super.dispose();
  }

  String get _playerName {
    final value = _nameController.text.trim();
    return value.isEmpty ? 'Oyuncu' : value;
  }

  MultiplayerTransport _newTransport() => LanTransport();

  Future<void> _prepareCoordinator() async {
    await _snapshotSubscription?.cancel();
    await _statusSubscription?.cancel();
    await _gameSubscription?.cancel();
    await _coordinator?.dispose();
    final coordinator = RoomCoordinator(
      transport: _newTransport(),
      playerName: _playerName,
    );
    _coordinator = coordinator;
    _snapshot = null;
    _connectionAddress = null;
    _roomCreated = false;
    _gamePageShown = false;
    _snapshotSubscription = coordinator.snapshots.listen((snapshot) {
      if (mounted) setState(() => _snapshot = snapshot);
    });
    _statusSubscription = coordinator.statuses.listen((status) {
      if (mounted) setState(() => _status = status);
    });
    _gameSubscription = coordinator.gameViews.listen(_showGameTable);
  }

  void _showGameTable(GameView view, {bool force = false}) {
    if (!mounted) return;
    if (!_gamePageShown || force) {
      _gamePageShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || _coordinator == null) return;
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => GameTableScreen(session: _coordinator!, initialView: view),
        ));
      });
    }
  }

  Future<void> _hostRoom() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await _prepareCoordinator();
      final address = await _coordinator!.host();
      if (!mounted) return;
      setState(() {
        _connectionAddress = address;
        _roomCreated = true;
        _status = 'Masa hazır. Diğer telefonlar aynı Wi-Fi ağına bağlanıp bu IP ile katılabilir.';
      });
    } catch (error) {
      _showError(error);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _joinRoom() async {
    if (_busy) return;
    final target = _ipController.text.trim();
    if (target.isEmpty) {
      _showError('Masa sahibinin IP adresini girin.');
      return;
    }
    setState(() => _busy = true);
    try {
      await _prepareCoordinator();
      await _coordinator!.join(target);
      if (mounted) {
        setState(() {
          _roomCreated = true;
          _status = 'Bağlantı kuruldu; masadan yanıt bekleniyor.';
        });
      }
    } catch (error) {
      _showError(error);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _leaveRoom() async {
    await _coordinator?.leave();
    await _coordinator?.dispose();
    if (!mounted) return;
    setState(() {
      _coordinator = null;
      _snapshot = null;
      _roomCreated = false;
      _connectionAddress = null;
      _gamePageShown = false;
      _status = 'Masadan ayrıldınız.';
    });
  }

  void _showError(Object error) {
    if (!mounted) return;
    setState(() => _status = 'Hata: $error');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Bağlantı kurulamadı: $error')),
    );
  }


  @override
  Widget build(BuildContext context) {
    final players = _snapshot?.players ?? const <RoomPlayer>[];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dört Kişilik Masa'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(builder: (context, constraints) {
          final compact = constraints.maxWidth < 760;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1040),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Oyuncu ve bağlantı',
                                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _nameController,
                              maxLength: 18,
                              enabled: !_roomCreated && _snapshot == null,
                              decoration: const InputDecoration(
                                labelText: 'Oyuncu adınız',
                                border: OutlineInputBorder(),
                                counterText: '',
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Row(
                              children: [
                                Icon(Icons.wifi, color: Color(0xFF78C5FF)),
                                SizedBox(width: 8),
                                Text('Yalnızca aynı Wi-Fi ağı üzerinden oynanır.'),
                              ],
                            ),
                            const SizedBox(height: 12),
                            if (_snapshot == null && !_roomCreated) ...[
                              TextField(
                                controller: _ipController,
                                keyboardType: TextInputType.text,
                                decoration: const InputDecoration(
                                  labelText: 'Masa sahibinin IPv4 adresi',
                                  hintText: '192.168.1.25',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ],
                            Wrap(
                              spacing: 10,
                              runSpacing: 10,
                              children: [
                                FilledButton.icon(
                                  onPressed: _busy || _roomCreated || _snapshot != null ? null : _hostRoom,
                                  icon: const Icon(Icons.add_to_home_screen),
                                  label: const Text('Wi-Fi masası kur'),
                                ),
                                OutlinedButton.icon(
                                  onPressed: _busy || _roomCreated || _snapshot != null ? null : _joinRoom,
                                  icon: const Icon(Icons.login),
                                  label: const Text('IP ile masaya katıl'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_roomCreated && _snapshot == null) ...[
                      const SizedBox(height: 14),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              const Expanded(child: Text('Bağlantı kuruluyor veya masa sahibinin yanıtı bekleniyor.')),
                              OutlinedButton.icon(
                                onPressed: _leaveRoom,
                                icon: const Icon(Icons.logout),
                                label: const Text('Ayrıl'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    if (_snapshot != null) ...[
                      const SizedBox(height: 14),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Expanded(
                                    child: Text('Oyun masası',
                                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                  ),
                                  Chip(label: Text('${_snapshot!.humanCount} gerçek oyuncu · ${_snapshot!.botCount} bot')),
                                ],
                              ),
                              if (_connectionAddress != null) ...[
                                const SizedBox(height: 8),
                                SelectableText(
                                  'IP: ${_connectionAddress!.split(':').first}  •  Port: ${_connectionAddress!.split(':').last}',
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                              ],
                              const SizedBox(height: 12),
                              GridView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: compact ? 2 : 4,
                                  mainAxisSpacing: 8,
                                  crossAxisSpacing: 8,
                                  childAspectRatio: compact ? 2.8 : 2.2,
                                ),
                                itemCount: 4,
                                itemBuilder: (context, index) {
                                  final matchingPlayers = players.where((p) => p.seat == index).toList();
                                  final player = matchingPlayers.isEmpty ? null : matchingPlayers.first;
                                  return Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: player == null
                                          ? Colors.white.withValues(alpha: 0.04)
                                          : const Color(0xFF123E68),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                          color: player == null ? Colors.white24 : const Color(0xFF78C5FF)),
                                    ),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 16,
                                          child: Text('${index + 1}'),
                                        ),
                                        const SizedBox(width: 9),
                                        Expanded(
                                          child: Text(
                                            player == null ? 'Boş koltuk' : (player.isBot ? '${player.name} · Bot' : player.name),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        if (player?.isHost == true)
                                          const Icon(Icons.star, color: Color(0xFF78C5FF), size: 17)
                                        else if (player?.isBot == true)
                                          const Icon(Icons.smart_toy, color: Color(0xFF78C5FF), size: 17),
                                      ],
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 12),
                              if (_snapshot!.isFull)
                                const Text('Dört oyuncu da masada.',
                                    style: TextStyle(color: Color(0xFF8FD2FF))),
                              if (_coordinator?.isHost == true && !_coordinator!.gameStarted && _snapshot!.isFull) ...[
                                const SizedBox(height: 10),
                                FilledButton.icon(
                                  onPressed: _busy ? null : () async {
                                    setState(() => _busy = true);
                                    try {
                                      await _coordinator!.startRoom();
                                    } catch (error) {
                                      _showError(error);
                                    } finally {
                                      if (mounted) setState(() => _busy = false);
                                    }
                                  },
                                  icon: const Icon(Icons.play_arrow_rounded),
                                  label: const Text('Oyunu başlat'),
                                ),
                              ] else if (_coordinator?.isHost == true && !_coordinator!.gameStarted && _snapshot!.canStartWithBots) ...[
                                const SizedBox(height: 10),
                                const Text('Eksik koltuklar botlarla doldurulabilir. En az iki gerçek oyuncu gerekir.'),
                                const SizedBox(height: 8),
                                FilledButton.icon(
                                  onPressed: _busy ? null : () async {
                                    setState(() => _busy = true);
                                    try {
                                      await _coordinator!.startRoom(fillWithBots: true);
                                    } catch (error) {
                                      _showError(error);
                                    } finally {
                                      if (mounted) setState(() => _busy = false);
                                    }
                                  },
                                  icon: const Icon(Icons.smart_toy_outlined),
                                  label: Text('Botlarla başlat (${4 - _snapshot!.occupiedSeats} bot eklenecek)'),
                                ),
                              ] else if (_snapshot!.isFull && _coordinator?.isHost == false) ...[
                                const SizedBox(height: 8),
                                const Text('Masa sahibinin oyunu başlatması bekleniyor.'),
                              ],
                              if (_snapshot!.isFull && _coordinator?.gameStarted == true && _coordinator?.currentGameView != null) ...[
                                const SizedBox(height: 8),
                                OutlinedButton.icon(
                                  onPressed: () => _showGameTable(_coordinator!.currentGameView!, force: true),
                                  icon: const Icon(Icons.sports_esports),
                                  label: const Text('Oyuna geri dön'),
                                ),
                              ],
                              const SizedBox(height: 8),
                              OutlinedButton.icon(
                                onPressed: _leaveRoom,
                                icon: const Icon(Icons.logout),
                                label: const Text('Masadan ayrıl'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Card(
                      color: const Color(0xFF0B2B4D),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.info_outline, color: Color(0xFF78C5FF)),
                            const SizedBox(width: 10),
                            Expanded(child: Text(_status)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Aynı Wi-Fi ağına bağlı 2–4 gerçek oyuncu katılabilir. Eksik koltuklar masa sahibi isterse botlarla doldurulur; bot hamlelerini masa sahibi yönetir.',
                      style: TextStyle(color: Colors.white60, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
