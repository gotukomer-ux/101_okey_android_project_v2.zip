import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../bot/bot_strategy.dart';
import '../domain/meld.dart';
import '../domain/tile.dart';
import '../game/game_state.dart';
import '../game/opening_rules.dart';
import '../session/game_session.dart';

class GameTableScreen extends StatefulWidget {
  const GameTableScreen({
    super.key,
    required this.session,
    required this.initialView,
  });

  final GameSession session;
  final GameView initialView;

  @override
  State<GameTableScreen> createState() => _GameTableScreenState();
}

class _GameTableScreenState extends State<GameTableScreen> {
  late GameView _view;
  StreamSubscription<GameView>? _subscription;
  StreamSubscription<String>? _statusSubscription;
  final Set<String> _selected = {};
  final List<List<String>> _draftMelds = [];
  final List<List<String>> _draftPairs = [];
  final Map<String, TileFace> _representedFaces = {};
  String? _selectedMeldId;
  bool _busy = false;
  bool _assisted = true;
  List<String> _manualOrder = [];
  static const int _turnLimitSeconds = 30;
  Timer? _turnTimer;
  int _turnSecondsRemaining = _turnLimitSeconds;
  String? _turnClockKey;
  bool _timeoutInProgress = false;

  @override
  void initState() {
    super.initState();
    _view = widget.initialView;
    _manualOrder = _view.myHand.map((tile) => tile.id).toList();
    _syncTurnClock(_view);
    _subscription = widget.session.gameViews.listen((view) {
      if (!mounted) return;
      setState(() {
        _view = view;
        final currentIds = view.myHand.map((tile) => tile.id).toSet();
        _draftMelds.removeWhere((meld) => meld.any((id) => !currentIds.contains(id)));
        _draftPairs.removeWhere((pair) => pair.any((id) => !currentIds.contains(id)));
        _manualOrder.removeWhere((id) => !currentIds.contains(id));
        for (final tile in view.myHand) {
          if (!_manualOrder.contains(tile.id)) _manualOrder.add(tile.id);
        }
        // Selection is cleared only after an authoritative state update. A
        // rejected network move therefore leaves the user's selection intact.
        _selected.clear();
        _selectedMeldId = null;
        _representedFaces.removeWhere((id, _) => !currentIds.contains(id));
        final mine = view.players.firstWhere((player) => player.seat == view.mySeat);
        if (mine.hasOpened) {
          _draftMelds.clear();
          _draftPairs.clear();
        }
      });
      _syncTurnClock(view);
    });
    _statusSubscription = widget.session.statuses.listen((message) {
      final lower = message.toLowerCase();
      if (lower.contains('hata') || lower.contains('redded') ||
          lower.contains('geçersiz') || lower.contains('sıra sizde değil') ||
          lower.contains('bulunamadı') || lower.contains('başarısız') ||
          lower.contains('bad state')) {
        _showMessage(message);
      }
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _statusSubscription?.cancel();
    _turnTimer?.cancel();
    super.dispose();
  }

  PlayerGameSummary get _myPlayer => _view.players.firstWhere((player) => player.seat == _view.mySeat);
  bool get _myTurn => !_view.roundFinished && _view.currentSeat == _view.mySeat;
  int get _handTotal => _view.myHand.fold<int>(0, (sum, tile) => sum +
      (_representedFaces[tile.id]?.number ??
       (tile.kind == TileKind.falseJoker ? _view.realOkey.number : tile.number ?? 0)));
  bool get _canProcess => _myTurn && !_view.mustDraw && !_busy &&
      _myPlayer.openingType == OpeningType.normal && _view.myHand.length > 1;
  bool get _canStartOpening => _myTurn && !_view.mustDraw && !_busy && !_myPlayer.hasOpened;
  bool get _canDraw => _myTurn && _view.mustDraw && !_busy;
  bool get _canDiscard => _myTurn && !_view.mustDraw && !_busy && _selected.length == 1;

  void _syncTurnClock(GameView view) {
    if (view.roundFinished || view.currentSeat != view.mySeat) {
      _turnTimer?.cancel();
      _turnTimer = null;
      _turnClockKey = null;
      _turnSecondsRemaining = _turnLimitSeconds;
      _timeoutInProgress = false;
      return;
    }
    final key = '${view.gameId}-${view.roundNumber}-${view.currentSeat}';
    if (_turnClockKey == key && (_turnTimer != null || _timeoutInProgress)) return;
    _turnTimer?.cancel();
    _turnClockKey = key;
    _turnSecondsRemaining = _turnLimitSeconds;
    _timeoutInProgress = false;
    _turnTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_turnSecondsRemaining <= 1) {
        setState(() => _turnSecondsRemaining = 0);
        timer.cancel();
        _turnTimer = null;
        _handleTurnTimeout();
      } else {
        setState(() => _turnSecondsRemaining--);
      }
    });
  }

  Future<void> _handleTurnTimeout() async {
    if (_timeoutInProgress || !mounted) return;
    _timeoutInProgress = true;
    _turnTimer?.cancel();
    _turnTimer = null;
    try {
      var latest = widget.session.currentGameView ?? _view;
      if (latest.roundFinished || latest.currentSeat != latest.mySeat) return;
      // A turn timeout consumes a stock tile first when the player has not drawn.
      if (latest.mustDraw) {
        await widget.session.submitGameAction(const {'action': 'draw_stock'});
        latest = widget.session.currentGameView ?? latest;
      }
      if (!mounted || latest.roundFinished || latest.currentSeat != latest.mySeat || latest.mustDraw) return;

      final strategy = const BotStrategy(difficulty: BotDifficulty.medium);
      if (latest.requiredOpeningTileId != null) {
        // The rules require a discarded-side pickup to be included in the opening.
        // The bot opening search is reused instead of making an illegal discard.
        final openingAction = strategy.nextAction(latest);
        final type = openingAction['action'];
        if (type == 'open_normal' || type == 'open_pairs') {
          await widget.session.submitGameAction(openingAction);
          latest = widget.session.currentGameView ?? latest;
        }
      }
      if (!mounted || latest.roundFinished || latest.currentSeat != latest.mySeat ||
          latest.mustDraw || latest.requiredOpeningTileId != null || latest.myHand.isEmpty) {
        if (mounted) _showMessage('Süre doldu; kural gereği otomatik atış yapılamadı.');
        return;
      }
      final stagedTileIds = <String>{
        ..._draftMelds.expand((meld) => meld),
        ..._draftPairs.expand((pair) => pair),
      };
      final discard = strategy.chooseLeastUsefulDiscard(
        latest, protectedTileIds: stagedTileIds);
      await widget.session.submitGameAction({'action': 'discard', 'tileId': discard.id});
      if (mounted) {
        final label = discard.isNumbered ? '${discard.number} ${discard.color!.name}' : 'sahte okey';
        _showMessage('Süre doldu. En az bağlantılı taş otomatik atıldı: $label');
      }
    } catch (error) {
      if (mounted) _showMessage('Otomatik hamle yapılamadı: $error');
    } finally {
      if (mounted) setState(() => _timeoutInProgress = false);
    }
  }

  void _seriesOpenButton() {
    if (_selected.length >= 3) {
      _stageMeld();
    } else if (_draftMelds.isNotEmpty) {
      _openNormal();
    } else {
      _showMessage('Önce en az üç taşı seçip Seri Aç düğmesine bas.');
    }
  }

  void _pairsOpenButton() {
    if (_selected.length == 2) {
      _stagePair();
    } else if (_draftPairs.length >= 5) {
      _openPairs();
    } else {
      _showMessage('Önce aynı sayı ve renkte iki taşı seçip Çift Aç düğmesine bas.');
    }
  }

  void _takeBackDrafts() {
    setState(() {
      _draftMelds.clear();
      _draftPairs.clear();
      _selected.clear();
      _representedFaces.clear();
      _selectedMeldId = null;
    });
  }

  List<Tile> get _displayHand {
    final hand = [..._view.myHand];
    final order = {for (var i = 0; i < _manualOrder.length; i++) _manualOrder[i]: i};
    hand.sort((a, b) => (order[a.id] ?? 1 << 20).compareTo(order[b.id] ?? 1 << 20));
    return hand;
  }

  Future<void> _act(Map<String, dynamic> action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.session.submitGameAction(action);
      // The session publishes an authoritative view after acceptance. Do not
      // clear a remote player's selection merely because the socket write worked.
      if (!mounted) return;
    } catch (error) {
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  Future<void> _startNextRound() async {
    if (_busy || !widget.session.canStartNextRound) return;
    setState(() => _busy = true);
    try {
      await widget.session.startNextRound();
      if (mounted) {
        setState(() {
          _selected.clear();
          _draftMelds.clear();
          _draftPairs.clear();
          _representedFaces.clear();
          _selectedMeldId = null;
          _manualOrder = _view.myHand.map((tile) => tile.id).toList();
        });
      }
    } catch (error) {
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _stageMeld() {
    if (!_canStartOpening || _selected.length < 3) return;
    if (_draftPairs.isNotEmpty) {
      _showMessage('Çift açılışı hazırlarken normal per hazırlayamazsınız.');
      return;
    }
    final alreadyStaged = _draftMelds.expand((meld) => meld).toSet();
    if (_selected.any(alreadyStaged.contains)) {
      _showMessage('Bir taş iki farklı per içinde kullanılamaz.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final tiles = _selected
        .map((id) => byId[id]!)
        .map((tile) => MeldTile(tile, representedFace: _representedFaces[tile.id]))
        .toList();
    final validation = MeldValidator.validate(tiles, _view.realOkey);
    if (!validation.isValid) {
      _showMessage(validation.error ?? 'Seçilen taşlar geçerli per değil.');
      return;
    }
    setState(() {
      _draftMelds.add(_selected.toList());
      _selected.clear();
    });
  }

  void _stagePair() {
    if (!_canStartOpening || _selected.length != 2) return;
    if (_draftMelds.isNotEmpty) {
      _showMessage('Normal açılış hazırlarken çift açılışı hazırlayamazsınız.');
      return;
    }
    final alreadyStaged = _draftPairs.expand((pair) => pair).toSet();
    if (_selected.any(alreadyStaged.contains)) {
      _showMessage('Bir taş iki farklı çift içinde kullanılamaz.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final selectedTiles = _selected.map((id) => byId[id]!).toList();
    final first = selectedTiles[0];
    final second = selectedTiles[1];
    if (!first.isNumbered || !second.isNumbered ||
        first.color != second.color || first.number != second.number) {
      _showMessage('Çift aynı renk ve aynı sayıdaki iki taştan oluşmalı.');
      return;
    }
    setState(() {
      _draftPairs.add(_selected.toList());
      _selected.clear();
    });
  }


  int _draftOpeningPoints() {
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    return _draftMelds.fold<int>(0, (total, ids) {
      final meld = ids.map((id) => MeldTile(
        byId[id]!,
        representedFace: _representedFaces[id],
      )).toList();
      return total + OpeningRules.meldPoints(meld, _view.realOkey);
    });
  }

  Future<void> _openNormal() async {
    if (_draftMelds.isEmpty || _myPlayer.hasOpened) return;
    if (_draftPairs.isNotEmpty) {
      _showMessage('Çift açılışı hazırlarken normal açılış yapamazsınız.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final proposedMelds = _draftMelds
        .map((ids) => ids
            .map((id) => MeldTile(byId[id]!, representedFace: _representedFaces[id]))
            .toList())
        .toList();
    final points = proposedMelds.fold<int>(
        0, (sum, meld) => sum + OpeningRules.meldPoints(meld, _view.realOkey));
    if (!OpeningRules.canOpenNormally(proposedMelds, _view.realOkey)) {
      _showMessage('Açılış geçersiz veya toplamı $points. En az 101 puanlık geçerli perler gerekli.');
      return;
    }
    await _act({
      'action': 'open_normal',
      'melds': _draftMelds
          .map((ids) => ids
              .map((id) => {
                    'tileId': id,
                    if (_representedFaces[id] != null)
                      'representedFace': _representedFaces[id]!.toJson(),
                  })
              .toList())
          .toList(),
    });
  }

  Future<void> _openPairs() async {
    if (_draftPairs.length < 5 || _draftMelds.isNotEmpty || _myPlayer.hasOpened) {
      _showMessage('Çift açmak için başka normal per hazırlamadan en az beş çift gerekli.');
      return;
    }
    await _act({'action': 'open_pairs', 'pairs': _draftPairs});
  }

  Future<void> _addToSelectedMeld() async {
    if (!_canProcess || _selected.length != 1 || _selectedMeldId == null) return;
    await _act({
      'action': 'add_to_meld',
      'meldId': _selectedMeldId,
      'tileId': _selected.first,
      if (_representedFaces[_selected.first] != null)
        'representedFace': _representedFaces[_selected.first]!.toJson(),
    });
  }


  Future<void> _chooseOkeyValue() async {
    if (_selected.length != 1) {
      _showMessage('Önce elinizden tek bir gerçek okey taşı seçin.');
      return;
    }
    final tileId = _selected.first;
    final matches = _view.myHand.where((tile) => tile.id == tileId).toList();
    if (matches.isEmpty) return;
    final tile = matches.first;
    final isRealOkey = tile.isNumbered &&
        tile.color == _view.realOkey.color && tile.number == _view.realOkey.number;
    if (!isRealOkey) {
      _showMessage('Yalnızca gerçek okeyin temsil edeceği yüz seçilebilir.');
      return;
    }
    var color = _representedFaces[tileId]?.color ?? TileColor.red;
    var number = _representedFaces[tileId]?.number ?? 1;
    final selectedFace = await showDialog<TileFace>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Okey hangi taşın yerine geçsin?'),
          content: Row(
            children: [
              Expanded(
                child: DropdownButton<TileColor>(
                  isExpanded: true,
                  value: color,
                  items: TileColor.values
                      .map((value) => DropdownMenuItem(value: value, child: Text(value.name)))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => color = value);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: number,
                  items: List.generate(13, (index) => index + 1)
                      .map((value) => DropdownMenuItem(value: value, child: Text('$value')))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => number = value);
                  },
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, TileFace(color, number)), child: const Text('Uygula')),
          ],
        ),
      ),
    );
    if (selectedFace != null && mounted) {
      setState(() => _representedFaces[tileId] = selectedFace);
    }
  }

  // The view is purely presentational: all rule validation and network actions
  // remain in the existing game engine and GameSession.
  static const _deep = Color(0xFF071A35);
  static const _felt = Color(0xFF14558D);
  static const _gold = Color(0xFF78C5FF);

  Color _faceColor(TileColor color) {
    switch (color) {
      case TileColor.red:
        return const Color(0xFFB71C2A);
      case TileColor.blue:
        return const Color(0xFF096EBB);
      case TileColor.black:
        return const Color(0xFF17202A);
      case TileColor.yellow:
        return const Color(0xFFD39712);
    }
  }

  void _moveTileTo(String dragged, String target) {
    if (dragged == target) return;
    final order = _displayHand.map((tile) => tile.id).toList();
    if (!order.contains(dragged) || !order.contains(target)) return;
    order.remove(dragged);
    order.insert(order.indexOf(target), dragged);
    setState(() {
      _manualOrder = order;
    });
  }

  void _autoArrange({required bool pairs}) {
    if (!_assisted) return;
    final tiles = [..._view.myHand];
    if (pairs) {
      // Identical tiles become adjacent; colours and numbers remain stable.
      tiles.sort((a, b) {
        if (!a.isNumbered || !b.isNumbered) {
          return a.isNumbered ? -1 : b.isNumbered ? 1 : a.id.compareTo(b.id);
        }
        final n = a.number!.compareTo(b.number!);
        if (n != 0) return n;
        return a.color!.index.compareTo(b.color!.index);
      });
    } else {
      // Same-colour consecutive numbers become adjacent.
      tiles.sort((a, b) {
        if (!a.isNumbered || !b.isNumbered) {
          return a.isNumbered ? -1 : b.isNumbered ? 1 : a.id.compareTo(b.id);
        }
        final c = a.color!.index.compareTo(b.color!.index);
        return c != 0 ? c : a.number!.compareTo(b.number!);
      });
    }
    setState(() {
      _manualOrder = tiles.map((tile) => tile.id).toList();
    });
  }

  Widget _tile(Tile tile, {
    bool selected = false,
    VoidCallback? onTap,
    double width = 42,
    double? height,
    TileFace? shownFace,
  }) {
    final face = shownFace ??
        (tile.isNumbered ? TileFace(tile.color!, tile.number!) : null);
    final tileHeight = height ?? width * 1.42;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: width,
        height: tileHeight,
        transform: selected ? Matrix4.translationValues(0, -4, 0) : null,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFFFFF), Color(0xFFFFF7E8), Color(0xFFE3D9C7)],
          ),
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: selected ? _gold : const Color(0xFFBDB3A1), width: selected ? 2.3 : 1),
          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 3, offset: Offset(0, 2))],
        ),
        child: Stack(children: [
          Align(
            alignment: const Alignment(0, -0.20),
            child: face == null
                ? Icon(Icons.local_florist_rounded, color: const Color(0xFF27864B), size: width * .64)
                : Text('${face.number}',
                    style: TextStyle(fontSize: width * .59, height: 1.05,
                      fontWeight: FontWeight.w900, color: _faceColor(face.color))),
          ),
          Positioned(bottom: tileHeight * .10, left: 0, right: 0,
            child: Center(child: Container(width: width * .19, height: width * .19,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: const Color(0xFFBDB4A4).withValues(alpha: .42),
                border: Border.all(color: const Color(0xFFBBB1A2), width: .7)))),),
        ]),
      ),
    );
  }

  BoxDecoration _panel({bool highlight = false, double radius = 12}) => BoxDecoration(
    gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFF185A98), Color(0xFF0A2D55)]),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: highlight ? _gold : const Color(0xFF66808A), width: highlight ? 1.5 : .8),
    boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 5, offset: Offset(0, 3))],
  );

  Widget _playerBadge(PlayerGameSummary player, {bool compact = false}) {
    final current = player.seat == _view.currentSeat && !_view.roundFinished;
    return Container(
      constraints: const BoxConstraints(minWidth: 0),
      padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 9, vertical: 5),
      decoration: _panel(highlight: current),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        CircleAvatar(radius: compact ? 11 : 15, backgroundColor: const Color(0xFF18596A),
          child: Icon(Icons.person_outline_rounded, size: compact ? 14 : 19, color: _gold)),
        const SizedBox(width: 5),
        Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min,
          children: [
            Text(player.name, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: compact ? 10 : 12, fontWeight: FontWeight.w800)),
            Text('${player.handCount} taş · ${player.hasOpened ? (player.openingType == OpeningType.normal ? '101 açtı' : 'çift açtı') : 'açmadı'}',
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: compact ? 8 : 10, color: Colors.white70)),
          ])),
      ]),
    );
  }

  Widget _smallTag(String text, {IconData? icon, bool highlighted = false}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    decoration: _panel(highlight: highlighted, radius: 9),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      if (icon != null) ...[Icon(icon, size: 13, color: _gold), const SizedBox(width: 4)],
      Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))),
    ]),
  );


  Widget _handRack(double availableWidth) {
    final hand = _displayHand;
    // Landscape table: up to 12 tiles per row; the final hand tile stays visible.
    final tileWidth = math.min(44.0, (availableWidth - 18) / 12.0);
    final tileHeight = tileWidth * 1.42;
    Widget rackRow(List<Tile> items) => SizedBox(
      height: tileHeight + 4,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (final tile in items)
          DragTarget<String>(
            onWillAcceptWithDetails: (details) => details.data != tile.id,
            onAcceptWithDetails: (details) => _moveTileTo(details.data, tile.id),
            builder: (context, candidates, rejected) => LongPressDraggable<String>(
              data: tile.id,
              feedback: Material(color: Colors.transparent,
                child: _tile(tile, width: tileWidth, height: tileHeight, selected: true)),
              childWhenDragging: Opacity(opacity: .3,
                child: _tile(tile, width: tileWidth, height: tileHeight)),
              child: _tile(tile, width: tileWidth, height: tileHeight,
                selected: _selected.contains(tile.id) || candidates.isNotEmpty,
                onTap: _view.roundFinished ? null : () => setState(() {
                  if (!_selected.add(tile.id)) _selected.remove(tile.id);
                })),
            ),
          ),
      ]),
    );
    return Container(
      padding: const EdgeInsets.fromLTRB(5, 6, 5, 6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFF246FAE), Color(0xFF124675), Color(0xFF092A4B)]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _gold, width: 2),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 9, offset: Offset(0, 3))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        rackRow(hand.take(12).toList()),
        const SizedBox(height: 2),
        rackRow(hand.skip(12).toList()),
      ]),
    );
  }

  Widget _meldField() {
    return LayoutBuilder(builder: (context, constraints) => Container(
      decoration: BoxDecoration(
        gradient: const RadialGradient(colors: [Color(0xFF2477B7), _felt, _deep], radius: 1.2),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: const Color(0xFF5BA4E4), width: 1.4),
        boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 10)],
      ),
      child: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _TableGridPainter())),
        if (_view.melds.isEmpty)
          Center(child: Opacity(opacity: .14,
            child: Text('101 OKEY', style: TextStyle(fontSize: math.min(36, constraints.maxWidth / 8),
              letterSpacing: 5, fontWeight: FontWeight.w900, color: const Color(0xFFB9E2FF))))),
        Positioned.fill(child: Padding(
          padding: const EdgeInsets.all(7),
          child: SingleChildScrollView(child: Wrap(spacing: 7, runSpacing: 7,
            children: _view.melds.map((meld) {
              final selected = _selectedMeldId == meld.id;
              return DragTarget<String>(
                onWillAcceptWithDetails: (details) => _canProcess && meld.type != GameMeldType.pair,
                onAcceptWithDetails: (details) => _act({
                  'action': 'add_to_meld', 'meldId': meld.id, 'tileId': details.data,
                  if (_representedFaces[details.data] != null)
                    'representedFace': _representedFaces[details.data]!.toJson(),
                }),
                builder: (context, candidates, rejected) => GestureDetector(
                  onTap: () => setState(() => _selectedMeldId = meld.id),
                  child: Container(padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: candidates.isNotEmpty || selected ? _gold.withValues(alpha: .23) : Colors.black26,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: selected ? _gold : Colors.white24)),
                    child: Row(mainAxisSize: MainAxisSize.min,
                      children: meld.tiles.map((item) => Padding(
                        padding: const EdgeInsets.only(right: 2),
                        child: _tile(item.tile, width: 27, height: 38, shownFace: item.representedFace))).toList())),
                ),
              );
            }).toList(),
          )),
        )),
      ]),
    ));
  }

  Widget _timerStrip() {
    final active = _myTurn && !_view.roundFinished;
    final progress = active ? _turnSecondsRemaining / _turnLimitSeconds : 1.0;
    final seconds = _turnSecondsRemaining.toString().padLeft(2, '0');
    return SizedBox(height: 26, child: Row(children: [
      const Icon(Icons.timer_outlined, color: Color(0xFFB6E1FF), size: 17),
      const SizedBox(width: 7),
      Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(10),
        child: LinearProgressIndicator(
          value: progress,
          minHeight: 8,
          backgroundColor: const Color(0xFF183B5D),
          valueColor: AlwaysStoppedAnimation<Color>(
            active && _turnSecondsRemaining <= 8 ? const Color(0xFFFFA6A6) : const Color(0xFF74CBFF)),
        ))),
      const SizedBox(width: 9),
      SizedBox(width: 43, child: Text(active ? '00:$seconds' : '--:--',
        textAlign: TextAlign.end,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Color(0xFFD8EEFF)))),
    ]));
  }

  Widget _sideAction(String text, IconData icon, VoidCallback? action) {
    return SizedBox(height: 39, child: ElevatedButton.icon(
      onPressed: action,
      icon: Icon(icon, size: 16),
      label: FittedBox(fit: BoxFit.scaleDown, child: Text(text,
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900))),
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF1B609D),
        disabledBackgroundColor: const Color(0xFF183653),
        foregroundColor: Colors.white,
        disabledForegroundColor: Colors.white38,
        padding: const EdgeInsets.symmetric(horizontal: 5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9),
          side: const BorderSide(color: Color(0xFF5795CE), width: .8)),
      ),
    ));
  }

  Widget _sidePanel() {
    return Container(
      width: 158,
      margin: const EdgeInsets.only(left: 7),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: const Color(0xB90A2545),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF3A79B6)),
      ),
      child: Column(children: [
        SizedBox(height: 24, child: Row(children: [
          const Expanded(child: Text('101 OKEY', style: TextStyle(
            color: Color(0xFFD7EDFF), fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 13))),
          IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 25, height: 24),
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close_rounded, color: Color(0xFFB8DFFF), size: 18)),
        ])),
        Expanded(child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: 5,
          crossAxisSpacing: 5,
          childAspectRatio: 1.85,
          children: [
            _sideAction('SERİ AÇ', Icons.view_week_outlined,
              _canStartOpening ? _seriesOpenButton : null),
            _sideAction('ÇİFT AÇ', Icons.filter_2_outlined,
              _canStartOpening ? _pairsOpenButton : null),
            _sideAction('GERİ TOPLA', Icons.undo_rounded,
              (_draftMelds.isNotEmpty || _draftPairs.isNotEmpty || _selected.isNotEmpty)
                  ? _takeBackDrafts : null),
            _sideAction('TAŞLARI İŞLE', Icons.playlist_add_rounded,
              _canProcess && _selected.length == 1 && _selectedMeldId != null
                  ? _addToSelectedMeld : null),
            _sideAction('TAŞ AT', Icons.north_east_rounded,
              _canDiscard ? () => _act({'action': 'discard', 'tileId': _selected.first}) : null),
            _sideAction('OKEY DEĞERİ', Icons.auto_awesome_outlined,
              _myTurn && !_view.mustDraw && !_busy && _selected.length == 1 ? _chooseOkeyValue : null),
          ],
        )),
        if (_view.roundFinished)
          SizedBox(height: 26, child: widget.session.canStartNextRound
            ? TextButton(onPressed: _busy ? null : _startNextRound,
                child: const Text('Yeni el', style: TextStyle(color: Color(0xFFB6E1FF)))
            ) : const Center(child: Text('Yeni el bekleniyor', style: TextStyle(fontSize: 9)))),
      ]),
    );
  }


  Widget _centerDrawColumn() {
    return Container(
      width: 65,
      margin: const EdgeInsets.symmetric(horizontal: 5),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: const Color(0xCC0A2B4D),
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: const Color(0xFF3D80B8)),
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        const Text('GÖSTERGE', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 8, color: Color(0xFFB9DFFF), fontWeight: FontWeight.w900)),
        _tile(_view.indicator, width: 37, height: 48),
        const Text('OKEY', style: TextStyle(fontSize: 8, color: Color(0xFFB9DFFF), fontWeight: FontWeight.w900)),
        _tile(Tile.numbered(id: 'okey-display', color: _view.realOkey.color,
          number: _view.realOkey.number), width: 37, height: 48),
        InkWell(
          onTap: _canDraw ? () => _act(const {'action': 'draw_stock'}) : null,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 51, height: 57,
            decoration: BoxDecoration(
              color: _canDraw ? const Color(0xFF246DA9) : const Color(0xFF183653),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF71B8F2)),
              boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 5, offset: Offset(1, 2))],
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.layers_rounded, color: Color(0xFFE7F5FF), size: 23),
              Text('${_view.drawPileCount}', style: const TextStyle(
                color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
              const Text('ÇEK', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900)),
            ]),
          ),
        ),
        InkWell(
          onTap: _canDraw && _view.discardPile.isNotEmpty
              ? () => _act(const {'action': 'take_discard'}) : null,
          borderRadius: BorderRadius.circular(8),
          child: Column(children: [
            if (_view.discardPile.isNotEmpty)
              _tile(_view.discardPile.last, width: 37, height: 48)
            else
              Container(width: 37, height: 48, decoration: BoxDecoration(
                color: const Color(0xFF153B5E), borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.white24))),
            const SizedBox(height: 2),
            const Text('YANDAN AL', textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFFD6ECFF), fontSize: 7, fontWeight: FontWeight.w900)),
          ]),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentPlayer = _view.players.firstWhere((p) => p.seat == _view.currentSeat);
    final others = [1, 2, 3].map((delta) =>
      _view.players[(_view.mySeat + delta) % 4]).toList();
    final points = _draftOpeningPoints();
    return Scaffold(
      backgroundColor: _deep,
      body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
        return Container(
          decoration: const BoxDecoration(gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF0C3764), Color(0xFF061A35), Color(0xFF14558D)])),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(7, 4, 7, 5),
            child: Column(children: [
              _timerStrip(),
              const SizedBox(height: 4),
              Expanded(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Expanded(child: Column(children: [
                  SizedBox(height: 34, child: Row(children: [
                    for (var i = 0; i < 3; i++) ...[
                      if (i > 0) const SizedBox(width: 5),
                      Expanded(child: _playerBadge(others[i], compact: true)),
                    ],
                  ])),
                  const SizedBox(height: 5),
                  Expanded(child: _meldField()),
                  const SizedBox(height: 4),
                  SizedBox(height: 25, child: Row(children: [
                    Expanded(child: _smallTag(
                      _view.roundFinished ? 'Kazanan: ${_view.players[_view.winnerSeat ?? 0].name}'
                        : _myTurn ? 'SIRA SENDE · ${_myPlayer.name}' : 'SIRA: ${currentPlayer.name}',
                      icon: Icons.person_outline, highlighted: _myTurn)),
                    const SizedBox(width: 5),
                    _smallTag('EL TOPLAMI  $_handTotal', icon: Icons.calculate_outlined, highlighted: true),
                    const SizedBox(width: 5),
                    _smallTag(_myPlayer.hasOpened
                        ? (_myPlayer.openingType == OpeningType.normal ? '101 AÇILDI' : 'ÇİFT AÇILDI')
                        : (_draftPairs.isNotEmpty ? 'ÇİFT ${_draftPairs.length}/5' : 'AÇILIŞ $points/101'),
                      icon: Icons.flag_outlined, highlighted: _myPlayer.hasOpened || points >= 101),
                  ])),
                  if (_view.requiredOpeningTileId != null)
                    const SizedBox(height: 15, child: Align(alignment: Alignment.centerLeft,
                      child: Text('Yandan aldığınız taşı bu tur 101 veya çift açılışında kullanmalısınız.',
                        style: TextStyle(fontSize: 9, color: Color(0xFFB9E2FF))))),
                  const SizedBox(height: 2),
                  _handRack(math.max(260.0, constraints.maxWidth - 248)),
                  const SizedBox(height: 2),
                  SizedBox(height: 21, child: Row(children: [
                    Expanded(child: Text('${_myPlayer.name}  ·  ${_myPlayer.totalScore} toplam puan',
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFFD7EDFF)))),
                    if (_assisted) ...[
                      TextButton(onPressed: () => _autoArrange(pairs: false),
                        style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 5),
                          minimumSize: Size.zero, tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                        child: const Text('SERİ DİZ', style: TextStyle(fontSize: 9, color: Color(0xFFB6E1FF)))),
                      TextButton(onPressed: () => _autoArrange(pairs: true),
                        style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 5),
                          minimumSize: Size.zero, tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                        child: const Text('ÇİFT DİZ', style: TextStyle(fontSize: 9, color: Color(0xFFB6E1FF)))),
                    ],
                    InkWell(onTap: () => setState(() => _assisted = !_assisted),
                      child: _smallTag(_assisted ? 'YARDIMLI' : 'YARDIMSIZ',
                        icon: _assisted ? Icons.auto_awesome : Icons.pan_tool_alt_outlined,
                        highlighted: _assisted)),
                  ])),
                ])),
                _centerDrawColumn(),
                _sidePanel(),
              ])),
              if (_view.roundFinished && !widget.session.canStartNextRound)
                const SizedBox(height: 14, child: Text('Masa sahibinin yeni eli başlatması bekleniyor.',
                  style: TextStyle(fontSize: 9, color: Colors.white70))),
            ]),
          ),
        );
      })),
    );
  }

}

class _TableGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFB4DBFF).withValues(alpha: .12)
      ..strokeWidth = .65;
    for (var x = 0.0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (var y = 0.0; y < size.height; y += 36) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    final center = Paint()..color = const Color(0xFF9CD8FF).withValues(alpha: .26)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), center);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
