// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'bot/bot_strategy.dart';
import 'session/solo_game_controller.dart';
import 'ui/game_table_screen.dart';
import 'ui/multiplayer_lobby_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const OkeyApp());
}

class OkeyApp extends StatelessWidget {
  const OkeyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '101 Okey',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF071A35),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF287FC0),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0D3158)),
      ),
      home: const GameHomeScreen(),
    );
  }
}

class GameHomeScreen extends StatelessWidget {
  const GameHomeScreen({super.key});

  Future<void> _startSolo(BuildContext context) async {
    final difficulty = await showDialog<BotDifficulty>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Bilgisayara karşı oyna'),
        content: const Text('Üç botun zorluk seviyesini seç.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, BotDifficulty.easy),
            child: const Text('Kolay'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, BotDifficulty.medium),
            child: const Text('Orta'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, BotDifficulty.hard),
            child: const Text('Zor'),
          ),
        ],
      ),
    );
    if (difficulty == null || !context.mounted) return;
    final session = SoloGameController.newGame(difficulty: difficulty);
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => GameTableScreen(
        session: session,
        initialView: session.currentGameView,
      ),
    ));
    await session.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF185C98), Color(0xFF071A35), Color(0xFF0B3764)])),
        child: SafeArea(child: Center(child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Padding(padding: const EdgeInsets.all(22),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 22),
              decoration: BoxDecoration(
                color: const Color(0xCC0B2B4D),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: const Color(0xFF5AA7E4), width: 1.5),
                boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 24, offset: Offset(0, 10))],
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 66, height: 66,
                  decoration: BoxDecoration(shape: BoxShape.circle,
                    color: const Color(0xFF1E70B1),
                    border: Border.all(color: const Color(0xFF8ACBFF), width: 2)),
                  child: const Icon(Icons.grid_view_rounded, size: 34, color: Colors.white)),
                const SizedBox(height: 10),
                const Text('101 OKEY', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900,
                  letterSpacing: 4, color: Color(0xFFE4F3FF))),
                const Text('MAVİ MASA', style: TextStyle(fontSize: 11, letterSpacing: 3,
                  color: Color(0xFF9ACFFF), fontWeight: FontWeight.w800)),
                const SizedBox(height: 22),
                SizedBox(width: 280, child: FilledButton.icon(
                  onPressed: () => _startSolo(context),
                  icon: const Icon(Icons.smart_toy_outlined),
                  label: const Text('BOTLARA KARŞI OYNA'),
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF267FC1),
                    foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 15))),
                ),
                const SizedBox(height: 10),
                SizedBox(width: 280, child: OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const MultiplayerLobbyScreen())),
                  icon: const Icon(Icons.wifi_rounded),
                  label: const Text('AYNI WI-FI İLE OYNA'),
                  style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFD5EDFF),
                    side: const BorderSide(color: Color(0xFF64B1EB)),
                    padding: const EdgeInsets.symmetric(vertical: 15))),
                ),
                const SizedBox(height: 12),
                const Text('Tek kişilik bot oyunu veya aynı Wi-Fi ağında dört kişilik masa',
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.white70)),
              ]),
            ),
          ),
        ))),
      ),
    );
  }
}