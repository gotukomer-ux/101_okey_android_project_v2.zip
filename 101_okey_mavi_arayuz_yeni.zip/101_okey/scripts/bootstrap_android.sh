#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK bulunamadı. https://docs.flutter.dev/get-started/install adresinden Flutter'ı kurun." >&2
  exit 1
fi

flutter create --platforms=android --org com.example --project-name classic_101_okey "$TMP/scaffold"
rm -rf "$ROOT/android"
cp -R "$TMP/scaffold/android" "$ROOT/android"
cp "$ROOT/android_template/app/src/main/AndroidManifest.xml" "$ROOT/android/app/src/main/AndroidManifest.xml"
mkdir -p "$ROOT/android/app/src/main/kotlin/com/example/classic_101_okey"
cp "$ROOT/android_template/app/src/main/kotlin/com/example/classic_101_okey/MainActivity.kt" \
  "$ROOT/android/app/src/main/kotlin/com/example/classic_101_okey/MainActivity.kt"

# Android 17 is API 37. Targeting API 37 enables ACCESS_LOCAL_NETWORK;
# Android 16 (API 36) remains supported and does not show this permission prompt.
GRADLE_KTS="$ROOT/android/app/build.gradle.kts"
GRADLE_GROOVY="$ROOT/android/app/build.gradle"
if [[ -f "$GRADLE_KTS" ]]; then
  python3 - "$GRADLE_KTS" <<'PYTHON'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text()
s, compile_count = re.subn(r'compileSdk\s*=\s*flutter\.compileSdkVersion', 'compileSdk = 37', s, count=1)
s, target_count = re.subn(r'targetSdk\s*=\s*flutter\.targetSdkVersion', 'targetSdk = 37', s, count=1)
if compile_count != 1 or target_count != 1:
    raise SystemExit('Gradle Kotlin DSL: compileSdk/targetSdk API 37 ayarlanamadı.')
p.write_text(s)
PYTHON
elif [[ -f "$GRADLE_GROOVY" ]]; then
  python3 - "$GRADLE_GROOVY" <<'PYTHON'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text()
s, compile_count = re.subn(r'compileSdkVersion\s+flutter\.compileSdkVersion', 'compileSdkVersion 37', s, count=1)
s, target_count = re.subn(r'targetSdkVersion\s+flutter\.targetSdkVersion', 'targetSdkVersion 37', s, count=1)
if compile_count != 1 or target_count != 1:
    raise SystemExit('Gradle Groovy: compileSdk/targetSdk API 37 ayarlanamadı.')
p.write_text(s)
PYTHON
else
  echo "Android app Gradle dosyası bulunamadı." >&2
  exit 1
fi

echo "Android platformu oluşturuldu; compileSdk/targetSdk 37 (Android 17) olarak ayarlandı."
echo "Android 16 (API 36) uyumluluğu korunuyor."
