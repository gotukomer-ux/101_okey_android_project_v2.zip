#!/usr/bin/env python3
"""Source-structure checks only; these are not Dart or Android runtime tests."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import yaml

ROOT = Path(__file__).resolve().parents[1]
required = [
    "lib/main.dart",
    "lib/domain/tile.dart",
    "lib/domain/tile_set.dart",
    "lib/domain/meld.dart",
    "lib/game/opening_rules.dart",
    "lib/game/game_state.dart",
    "lib/game/game_engine.dart",
    "lib/bot/bot_strategy.dart",
    "lib/session/game_session.dart",
    "lib/session/solo_game_controller.dart",
    "lib/multiplayer/transport_event.dart",
    "lib/multiplayer/multiplayer_transport.dart",
    "lib/multiplayer/lan_transport.dart",
    "lib/multiplayer/room_state.dart",
    "lib/multiplayer/room_coordinator.dart",
    "lib/ui/multiplayer_lobby_screen.dart",
    "lib/ui/game_table_screen.dart",
    "android_template/app/src/main/AndroidManifest.xml",
    "android_template/app/src/main/kotlin/com/example/classic_101_okey/MainActivity.kt",
    "test/tile_set_test.dart",
    "test/meld_validator_test.dart",
    "test/game/opening_rules_test.dart",
    "test/game/game_engine_test.dart",
    "test/bot/bot_strategy_test.dart",
    "test/multiplayer/room_registry_test.dart",
    "test/multiplayer/lan_transport_test.dart",
    "test/multiplayer/game_sync_test.dart",
    "test/multiplayer/protocol_test.dart",
    "scripts/bootstrap_android.sh",
    "scripts/verify_android.sh",
]
missing = [path for path in required if not (ROOT / path).is_file()]
if missing:
    print("Missing files:", *missing, sep="\n- ")
    sys.exit(1)

manifest_path = ROOT / "android_template/app/src/main/AndroidManifest.xml"
manifest_text = manifest_path.read_text()
kotlin_text = (ROOT / "android_template/app/src/main/kotlin/com/example/classic_101_okey/MainActivity.kt").read_text()
lan_text = (ROOT / "lib/multiplayer/lan_transport.dart").read_text()
transport_text = (ROOT / "lib/multiplayer/multiplayer_transport.dart").read_text()
room_text = (ROOT / "lib/multiplayer/room_state.dart").read_text()
coordinator_text = (ROOT / "lib/multiplayer/room_coordinator.dart").read_text()
engine_text = (ROOT / "lib/game/game_engine.dart").read_text()
view_text = (ROOT / "lib/game/game_state.dart").read_text()
opening_text = (ROOT / "lib/game/opening_rules.dart").read_text()
ui_text = (ROOT / "lib/ui/game_table_screen.dart").read_text()
bot_text = (ROOT / "lib/bot/bot_strategy.dart").read_text()
solo_text = (ROOT / "lib/session/solo_game_controller.dart").read_text()
session_text = (ROOT / "lib/session/game_session.dart").read_text()
main_text = (ROOT / "lib/main.dart").read_text()

checks = {
    "Android manifest declares INTERNET": 'android.permission.INTERNET' in manifest_text,
    "Android manifest declares local network access": 'android.permission.ACCESS_LOCAL_NETWORK' in manifest_text,
    "Android native bridge only handles local network permission": 'ensureLocalNetworkPermission' in kotlin_text and 'Bluetooth' not in kotlin_text,
    "Wi-Fi transport caps remote seats at three": '_peers.length >= 3' in lan_text,
    "Wi-Fi transport supports rejected-peer cleanup": 'disconnectPeer(String peerId)' in transport_text and 'disconnectPeer(String peerId)' in lan_text,
    "Lobby is Wi-Fi-only and has no Bluetooth entry points": 'Yalnızca aynı Wi-Fi ağı üzerinden oynanır' in (ROOT / "lib/ui/multiplayer_lobby_screen.dart").read_text() and 'Bluetooth' not in (ROOT / "lib/ui/multiplayer_lobby_screen.dart").read_text(),
    "Lobby uses the matching blue visual theme": '0xFF123E68' in (ROOT / "lib/ui/multiplayer_lobby_screen.dart").read_text() and '0xFF78C5FF' in (ROOT / "lib/ui/multiplayer_lobby_screen.dart").read_text(),
    "Room registry resolves peer identity to a seat": 'playerForPeer(String peerId)' in room_text and 'peerForSeat(int seat)' in room_text,
    "Game engine starts a four-seat 106-tile deal": 'TileSet.deal' in engine_text and 'playerNames.length != 4' in engine_text,
    "Indicator-to-okey calculation is centralized": 'realOkeyFor(indicator)' in (ROOT / "lib/domain/tile_set.dart").read_text(),
    "Game engine validates all incoming actions": 'engine.applyAction(player.seat' in coordinator_text and 'void applyAction(int seat' in engine_text,
    "Host sends seat-specific game snapshots": 'engine.viewFor(seat).toJson()' in coordinator_text,
    "Host resolves seat from authenticated socket mapping": 'registry.playerForPeer(peerId)' in coordinator_text,
    "Network protocol version is explicitly pinned and checked": "protocolVersion = 2" in coordinator_text and "data[\'protocol\'] != protocolVersion" in coordinator_text,
    "Old multiplayer protocol is covered by a TCP rejection test": "protocol': 1" in (ROOT / "test/multiplayer/protocol_test.dart").read_text() and "join_rejected" in (ROOT / "test/multiplayer/protocol_test.dart").read_text(),
    "UI explains mandatory yandan-taken opening tile": 'Yandan aldığınız taşı bu tur 101 veya çift açılışında kullanmalısınız.' in ui_text,
    "Host separates human action rejection from bot processing": 'Human action is committed' in coordinator_text,
    "Game view serializes only the recipient hand": "'myHand': myHand" in view_text and "'hand':" not in view_text,
    "Turn, normal opening and pair opening rules exist": all(value in engine_text for value in ['drawFromStock', 'takeDiscard', 'openNormally', 'openPairs', 'discard']),
    "Opening points include represented joker value": 'item.representedFace?.number' in opening_text,
    "Incoming game views validate physical tile uniqueness": 'Aynı fiziksel taş oyun görüntüsünde birden fazla yerde' in view_text,
    "Incoming game views check indicator and real okey consistency": 'Gösterge ile gerçek okey değeri uyuşmuyor' in view_text,
    "UI supports draw, discard, normal/pair open and adding to meld": all(value in ui_text for value in ['draw_stock', 'take_discard', 'discard', 'open_normal', 'open_pairs', 'add_to_meld']),
    "UI has a 30-second turn clock": '_turnLimitSeconds = 30' in ui_text and '_timerStrip()' in ui_text,
    "UI places the draw pile beside the central table": 'Widget _centerDrawColumn()' in ui_text and '_centerDrawColumn(),\n                _sidePanel()' in ui_text,
    "UI displays total hand value and 101 opening progress": 'EL TOPLAMI  $_handTotal' in ui_text and 'AÇILIŞ $points/101' in ui_text,
    "Timed-out turn draws and discards a least-useful tile": '_handleTurnTimeout()' in ui_text and 'chooseLeastUsefulDiscard(' in ui_text and 'protectedTileIds: stagedTileIds' in ui_text,
    "Timeout strategy keeps locally staged opening tiles": 'protectedTileIds' in bot_text and 'staged tiles while choosing another isolated tile' in (ROOT / 'test/bot/bot_strategy_test.dart').read_text(),
    "UI supports hand reordering by drag handle": '_moveTileTo' in ui_text and 'DragTarget<String>' in ui_text,
    "UI supports dragging a tile onto a public meld": 'LongPressDraggable<String>' in ui_text and 'DragTarget<String>' in ui_text,
    "LAN integration test covers four seats and synchronized turns": 'four LAN seats' in (ROOT / 'test/multiplayer/game_sync_test.dart').read_text(),
    "Game-engine tests import deterministic Random": "import 'dart:math';" in (ROOT / 'test/game/game_engine_test.dart').read_text(),
    "Tile-set tests import the tile model explicitly": 'domain/tile.dart' in (ROOT / 'test/tile_set_test.dart').read_text(),
    "Offline mode uses the same authoritative game engine": 'engine.applyAction(seat, action)' in solo_text,
    "Bot strategy supports normal/pair opening and meld processing": all(value in bot_text for value in ['open_normal', 'open_pairs', 'add_to_meld', 'discard']),
    "Three local bots are driven automatically": 'while (!_engine.isFinished && _engine.currentSeat != 0)' in solo_text,
    "Solo play is accessible from the home screen": 'BOTLARA KARŞI OYNA' in main_text,
    "Network and offline sessions share one game-table contract": 'implements GameSession' in coordinator_text and 'implements GameSession' in solo_text,
    "New round preserves cumulative scores in both modes": 'initialScores: scores' in solo_text and 'initialScores: scores' in coordinator_text,
    "Game table exposes the next-round action": 'canStartNextRound' in ui_text and 'startNextRound' in ui_text,
    "False joker penalty uses the current real okey face value": 'if (tile.kind == TileKind.falseJoker) return realOkey.number;' in engine_text,
    "Round results update cumulative totals": 'player.totalScore += _scoreDeltas[player.seat]!;' in engine_text,
    "Yandan alınan zorunlu taş, yalnızca ilgili oyuncunun görünümüne eklenir": 'requiredOpeningTileId: seat == _currentSeat ? _requiredOpeningTileId : null' in engine_text,
    "Game view validates and serializes the forced opening tile": 'requiredOpeningTileId' in view_text and 'view.myHand.any((tile) => tile.id == view.requiredOpeningTileId)' in view_text,
    "Bot can take discard when it is used in its opening or meld": '_shouldTakeDiscard(view)' in bot_text and "'action': 'take_discard'" in bot_text,
    "Bot discard protects connected meld tiles and keeps jokers": 'connections * 100.0' in bot_text and 'return 11000' in bot_text and '_futureMeldPotential' in bot_text,
    "Room can fill two- or three-human tables with bots": 'fillRemainingWithBots' in room_text and 'humanCount >= 2' in room_text and 'isBot' in room_text,
    "Host automatically executes bot turns before broadcasting": '_runBotTurns()' in coordinator_text and 'engine.applyAction(seat, action)' in coordinator_text and 'fillWithBots: true' in (ROOT / "lib/ui/multiplayer_lobby_screen.dart").read_text(),
    "Bot tests cover auto-play, meld protection, discard use and rule actions": all(value in (ROOT / 'test/bot/bot_strategy_test.dart').read_text() for value in ['open_normal', 'open_pairs', 'add_to_meld', 'take_discard', 'automatically plays all three bots', 'discards an isolated tile']),
}

try:
    ET.parse(manifest_path)
    checks["Android manifest is valid XML"] = True
except ET.ParseError as error:
    checks["Android manifest is valid XML"] = False
    print("Manifest XML error:", error)

try:
    pubspec = yaml.safe_load((ROOT / "pubspec.yaml").read_text())
    checks["pubspec parses and declares Flutter SDK"] = isinstance(pubspec, dict) and "flutter" in pubspec.get("dependencies", {})
except yaml.YAMLError as error:
    checks["pubspec parses and declares Flutter SDK"] = False
    print("pubspec YAML error:", error)

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
if failed:
    sys.exit(1)
print(f"\n{len(checks)} source-structure checks passed. Flutter/Dart tests and APK runtime/build verification are separate and were not performed by this script.")
