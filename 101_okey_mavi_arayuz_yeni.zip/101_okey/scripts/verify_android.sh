#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

flutter pub get
flutter analyze
flutter test
flutter build apk --debug

echo "All Flutter checks passed. Candidate APK: build/app/outputs/flutter-apk/app-debug.apk"
