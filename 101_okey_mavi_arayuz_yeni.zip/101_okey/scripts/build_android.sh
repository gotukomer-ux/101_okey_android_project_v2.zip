#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

for tool in flutter java; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "HATA: $tool bulunamadı. Flutter SDK ve Android Studio/SDK kurulmalı." >&2
    exit 2
  fi
done

bash scripts/bootstrap_android.sh
flutter pub get
flutter analyze
flutter test --reporter expanded
flutter build apk --release
APK="build/app/outputs/flutter-apk/app-release.apk"
test -s "$APK"
echo "BAŞARILI: $APK"
