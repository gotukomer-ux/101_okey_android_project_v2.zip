import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../domain/meld.dart';
import '../domain/tile.dart';
import '../game/game_state.dart';
import '../game/opening_rules.dart';
import '../session/game_session.dart';

class GameTableScreen extends StatefulWidget {
  const GameTableScreen({
    super.key,
    required this.session,
    required this.initialView,
  });

  final GameSession session;
  final GameView initialView;

  @override
  State<GameTableScreen> createState() => _GameTableScreenState();
}

class _GameTableScreenState extends State<GameTableScreen> {
  late GameView _view;
  StreamSubscription<GameView>? _subscription;
  StreamSubscription<String>? _statusSubscription;
  final Set<String> _selected = {};
  final List<List<String>> _draftMelds = [];
  final List<List<String>> _draftPairs = [];
  final Map<String, TileFace> _representedFaces = {};
  String? _selectedMeldId;
  bool _busy = false;
  bool _sortByNumber = false;
  bool _assisted = true;
  bool _pairSort = false;
  int? _scoreFlash;
  List<String> _manualOrder = [];

  @override
  void initState() {
    super.initState();
    _view = widget.initialView;
    _manualOrder = _view.myHand.map((tile) => tile.id).toList();
    _subscription = widget.session.gameViews.listen((view) {
      if (!mounted) return;
      setState(() {
        _view = view;
        final currentIds = view.myHand.map((tile) => tile.id).toSet();
        _manualOrder.removeWhere((id) => !currentIds.contains(id));
        for (final tile in view.myHand) {
          if (!_manualOrder.contains(tile.id)) _manualOrder.add(tile.id);
        }
        // Selection is cleared only after an authoritative state update. A
        // rejected network move therefore leaves the user's selection intact.
        _selected.clear();
        _selectedMeldId = null;
        _representedFaces.removeWhere((id, _) => !currentIds.contains(id));
        final mine = view.players.firstWhere((player) => player.seat == view.mySeat);
        if (mine.hasOpened) {
          _draftMelds.clear();
          _draftPairs.clear();
        }
      });
    });
    _statusSubscription = widget.session.statuses.listen((message) {
      final lower = message.toLowerCase();
      if (lower.contains('hata') || lower.contains('redded') ||
          lower.contains('geçersiz') || lower.contains('sıra sizde değil') ||
          lower.contains('bulunamadı') || lower.contains('başarısız') ||
          lower.contains('bad state')) {
        _showMessage(message);
      }
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _statusSubscription?.cancel();
    super.dispose();
  }

  PlayerGameSummary get _myPlayer => _view.players.firstWhere((player) => player.seat == _view.mySeat);
  bool get _myTurn => !_view.roundFinished && _view.currentSeat == _view.mySeat;
  bool get _canProcess => _myTurn && !_view.mustDraw && !_busy &&
      _myPlayer.openingType == OpeningType.normal && _view.myHand.length > 1;
  bool get _canStartOpening => _myTurn && !_view.mustDraw && !_busy && !_myPlayer.hasOpened;
  bool get _canDraw => _myTurn && _view.mustDraw && !_busy;
  bool get _canDiscard => _myTurn && !_view.mustDraw && !_busy && _selected.length == 1;

  List<Tile> get _displayHand {
    final hand = [..._view.myHand];
    if (_pairSort) {
      hand.sort((a, b) {
        if (!a.isNumbered || !b.isNumbered) return a.isNumbered ? -1 : 1;
        final ac = _view.myHand.where((t) => t.color == a.color && t.number == a.number).length;
        final bc = _view.myHand.where((t) => t.color == b.color && t.number == b.number).length;
        if (ac != bc) return bc.compareTo(ac);
        final color = a.color!.index.compareTo(b.color!.index);
        return color != 0 ? color : a.number!.compareTo(b.number!);
      });
    } else if (_sortByNumber) {
      hand.sort((a, b) {
        if (a.isNumbered != b.isNumbered) return a.isNumbered ? -1 : 1;
        if (!a.isNumbered) return a.id.compareTo(b.id);
        final colorCompare = a.color!.index.compareTo(b.color!.index);
        return colorCompare != 0 ? colorCompare : a.number!.compareTo(b.number!);
      });
    } else {
      final order = {for (var i = 0; i < _manualOrder.length; i++) _manualOrder[i]: i};
      hand.sort((a, b) => (order[a.id] ?? 1 << 20).compareTo(order[b.id] ?? 1 << 20));
    }
    return hand;
  }

  Future<void> _act(Map<String, dynamic> action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.session.submitGameAction(action);
      // The session publishes an authoritative view after acceptance. Do not
      // clear a remote player's selection merely because the socket write worked.
      if (!mounted) return;
    } catch (error) {
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  Future<void> _startNextRound() async {
    if (_busy || !widget.session.canStartNextRound) return;
    setState(() => _busy = true);
    try {
      await widget.session.startNextRound();
      if (mounted) {
        setState(() {
          _selected.clear();
          _draftMelds.clear();
          _draftPairs.clear();
          _representedFaces.clear();
          _selectedMeldId = null;
          _manualOrder = _view.myHand.map((tile) => tile.id).toList();
        });
      }
    } catch (error) {
      _showMessage(error.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _stageMeld() {
    if (!_canStartOpening || _selected.length < 3) return;
    if (_draftPairs.isNotEmpty) {
      _showMessage('Çift açılışı hazırlarken normal per hazırlayamazsınız.');
      return;
    }
    final alreadyStaged = _draftMelds.expand((meld) => meld).toSet();
    if (_selected.any(alreadyStaged.contains)) {
      _showMessage('Bir taş iki farklı per içinde kullanılamaz.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final tiles = _selected
        .map((id) => byId[id]!)
        .map((tile) => MeldTile(tile, representedFace: _representedFaces[tile.id]))
        .toList();
    final validation = MeldValidator.validate(tiles, _view.realOkey);
    if (!validation.isValid) {
      _showMessage(validation.error ?? 'Seçilen taşlar geçerli per değil.');
      return;
    }
    setState(() {
      _draftMelds.add(_selected.toList());
      _selected.clear();
      _scoreFlash = _draftOpeningPoints();
    });
  }

  void _stagePair() {
    if (!_canStartOpening || _selected.length != 2) return;
    if (_draftMelds.isNotEmpty) {
      _showMessage('Normal açılış hazırlarken çift açılışı hazırlayamazsınız.');
      return;
    }
    final alreadyStaged = _draftPairs.expand((pair) => pair).toSet();
    if (_selected.any(alreadyStaged.contains)) {
      _showMessage('Bir taş iki farklı çift içinde kullanılamaz.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final selectedTiles = _selected.map((id) => byId[id]!).toList();
    final first = selectedTiles[0];
    final second = selectedTiles[1];
    if (!first.isNumbered || !second.isNumbered ||
        first.color != second.color || first.number != second.number) {
      _showMessage('Çift aynı renk ve aynı sayıdaki iki taştan oluşmalı.');
      return;
    }
    setState(() {
      _draftPairs.add(_selected.toList());
      _selected.clear();
      _scoreFlash = _draftPairs.length * 2;
    });
  }


  int _draftOpeningPoints() {
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    return _draftMelds.fold<int>(0, (total, ids) {
      final meld = ids.map((id) => MeldTile(
        byId[id]!,
        representedFace: _representedFaces[id],
      )).toList();
      return total + OpeningRules.meldPoints(meld, _view.realOkey);
    });
  }

  Future<void> _openNormal() async {
    setState(() => _scoreFlash = _draftOpeningPoints());
    if (_draftMelds.isEmpty || _myPlayer.hasOpened) return;
    if (_draftPairs.isNotEmpty) {
      _showMessage('Çift açılışı hazırlarken normal açılış yapamazsınız.');
      return;
    }
    final byId = {for (final tile in _view.myHand) tile.id: tile};
    final proposedMelds = _draftMelds
        .map((ids) => ids
            .map((id) => MeldTile(byId[id]!, representedFace: _representedFaces[id]))
            .toList())
        .toList();
    final points = proposedMelds.fold<int>(
        0, (sum, meld) => sum + OpeningRules.meldPoints(meld, _view.realOkey));
    if (!OpeningRules.canOpenNormally(proposedMelds, _view.realOkey)) {
      _showMessage('Açılış geçersiz veya toplamı $points. En az 101 puanlık geçerli perler gerekli.');
      return;
    }
    await _act({
      'action': 'open_normal',
      'melds': _draftMelds
          .map((ids) => ids
              .map((id) => {
                    'tileId': id,
                    if (_representedFaces[id] != null)
                      'representedFace': _representedFaces[id]!.toJson(),
                  })
              .toList())
          .toList(),
    });
  }

  Future<void> _openPairs() async {
    setState(() => _scoreFlash = _draftPairs.length * 2);
    if (_draftPairs.length < 5 || _draftMelds.isNotEmpty || _myPlayer.hasOpened) {
      _showMessage('Çift açmak için başka normal per hazırlamadan en az beş çift gerekli.');
      return;
    }
    await _act({'action': 'open_pairs', 'pairs': _draftPairs});
  }

  Future<void> _addToSelectedMeld() async {
    if (!_canProcess || _selected.length != 1 || _selectedMeldId == null) return;
    await _act({
      'action': 'add_to_meld',
      'meldId': _selectedMeldId,
      'tileId': _selected.first,
      if (_representedFaces[_selected.first] != null)
        'representedFace': _representedFaces[_selected.first]!.toJson(),
    });
  }


  Future<void> _chooseOkeyValue() async {
    if (_selected.length != 1) {
      _showMessage('Önce elinizden tek bir gerçek okey taşı seçin.');
      return;
    }
    final tileId = _selected.first;
    final matches = _view.myHand.where((tile) => tile.id == tileId).toList();
    if (matches.isEmpty) return;
    final tile = matches.first;
    final isRealOkey = tile.isNumbered &&
        tile.color == _view.realOkey.color && tile.number == _view.realOkey.number;
    if (!isRealOkey) {
      _showMessage('Yalnızca gerçek okeyin temsil edeceği yüz seçilebilir.');
      return;
    }
    var color = _representedFaces[tileId]?.color ?? TileColor.red;
    var number = _representedFaces[tileId]?.number ?? 1;
    final selectedFace = await showDialog<TileFace>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Okey hangi taşın yerine geçsin?'),
          content: Row(
            children: [
              Expanded(
                child: DropdownButton<TileColor>(
                  isExpanded: true,
                  value: color,
                  items: TileColor.values
                      .map((value) => DropdownMenuItem(value: value, child: Text(value.name)))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => color = value);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: number,
                  items: List.generate(13, (index) => index + 1)
                      .map((value) => DropdownMenuItem(value: value, child: Text('$value')))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => number = value);
                  },
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, TileFace(color, number)), child: const Text('Uygula')),
          ],
        ),
      ),
    );
    if (selectedFace != null && mounted) {
      setState(() => _representedFaces[tileId] = selectedFace);
    }
  }

  // The view is purely presentational: all rule validation and network actions
  // remain in the existing game engine and GameSession.
  static const _navy = Color(0xFF062936);
  static const _deep = Color(0xFF031C29);
  static const _felt = Color(0xFF073B4A);
  static const _gold = Color(0xFFE2B96C);

  Color _faceColor(TileColor color) {
    switch (color) {
      case TileColor.red:
        return const Color(0xFFB71C2A);
      case TileColor.blue:
        return const Color(0xFF096EBB);
      case TileColor.black:
        return const Color(0xFF17202A);
      case TileColor.yellow:
        return const Color(0xFFD39712);
    }
  }

  void _moveTileTo(String dragged, String target) {
    if (dragged == target) return;
    final order = _displayHand.map((tile) => tile.id).toList();
    if (!order.contains(dragged) || !order.contains(target)) return;
    order.remove(dragged);
    order.insert(order.indexOf(target), dragged);
    setState(() {
      _manualOrder = order;
      _sortByNumber = false;
    });
  }

  void _autoArrange({required bool pairs}) {
    if (!_assisted) return;
    final tiles = [..._view.myHand];
    if (pairs) {
      // Identical tiles become adjacent; colours and numbers remain stable.
      tiles.sort((a, b) {
        if (!a.isNumbered || !b.isNumbered) {
          return a.isNumbered ? -1 : b.isNumbered ? 1 : a.id.compareTo(b.id);
        }
        final n = a.number!.compareTo(b.number!);
        if (n != 0) return n;
        return a.color!.index.compareTo(b.color!.index);
      });
    } else {
      // Same-colour consecutive numbers become adjacent.
      tiles.sort((a, b) {
        if (!a.isNumbered || !b.isNumbered) {
          return a.isNumbered ? -1 : b.isNumbered ? 1 : a.id.compareTo(b.id);
        }
        final c = a.color!.index.compareTo(b.color!.index);
        return c != 0 ? c : a.number!.compareTo(b.number!);
      });
    }
    setState(() {
      _manualOrder = tiles.map((tile) => tile.id).toList();
      _sortByNumber = false;
    });
  }

  Widget _tile(Tile tile, {
    bool selected = false,
    VoidCallback? onTap,
    double width = 42,
    double? height,
    TileFace? shownFace,
  }) {
    final face = shownFace ??
        (tile.isNumbered ? TileFace(tile.color!, tile.number!) : null);
    final tileHeight = height ?? width * 1.42;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        width: width,
        height: tileHeight,
        transform: selected ? Matrix4.translationValues(0, -4, 0) : null,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFFFFF), Color(0xFFFFF7E8), Color(0xFFE3D9C7)],
          ),
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: selected ? _gold : const Color(0xFFBDB3A1), width: selected ? 2.3 : 1),
          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 3, offset: Offset(0, 2))],
        ),
        child: Stack(children: [
          Align(
            alignment: const Alignment(0, -0.20),
            child: face == null
                ? Icon(Icons.local_florist_rounded, color: const Color(0xFF27864B), size: width * .64)
                : Text('${face.number}',
                    style: TextStyle(fontSize: width * .59, height: 1.05,
                      fontWeight: FontWeight.w900, color: _faceColor(face.color))),
          ),
          Positioned(bottom: tileHeight * .10, left: 0, right: 0,
            child: Center(child: Container(width: width * .19, height: width * .19,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: const Color(0xFFBDB4A4).withValues(alpha: .42),
                border: Border.all(color: const Color(0xFFBBB1A2), width: .7)))),),
        ]),
      ),
    );
  }

  BoxDecoration _panel({bool highlight = false, double radius = 12}) => BoxDecoration(
    gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFF0E4052), Color(0xFF072331)]),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: highlight ? _gold : const Color(0xFF66808A), width: highlight ? 1.5 : .8),
    boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 5, offset: Offset(0, 3))],
  );

  Widget _playerBadge(PlayerGameSummary player, {bool compact = false}) {
    final current = player.seat == _view.currentSeat && !_view.roundFinished;
    return Container(
      constraints: const BoxConstraints(minWidth: 0),
      padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 9, vertical: 5),
      decoration: _panel(highlight: current),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        CircleAvatar(radius: compact ? 11 : 15, backgroundColor: const Color(0xFF18596A),
          child: Icon(Icons.smart_toy_outlined, size: compact ? 14 : 19, color: _gold)),
        const SizedBox(width: 5),
        Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min,
          children: [
            Text(player.name, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: compact ? 10 : 12, fontWeight: FontWeight.w800)),
            Text('${player.handCount} taş · ${player.totalScore} p',
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: compact ? 8 : 10, color: Colors.white70)),
          ])),
      ]),
    );
  }

  Widget _smallTag(String text, {IconData? icon, bool highlighted = false}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    decoration: _panel(highlight: highlighted, radius: 9),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      if (icon != null) ...[Icon(icon, size: 13, color: _gold), const SizedBox(width: 4)],
      Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))),
    ]),
  );

  Widget _action(String text, IconData icon, VoidCallback? onPressed,
      {Color color = const Color(0xFF124F63)}) {
    return SizedBox(height: 39, child: ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color, disabledBackgroundColor: const Color(0xFF233B43),
        foregroundColor: Colors.white, disabledForegroundColor: Colors.white38,
        padding: const EdgeInsets.symmetric(horizontal: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9),
          side: BorderSide(color: onPressed == null ? Colors.white12 : _gold.withValues(alpha: .65))),
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 16),
        Text(text, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
      ]),
    ));
  }

  Widget _handRack(double availableWidth) {
    final hand = _displayHand;
    // 11 positions per row fit a narrow phone without clipping the hand.
    final tileWidth = math.min(44.0, (availableWidth - 20) / 11.0);
    final tileHeight = tileWidth * 1.42;
    Widget rackRow(List<Tile> items) => SizedBox(
      height: tileHeight + 4,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (final tile in items)
          DragTarget<String>(
            onWillAcceptWithDetails: (details) => details.data != tile.id,
            onAcceptWithDetails: (details) => _moveTileTo(details.data, tile.id),
            builder: (context, candidates, rejected) => LongPressDraggable<String>(
              data: tile.id,
              feedback: Material(color: Colors.transparent,
                child: _tile(tile, width: tileWidth, height: tileHeight, selected: true)),
              childWhenDragging: Opacity(opacity: .3,
                child: _tile(tile, width: tileWidth, height: tileHeight)),
              child: _tile(tile, width: tileWidth, height: tileHeight,
                selected: _selected.contains(tile.id) || candidates.isNotEmpty,
                onTap: _view.roundFinished ? null : () => setState(() {
                  if (!_selected.add(tile.id)) _selected.remove(tile.id);
                })),
            ),
          ),
      ]),
    );
    return Container(
      padding: const EdgeInsets.fromLTRB(5, 6, 5, 6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFFE0A746), Color(0xFF8B4B20), Color(0xFF48280F)]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _gold, width: 2),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 9, offset: Offset(0, 3))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        rackRow(hand.take(11).toList()),
        const SizedBox(height: 2),
        rackRow(hand.skip(11).toList()),
      ]),
    );
  }

  Widget _meldField() {
    return LayoutBuilder(builder: (context, constraints) => Container(
      decoration: BoxDecoration(
        gradient: const RadialGradient(colors: [Color(0xFF12596B), _felt, _deep], radius: 1.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _gold, width: 1.8),
        boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 12)],
      ),
      child: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _TableGridPainter())),
        if (_view.melds.isEmpty)
          Center(child: Opacity(opacity: .11,
            child: Text('101 OKEY', style: TextStyle(fontSize: math.min(38, constraints.maxWidth / 8),
              letterSpacing: 5, fontWeight: FontWeight.w900, color: _gold)))),
        Positioned.fill(child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 7, 72, 7),
          child: SingleChildScrollView(child: Wrap(spacing: 6, runSpacing: 6,
            children: _view.melds.map((meld) {
              final selected = _selectedMeldId == meld.id;
              return DragTarget<String>(
                onWillAcceptWithDetails: (details) => _canProcess && meld.type != GameMeldType.pair,
                onAcceptWithDetails: (details) => _act({
                  'action': 'add_to_meld', 'meldId': meld.id, 'tileId': details.data,
                  if (_representedFaces[details.data] != null)
                    'representedFace': _representedFaces[details.data]!.toJson(),
                }),
                builder: (context, candidates, rejected) => GestureDetector(
                  onTap: () => setState(() => _selectedMeldId = meld.id),
                  child: Container(padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: candidates.isNotEmpty || selected ? _gold.withValues(alpha: .28) : Colors.black26,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: selected ? _gold : Colors.white24)),
                    child: Row(mainAxisSize: MainAxisSize.min,
                      children: meld.tiles.map((item) => Padding(
                        padding: const EdgeInsets.only(right: 2),
                        child: _tile(item.tile, width: 25, height: 36, shownFace: item.representedFace))).toList())),
                ),
              );
            }).toList(),
          )),
        )),
        Positioned(top: 7, right: 6, child: Column(children: [
          const Text('Gösterge', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
          _tile(_view.indicator, width: 31, height: 43),
          const SizedBox(height: 5),
          const Text('Okey', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
          _tile(Tile.numbered(id: 'okey-display', color: _view.realOkey.color,
            number: _view.realOkey.number), width: 31, height: 43),
        ])),
        Positioned(bottom: 7, right: 6, child: Column(children: [
          Container(width: 37, height: 42, alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF153C68),
              borderRadius: BorderRadius.circular(5), border: Border.all(color: _gold)),
            child: const Icon(Icons.style_rounded, color: Colors.white70, size: 23)),
          Text('${_view.drawPileCount} taş', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
          if (_view.discardPile.isNotEmpty) ...[
            const SizedBox(height: 4),
            _tile(_view.discardPile.last, width: 29, height: 40),
          ],
        ])),
      ]),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final currentPlayer = _view.players.firstWhere((p) => p.seat == _view.currentSeat);
    final others = [1, 2, 3].map((delta) =>
      _view.players[(_view.mySeat + delta) % 4]).toList();
    final points = _draftOpeningPoints();
    return Scaffold(
      backgroundColor: _deep,
      body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
        final narrow = constraints.maxWidth < 600;
        return Container(
          decoration: const BoxDecoration(gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF083B4C), Color(0xFF021B27), Color(0xFF0B4250)])),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Column(children: [
              SizedBox(height: 43, child: Row(children: [
                const Icon(Icons.casino_outlined, color: _gold, size: 21),
                const SizedBox(width: 5),
                const Expanded(child: Text('101 Okey',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFFFFE3A2)))),
                _smallTag('El ${_view.roundNumber}', icon: Icons.flag_outlined),
                const SizedBox(width: 6),
                TextButton(onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Lobi', style: TextStyle(color: _gold))),
              ])),
              SizedBox(height: 47, child: Row(children: [
                for (var i = 0; i < 3; i++) ...[
                  if (i > 0) const SizedBox(width: 5),
                  Expanded(child: _playerBadge(others[i], compact: narrow)),
                ],
              ])),
              const SizedBox(height: 7),
              Expanded(child: _meldField()),
              const SizedBox(height: 6),
              SizedBox(height: 35, child: Row(children: [
                Expanded(child: _smallTag(_view.roundFinished
                  ? 'Kazanan: ${_view.players[_view.winnerSeat ?? 0].name}'
                  : _myTurn ? 'Sıra sizde' : 'Sıra: ${currentPlayer.name}',
                  icon: Icons.person_outline, highlighted: _myTurn)),
                const SizedBox(width: 6),
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                  decoration: _panel(highlight: points >= 101),
                  child: Text(_draftPairs.isNotEmpty ? 'Çift: ${_draftPairs.length}/5' : 'El: $points',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _gold))),
                const SizedBox(width: 6),
                _smallTag('${_view.drawPileCount} taş', icon: Icons.layers_outlined),
              ])),
              if (_view.requiredOpeningTileId != null)
                const Padding(padding: EdgeInsets.symmetric(vertical: 2),
                  child: Text('Yandan aldığınız taşı bu tur 101 veya çift açılışında kullanmalısınız.',
                    style: TextStyle(fontSize: 10, color: _gold))),
              SizedBox(height: 27, child: Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.account_circle, size: 20, color: _gold),
                  const SizedBox(width: 6),
                  Flexible(child: Text('${_myPlayer.name} · ${_myPlayer.totalScore} puan',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
                  const SizedBox(width: 10),
                  InkWell(onTap: () => setState(() => _assisted = !_assisted),
                    child: _smallTag(_assisted ? 'Yardımlı' : 'Yardımsız',
                      icon: _assisted ? Icons.auto_awesome : Icons.pan_tool_alt_outlined,
                      highlighted: _assisted)),
                ])),
              _handRack(constraints.maxWidth - 16),
              const SizedBox(height: 6),
              GridView.count(
                shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 4, mainAxisSpacing: 4, crossAxisSpacing: 5,
                childAspectRatio: (constraints.maxWidth / 4 - 7) / 39,
                children: [
                  _action('Taş çek', Icons.layers, _canDraw ? () => _act({'action': 'draw_stock'}) : null,
                    color: const Color(0xFF136444)),
                  _action('Yandan al', Icons.arrow_forward, _canDraw && _view.discardPile.isNotEmpty
                    ? () => _act({'action': 'take_discard'}) : null),
                  _action('Taş at', Icons.delete_outline, _canDiscard
                    ? () => _act({'action': 'discard', 'tileId': _selected.first}) : null,
                    color: const Color(0xFF8A2D2C)),
                  _action('Per ekle', Icons.add_circle_outline, _canStartOpening ? _stageMeld : null),
                  _action('Okey değeri', Icons.info_outline,
                    _myTurn && !_view.mustDraw && !_busy && _selected.length == 1 ? _chooseOkeyValue : null),
                  _action('Çift ekle', Icons.filter_2_outlined, _canStartOpening ? _stagePair : null),
                  _action('101 aç', Icons.flag_outlined,
                    _canStartOpening && _draftMelds.isNotEmpty ? _openNormal : null,
                    color: const Color(0xFF6E5322)),
                  _action('Çift aç', Icons.style_outlined,
                    _canStartOpening && _draftPairs.length >= 5 ? _openPairs : null),
                ],
              ),
              if (_assisted) ...[
                const SizedBox(height: 4),
                Row(children: [
                  Expanded(child: _action('Seri Diz', Icons.view_week_outlined,
                    () => _autoArrange(pairs: false))),
                  const SizedBox(width: 6),
                  Expanded(child: _action('Çift Diz', Icons.copy_all_outlined,
                    () => _autoArrange(pairs: true))),
                  const SizedBox(width: 6),
                  Expanded(child: _action('Pere işle', Icons.playlist_add,
                    _canProcess && _selected.length == 1 && _selectedMeldId != null
                      ? _addToSelectedMeld : null)),
                ]),
              ] else ...[
                const SizedBox(height: 4),
                SizedBox(width: double.infinity, child: _action('Seçili pere işle',
                  Icons.playlist_add,
                  _canProcess && _selected.length == 1 && _selectedMeldId != null
                    ? _addToSelectedMeld : null)),
              ],
              if (_view.roundFinished)
                SizedBox(height: 33, child: widget.session.canStartNextRound
                  ? TextButton(onPressed: _busy ? null : _startNextRound,
                      child: const Text('Yeni el başlat', style: TextStyle(color: _gold)))
                  : const Center(child: Text('Masa sahibinin yeni eli başlatması bekleniyor.',
                      style: TextStyle(fontSize: 10)))),
              const SizedBox(height: 5),
            ]),
          ),
        );
      })),
    );
  }
}

class _TableGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFF7BA4A8).withValues(alpha: .095)
      ..strokeWidth = .65;
    for (var x = 0.0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (var y = 0.0; y < size.height; y += 36) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    final center = Paint()..color = const Color(0xFFE2B96C).withValues(alpha: .22)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), center);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
